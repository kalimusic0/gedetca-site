//  GedetcaTheme.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "GedetcaTheme.hpp"

#include <QColor>
#include <QDir>
#include <QFile>
#include <algorithm>
#include <cmath>
#include <QMap>


namespace glabels::GedetcaTheme
{

        namespace
        {
                struct Colors
                {
                        QString win;         // window background
                        QString base;        // inputs / lists background
                        QString alt;         // alternate rows
                        QString text;
                        QString textSec;
                        QString border;
                        QString borderSoft;
                        QString hover;       // hover of buttons / items
                        QString sel;         // selected items
                        QString accent;      // turquoise
                        QString accentHover;
                        QString accentText;  // accent for text over the window
                        QString menuBar;     // top bar (always dark, like gedetca_web)
                        QString menuText;
                        QString menuHover;
                        QString header;      // table headers
                        QString headerText;
                        QString disabled;
                        QString tipBg;
                        QString tipText;
                };

                const Colors LIGHT = {
                        "#ebf5f9", "#fafcfd", "#f2f9fb", "#0a1f29", "#496d79",
                        "#bdd4db", "#d6e6eb", "#d4f1f7", "#bff1f8",
                        "#009eb2", "#05bed6", "#00838a",
                        "#041d28", "#e9fdff", "#0d5160",
                        "#063847", "#e9fdff", "#94a3a8",
                        "#041d28", "#e9fdff"
                };

                const Colors DARK = {
                        "#062733", "#083f50", "#0a4658", "#e9fdff", "#9fdbe3",
                        "#0d5160", "#0b4757", "#0d5160", "#0f6578",
                        "#00b8d4", "#2de2b0", "#5ff2ff",
                        "#021821", "#e9fdff", "#0d5160",
                        "#0b4a5a", "#e9fdff", "#5f8a95",
                        "#e9fdff", "#041d28"
                };

                Colors customDark, customLight;
                bool   customSet = false;

                const Colors& colors( bool dark )
                {
                        if ( customSet )
                        {
                                return dark ? customDark : customLight;
                        }
                        return dark ? DARK : LIGHT;
                }

                // CSS-like hsl(): hue in degrees (any value), saturation and lightness in %
                QString hsl( double h, double s, double l )
                {
                        double hue = std::fmod( std::fmod( h, 360.0 ) + 360.0, 360.0 ) / 360.0;
                        return QColor::fromHslF( hue, std::clamp( s / 100.0, 0.0, 1.0 ), std::clamp( l / 100.0, 0.0, 1.0 ) ).name();
                }
        }


        void setCustom( double h, double s, double lb )
        {
                // Dark mode (tema.css, :root)
                customDark = {
                        hsl( h + 11, 81.8*s, 8.6 + lb ),    // win
                        hsl( h + 7,  84.4*s, 15.1 + lb ),   // base
                        hsl( h + 8,  76.8*s, 13.5 + lb ),   // alt
                        hsl( h - 2,  100*s,  95.7 + lb ),   // text
                        hsl( h,      32.3*s, 74.5 + lb ),   // textSec
                        hsl( h + 9,  68.8*s, 28 + lb ),     // border
                        hsl( h + 9,  68.8*s, 20 + lb ),     // borderSoft
                        hsl( h + 4,  76.1*s, 21.4 + lb ),   // hover
                        hsl( h + 4,  87.6*s, 27 + lb ),     // sel
                        hsl( h,      100*s,  43.5 + lb ),   // accent
                        hsl( h,      87.3*s, 53.7 + lb ),   // accentHover
                        hsl( h - 2,  100*s,  68.6 + lb ),   // accentText
                        hsl( h + 12, 83.6*s, 5 ),           // menuBar
                        hsl( h - 2,  100*s,  95.7 ),        // menuText
                        hsl( h + 4,  76.1*s, 21.4 ),        // menuHover
                        hsl( h + 4,  87.6*s, 22.2 + lb ),   // header
                        hsl( h - 2,  100*s,  95.7 ),        // headerText
                        hsl( h,      20*s,   45 ),          // disabled
                        hsl( h - 2,  100*s,  95.7 ),        // tipBg
                        hsl( h + 11, 81.8*s, 8.6 )          // tipText
                };

                // Light mode (tema.css, :root[data-modo="claro"])
                customLight = {
                        hsl( h + 11, 55*s,   95 ),
                        hsl( h + 8,  45*s,   98 ),
                        hsl( h + 7,  50*s,   91 ),
                        hsl( h + 13, 60*s,   10 ),
                        hsl( h + 8,  28*s,   36 ),
                        hsl( h + 8,  30*s,   78 ),
                        hsl( h + 8,  30*s,   86 ),
                        hsl( h + 4,  75*s,   88 ),
                        hsl( h + 4,  75*s,   82 ),
                        hsl( h,      100*s,  35 + lb ),
                        hsl( h,      95*s,   43 + lb ),
                        hsl( h - 4,  100*s,  27 + lb ),
                        hsl( h + 12, 83.6*s, 8 ),
                        hsl( h - 2,  100*s,  95.7 ),
                        hsl( h + 4,  76.1*s, 21.4 ),
                        hsl( h + 4,  75*s,   30 ),
                        "#ffffff",
                        hsl( h,      10*s,   60 ),
                        hsl( h + 12, 83.6*s, 8 ),
                        "#ffffff"
                };

                customSet = true;
        }


        QPalette palette( bool dark )
        {
                const Colors& c = colors( dark );
                QPalette p;

                p.setColor( QPalette::Window,          QColor( c.win ) );
                p.setColor( QPalette::WindowText,      QColor( c.text ) );
                p.setColor( QPalette::Base,            QColor( c.base ) );
                p.setColor( QPalette::AlternateBase,   QColor( c.alt ) );
                p.setColor( QPalette::ToolTipBase,     QColor( c.tipBg ) );
                p.setColor( QPalette::ToolTipText,     QColor( c.tipText ) );
                p.setColor( QPalette::PlaceholderText, QColor( c.textSec ) );
                p.setColor( QPalette::Text,            QColor( c.text ) );
                p.setColor( QPalette::Button,          QColor( c.base ) );
                p.setColor( QPalette::ButtonText,      QColor( c.text ) );
                p.setColor( QPalette::BrightText,      QColor( "#ffffff" ) );
                p.setColor( QPalette::Light,           QColor( dark ? "#0f6578" : "#ffffff" ) );
                p.setColor( QPalette::Midlight,        QColor( c.borderSoft ) );
                p.setColor( QPalette::Mid,             QColor( c.border ) );
                p.setColor( QPalette::Dark,            QColor( c.border ) );
                p.setColor( QPalette::Shadow,          QColor( "#021821" ) );
                p.setColor( QPalette::Highlight,       QColor( c.accent ) );
                p.setColor( QPalette::HighlightedText, QColor( dark ? "#021821" : "#ffffff" ) );
                p.setColor( QPalette::Link,            QColor( c.accentText ) );
                p.setColor( QPalette::LinkVisited,     QColor( dark ? "#2de2b0" : "#0b847c" ) );

                p.setColor( QPalette::Disabled, QPalette::WindowText,      QColor( c.disabled ) );
                p.setColor( QPalette::Disabled, QPalette::Text,            QColor( c.disabled ) );
                p.setColor( QPalette::Disabled, QPalette::ButtonText,      QColor( c.disabled ) );
                p.setColor( QPalette::Disabled, QPalette::HighlightedText, QColor( c.win ) );
                p.setColor( QPalette::Disabled, QPalette::Highlight,       QColor( c.disabled ) );

                return p;
        }


        QString styleSheet( bool dark )
        {
                const Colors& c = colors( dark );

                QString qss = R"(
QMenuBar { background: @menuBar@; color: @menuText@; padding: 2px; }
QMenuBar::item { background: transparent; padding: 4px 10px; border-radius: 6px; }
QMenuBar::item:selected { background: @menuHover@; }

QMenu { background: @base@; color: @text@; border: 1px solid @border@; padding: 4px; }
QMenu::item { padding: 5px 26px 5px 24px; border-radius: 6px; }
QMenu::item:selected { background: @sel@; color: @text@; }
QMenu::item:disabled { color: @disabled@; }
QMenu::separator { height: 1px; background: @borderSoft@; margin: 4px 8px; }

QToolBar { background: @win@; border: none; spacing: 2px; padding: 2px; }
QToolBar::separator { background: @border@; width: 1px; height: 1px; margin: 4px; }
QToolButton { background: transparent; border: 1px solid transparent; border-radius: 8px; padding: 3px; color: @text@; }
QToolButton:hover { background: @hover@; border-color: @border@; }
QToolButton:checked, QToolButton:pressed { background: @sel@; border-color: @accent@; }
QToolButton:disabled { color: @disabled@; }

QPushButton { background: @base@; color: @text@; border: 1px solid @border@; border-radius: 8px; padding: 5px 14px; }
QPushButton:hover { background: @hover@; border-color: @accent@; }
QPushButton:pressed { background: @sel@; }
QPushButton:default, QPushButton:checked { background: @accent@; color: #ffffff; border-color: @accent@; }
QPushButton:default:hover { background: @accentHover@; }
QPushButton:disabled { color: @disabled@; background: @win@; }

QLineEdit, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit, QComboBox {
    background: @base@; color: @text@; border: 1px solid @border@; border-radius: 6px;
    padding: 3px 6px; selection-background-color: @accent@; selection-color: #ffffff;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {
    border-color: @accent@;
}
QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QComboBox:disabled { color: @disabled@; background: @win@; }
QComboBox QAbstractItemView { background: @base@; color: @text@; border: 1px solid @border@;
    selection-background-color: @sel@; selection-color: @text@; outline: 0; }

QTabWidget::pane { border: 1px solid @border@; border-radius: 8px; background: @base@; top: -1px; }
QTabBar::tab { background: transparent; color: @textSec@; padding: 6px 12px; border: none;
    border-bottom: 2px solid transparent; margin-right: 2px; }
QTabBar::tab:selected { color: @accentText@; border-bottom: 2px solid @accent@; font-weight: 600; }
QTabBar::tab:hover:!selected { color: @text@; background: @hover@; border-radius: 6px; }

QGroupBox { border: 1px solid @borderSoft@; border-radius: 8px; margin-top: 12px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: @accentText@; }

QListView, QListWidget, QTreeView, QTableView {
    background: @base@; color: @text@; border: 1px solid @border@; border-radius: 8px;
    alternate-background-color: @alt@; selection-background-color: @sel@; selection-color: @text@;
}
QHeaderView::section { background: @header@; color: @headerText@; border: none; padding: 5px 8px; }

QScrollBar:vertical { background: transparent; width: 12px; margin: 0; }
QScrollBar::handle:vertical { background: @border@; border-radius: 5px; min-height: 24px; margin: 2px; }
QScrollBar::handle:vertical:hover { background: @accent@; }
QScrollBar:horizontal { background: transparent; height: 12px; margin: 0; }
QScrollBar::handle:horizontal { background: @border@; border-radius: 5px; min-width: 24px; margin: 2px; }
QScrollBar::handle:horizontal:hover { background: @accent@; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

QStatusBar { background: @menuBar@; color: @menuText@; }
QStatusBar QLabel { color: @menuText@; }

QToolTip { background: @tipBg@; color: @tipText@; border: 1px solid @accent@; border-radius: 6px; padding: 4px 6px; }

QProgressBar { background: @borderSoft@; border: none; border-radius: 6px; text-align: center; color: @text@; }
QProgressBar::chunk { background: @accent@; border-radius: 6px; }
)";

                const QMap<QString,QString> tokens = {
                        { "@win@", c.win }, { "@base@", c.base }, { "@alt@", c.alt },
                        { "@text@", c.text }, { "@textSec@", c.textSec },
                        { "@border@", c.border }, { "@borderSoft@", c.borderSoft },
                        { "@hover@", c.hover }, { "@sel@", c.sel },
                        { "@accent@", c.accent }, { "@accentHover@", c.accentHover }, { "@accentText@", c.accentText },
                        { "@menuBar@", c.menuBar }, { "@menuText@", c.menuText }, { "@menuHover@", c.menuHover },
                        { "@header@", c.header }, { "@headerText@", c.headerText },
                        { "@disabled@", c.disabled }, { "@tipBg@", c.tipBg }, { "@tipText@", c.tipText } };

                for ( auto it = tokens.constBegin(); it != tokens.constEnd(); ++it )
                {
                        qss.replace( it.key(), it.value() );
                }

                return qss;
        }

}
