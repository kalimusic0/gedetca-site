//  TextScript.hpp
//
//  Runs the data transformation script (JavaScript) of a text object.
//
//  The script is the body of a function with two parameters:
//      Value   the text being transformed (string)
//      Fields  object with the merge fields and variables (name -> string)
//  and must leave the result in Value, e.g.:   Value = Value.substring(2);
//  Etiqueta() is the number of the label in the print run (1, 2, 3...) and Total() how many there are:
//      Value = Etiqueta() + " de " + Total();
//
//  The engine has no access to files, network or the system.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_TextScript_hpp
#define model_TextScript_hpp


#include <QMap>
#include <functional>
#include <QString>


namespace glabels::model
{

        class TextScript
        {
        public:
                // Gives the script the text shown by another object, by name: Objeto("TALLA").
                // The object that runs the script sets it while it processes its text.
                using ObjectResolver = std::function<QString(const QString&)>;
                static ObjectResolver objectResolver();
                static void setObjectResolver( ObjectResolver resolver );

                // Returns true on success.  On failure 'error' (if given) receives the
                // message and 'out' is left equal to 'value'.
                static bool run( const QString&                script,
                                 const QString&                value,
                                 const QMap<QString,QString>&  fields,
                                 QString&                      out,
                                 QString*                      error = nullptr );
        };

}


#endif // model_TextScript_hpp
