//  Gs1.hpp
//
//  GS1 Application Identifiers (AI): catalog, validation and check digits.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_Gs1_hpp
#define model_Gs1_hpp


#include <QList>
#include <QString>


namespace glabels::model::Gs1
{

        enum class Kind { NUMERIC, ALNUM, DATE };

        struct Ai
        {
                QString ai;            // "01", "10", "3103"...
                QString description;   // Spanish description
                Kind    kind;
                int     minLen;
                int     maxLen;        // fixed length when minLen == maxLen
                bool    check;         // last digit is a GS1 check digit

                bool isFixed() const { return minLen == maxLen; }
        };

        const QList<Ai>& aiList();
        const Ai*        findAi( const QString& ai );

        // Check digit (GS1 mod 10) for a string of digits that does not include it
        QString checkDigit( const QString& digitsWithoutCheck );

        // Does a number (all digits, last one is the check digit) have a valid check digit?
        bool hasValidCheckDigit( const QString& digits );

        // "13 caracteres numéricos", "Hasta 20 caracteres alfanuméricos"...
        QString formatDescription( const Ai& ai );

        // Validates a value typed by the user.  Returns an error message (empty when
        // valid) and, when valid, the final value to encode (check digit added).
        QString validate( const Ai& ai, const QString& input, QString* finalValue );

}


#endif // model_Gs1_hpp
