//  TextFormat.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "TextFormat.hpp"
#include "TextScript.hpp"

#include <QLocale>
#include <QRegularExpression>
#include <QUrl>
#include <cmath>


namespace glabels::model
{

        namespace
        {
                QLocale makeLocale( const QString& name )
                {
                        return name.isEmpty() ? QLocale::system() : QLocale( name );
                }

                QString enc( const QString& s )
                {
                        return QString::fromLatin1( QUrl::toPercentEncoding( s ) );
                }

                QString dec( const QString& s )
                {
                        return QUrl::fromPercentEncoding( s.toLatin1() );
                }

                // ---- Search and replace actions <-> string
                QString encodeActions( const QList<TextFormat::ReplaceAction>& actions )
                {
                        QStringList list;
                        for ( const auto& a : actions )
                        {
                                list << QStringList{ QString::number( int(a.kind) ),
                                                     QString::number( int(a.syntax) ),
                                                     QString::number( a.firstOnly ? 1 : 0 ),
                                                     enc( a.description ),
                                                     enc( a.find ),
                                                     enc( a.replace ) }.join( ',' );
                        }
                        return list.join( '|' );
                }

                QList<TextFormat::ReplaceAction> decodeActions( const QString& s )
                {
                        QList<TextFormat::ReplaceAction> actions;
                        if ( s.isEmpty() ) return actions;
                        for ( const QString& item : s.split( '|' ) )
                        {
                                QStringList q = item.split( ',' );
                                if ( q.size() < 6 ) continue;
                                TextFormat::ReplaceAction a;
                                a.kind        = TextFormat::ReplaceAction::Kind( qBound( 0, q[0].toInt(), 1 ) );
                                a.syntax      = TextFormat::ReplaceAction::Syntax( qBound( 0, q[1].toInt(), 2 ) );
                                a.firstOnly   = q[2].toInt() != 0;
                                a.description = dec( q[3] );
                                a.find        = dec( q[4] );
                                a.replace     = dec( q[5] );
                                actions << a;
                        }
                        return actions;
                }

                // ---- Data serialization: add k (may be negative) to a text value
                long long floorDiv( long long a, long long b )
                {
                        long long q = a / b;
                        if ( (a % b != 0) && ((a < 0) != (b < 0)) ) q--;
                        return q;
                }

                QString serialAdd( const QString& s, long long k, int method, bool lowerNew, bool preserve )
                {
                        if ( k == 0 || s.isEmpty() )
                        {
                                return s;
                        }

                        if ( method == TextFormat::SERIAL_NUMERIC )
                        {
                                bool ok = false;
                                long long v = s.trimmed().toLongLong( &ok );
                                if ( !ok ) return s;
                                long long r = v + k;
                                QString t = QString::number( r < 0 ? -r : r );
                                if ( preserve )
                                {
                                        int width = s.trimmed().size();
                                        if ( t.size() < width ) t = t.rightJustified( width, '0' );
                                        if ( t.size() > width ) t = t.right( width );
                                }
                                return QString( r < 0 ? "-" : "" ) + t;
                        }

                        // Alphanumeric / alphabetic: mixed radix (digits 0-9, letters A-Z)
                        QString r = s;
                        long long carry = k;
                        int leftmost = -1;
                        for ( int i = r.size() - 1; i >= 0; i-- )
                        {
                                QChar ch = r[i];
                                bool isDigit = ch.unicode() >= '0' && ch.unicode() <= '9';
                                bool isLetter = ( ch.unicode() >= 'A' && ch.unicode() <= 'Z' ) ||
                                                ( ch.unicode() >= 'a' && ch.unicode() <= 'z' );
                                if ( !( isLetter || ( isDigit && method == TextFormat::SERIAL_ALNUM ) ) )
                                {
                                        continue;
                                }
                                int radix = isDigit ? 10 : 26;
                                int base  = isDigit ? '0' : ( ch.isUpper() ? 'A' : 'a' );
                                long long d = ch.unicode() - base;
                                long long total = d + carry;
                                long long q = floorDiv( total, radix );
                                long long nd = total - q * radix;
                                carry = q;
                                r[i] = QChar( int( base + nd ) );
                                leftmost = i;
                        }

                        if ( carry > 0 && !preserve && leftmost >= 0 )
                        {
                                if ( r[leftmost].isDigit() )
                                {
                                        r.insert( leftmost, QString::number( carry ) );
                                }
                                else
                                {
                                        QString extra;
                                        long long n = carry;
                                        while ( n > 0 )
                                        {
                                                n--;
                                                extra.prepend( QChar( int( ( lowerNew ? 'a' : 'A' ) + n % 26 ) ) );
                                                n /= 26;
                                        }
                                        r.insert( leftmost, extra );
                                }
                        }
                        return r;
                }

                // ---- Search and replace: wildcard pattern -> regular expression
                QRegularExpression makeRegex( const TextFormat::ReplaceAction& a )
                {
                        if ( a.syntax == TextFormat::ReplaceAction::REGEX )
                        {
                                return QRegularExpression( a.find );
                        }
                        // wildcards: * and ?
                        QString p = QRegularExpression::escape( a.find );
                        p.replace( "\\*", ".*" ).replace( "\\?", "." );
                        return QRegularExpression( p, QRegularExpression::DotMatchesEverythingOption );
                }
        }


        bool TextFormat::isDefault() const
        {
                return type == TEXT &&
                       caseMode == CASE_NONE &&
                       prefix.isEmpty() && suffix.isEmpty() &&
                       offsetValue == 0 &&
                       suppressMode == SUPPRESS_NEVER &&
                       replaceActions.isEmpty() &&
                       script.trimmed().isEmpty() &&
                       serialMode == SERIAL_NONE;
        }


        QString TextFormat::toString() const
        {
                if ( isDefault() )
                {
                        return "";
                }
                QStringList parts;
                parts << QString::number( int(type) )
                      << enc( locale )
                      << enc( pattern )
                      << QString::number( grouping ? 1 : 0 )
                      << QString::number( leadingZero ? 1 : 0 )
                      << QString::number( fixedDecimals ? 1 : 0 )
                      << QString::number( decimals )
                      << QString::number( negativeStyle )
                      << QString::number( int(caseMode) )
                      << enc( prefix )
                      << enc( suffix )
                      << QString::number( offsetValue )
                      << QString::number( int(offsetUnit) )
                      << QString::number( int(suppressMode) )
                      << enc( suppressField )
                      << QString::number( int(suppressCond) )
                      << enc( suppressValue )
                      << QString::number( int(serialMode) )
                      << QString::number( int(serialMethod) )
                      << QString::number( serialLowerCase ? 1 : 0 )
                      << QString::number( serialPreserve ? 1 : 0 )
                      << QString::number( serialStep )
                      << QString::number( int(serialEvent) )
                      << QString::number( serialInterval )
                      << enc( script )
                      << encodeActions( replaceActions );
                // NOTE: do not chain QString::arg() here: percent-encoded text such as
                // "%2F" would be taken for a place marker and corrupted.
                return parts.join( ';' );
        }


        TextFormat TextFormat::fromString( const QString& s )
        {
                TextFormat f;
                QStringList p = s.split( ';' );
                if ( p.size() >= 8 )
                {
                        int t = p[0].toInt();
                        f.type          = (t >= 0 && t <= 3) ? Type(t) : TEXT;
                        f.locale        = dec( p[1] );
                        f.pattern       = dec( p[2] );
                        f.grouping      = p[3].toInt() != 0;
                        f.leadingZero   = p[4].toInt() != 0;
                        f.fixedDecimals = p[5].toInt() != 0;
                        f.decimals      = qBound( 0, p[6].toInt(), 15 );
                        f.negativeStyle = qBound( 0, p[7].toInt(), 4 );
                }
                if ( p.size() >= 17 && QRegularExpression( "^%\\d+$" ).match( p[16] ).hasMatch() )
                {
                        // Saved by a version that corrupted the line (QString::arg() mixed the
                        // percent-encoded text with its place markers): the values after the
                        // type and locale are shifted and cannot be trusted, so use defaults.
                        f.pattern.clear();
                        f.grouping = true;  f.leadingZero = true;  f.fixedDecimals = true;
                        f.decimals = 2;     f.negativeStyle = 0;
                        return f;
                }
                if ( p.size() >= 17 )
                {
                        f.caseMode      = CaseMode( qBound( 0, p[8].toInt(), 3 ) );
                        f.prefix        = dec( p[9] );
                        f.suffix        = dec( p[10] );
                        f.offsetValue   = p[11].toInt();
                        f.offsetUnit    = OffsetUnit( qBound( 0, p[12].toInt(), 6 ) );
                        f.suppressMode  = SuppressMode( qBound( 0, p[13].toInt(), 2 ) );
                        f.suppressField = dec( p[14] );
                        f.suppressCond  = Condition( qBound( 0, p[15].toInt(), 4 ) );
                        f.suppressValue = dec( p[16] );
                }
                if ( p.size() >= 26 )
                {
                        f.serialMode      = SerialMode( qBound( 0, p[17].toInt(), 2 ) );
                        f.serialMethod    = SerialMethod( qBound( 0, p[18].toInt(), 2 ) );
                        f.serialLowerCase = p[19].toInt() != 0;
                        f.serialPreserve  = p[20].toInt() != 0;
                        f.serialStep      = p[21].toInt();
                        f.serialEvent     = SerialEvent( qBound( 0, p[22].toInt(), 2 ) );
                        f.serialInterval  = qMax( 1, p[23].toInt() );
                        f.script          = dec( p[24] );
                        f.replaceActions  = decodeActions( p[25] );
                }
                return f;
        }


        bool TextFormat::operator==( const TextFormat& o ) const
        {
                return toString() == o.toString();
        }


        QDateTime TextFormat::referenceDateTime()
        {
                return QDateTime( QDate( 2001, 3, 14 ), QTime( 13, 30, 55 ) );
        }


        QStringList TextFormat::datePatterns()
        {
                return { "dd/MM/yyyy",
                         "MM/dd/yyyy",
                         "d/M/yy",
                         "yyyy-MM-dd",
                         "dd-MM-yyyy",
                         "yyyyMMdd",
                         "yyMMdd",
                         "d MMM yyyy",
                         "d MMMM yyyy",
                         "d 'de' MMMM 'de' yyyy",
                         "dddd, d MMMM yyyy",
                         "dddd, d 'de' MMMM 'de' yyyy",
                         "MMMM yyyy",
                         "dd/MM/yyyy HH:mm",
                         "dd/MM/yyyy HH:mm:ss",
                         "yyyy-MM-dd HH:mm:ss",
                         "yyyy-MM-ddTHH:mm:ss" };
        }


        QStringList TextFormat::timePatterns()
        {
                return { "HH:mm",
                         "hh:mm AP",
                         "h:mm AP",
                         "HH:mm:ss",
                         "hh:mm:ss AP",
                         "h:mm:ss AP",
                         "HHmm",
                         "HHmmss" };
        }


        QStringList TextFormat::negativeStyleExamples()
        {
                return { "-1,234.10", "(1,234.10)", "- 1,234.10", "1,234.10-", "1,234.10 -" };
        }


        QString TextFormat::sampleValue() const
        {
                switch ( type )
                {
                case NUMBER:
                        return "1234.1";
                default:
                        return "";   // date/time: "now"
                }
        }


        bool TextFormat::parseDateTime( const QString& value, QDateTime& dt ) const
        {
                QString v = value.trimmed();
                if ( v.isEmpty() )
                {
                        dt = QDateTime::currentDateTime();
                        return true;
                }

                static const QStringList dateTimeFormats = {
                        "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd/MM/yyyy", "d/M/yyyy",
                        "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy HH:mm", "dd-MM-yyyy",
                        "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
                        "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd",
                        "MM/dd/yyyy", "yyyyMMdd", "yyyyMMddHHmmss",
                        "HH:mm:ss", "HH:mm", "hh:mm AP", "h:mm AP" };

                dt = QDateTime::fromString( v, Qt::ISODateWithMs );
                if ( dt.isValid() ) return true;
                dt = QDateTime::fromString( v, Qt::ISODate );
                if ( dt.isValid() ) return true;

                for ( const QString& f : dateTimeFormats )
                {
                        dt = QDateTime::fromString( v, f );
                        if ( dt.isValid() )
                        {
                                return true;
                        }
                }

                QLocale loc = makeLocale( locale );
                for ( auto fmt : { QLocale::ShortFormat, QLocale::LongFormat } )
                {
                        dt = loc.toDateTime( v, fmt );
                        if ( dt.isValid() ) return true;
                        QDate d = loc.toDate( v, fmt );
                        if ( d.isValid() ) { dt = QDateTime( d, QTime( 0, 0 ) ); return true; }
                        QTime t = loc.toTime( v, fmt );
                        if ( t.isValid() ) { dt = QDateTime( QDate::currentDate(), t ); return true; }
                }

                return false;
        }


        QString TextFormat::formatNumber( double v ) const
        {
                QLocale loc = makeLocale( locale );
                if ( !grouping )
                {
                        loc.setNumberOptions( loc.numberOptions() | QLocale::OmitGroupSeparator );
                }
                else
                {
                        loc.setNumberOptions( loc.numberOptions() & ~QLocale::OmitGroupSeparator );
                }

                bool negative = v < 0;
                double a = std::fabs( v );

                QString s = loc.toString( a, 'f', decimals );

                if ( !fixedDecimals && decimals > 0 )
                {
                        // Maximum: trim trailing zeros (and a dangling decimal point)
                        QString dp = loc.decimalPoint();
                        int pos = s.lastIndexOf( dp );
                        if ( pos >= 0 )
                        {
                                int end = s.size();
                                while ( end > pos + dp.size() && s[end-1] == '0' ) end--;
                                if ( end == pos + dp.size() ) end = pos;
                                s = s.left( end );
                        }
                }

                if ( !leadingZero && a < 1.0 )
                {
                        QString dp = loc.decimalPoint();
                        if ( s.startsWith( "0" + dp ) )
                        {
                                s = s.mid( 1 );
                        }
                }

                if ( negative && s.contains( QRegularExpression( "[1-9]" ) ) )
                {
                        switch ( negativeStyle )
                        {
                        case 1:  s = "(" + s + ")";   break;
                        case 2:  s = "- " + s;        break;
                        case 3:  s = s + "-";         break;
                        case 4:  s = s + " -";        break;
                        default: s = loc.negativeSign() + s; break;
                        }
                }

                return s;
        }


        QString TextFormat::applyCase( const QString& s ) const
        {
                QLocale loc = makeLocale( locale );
                switch ( caseMode )
                {
                case CASE_LOWER:
                        return loc.toLower( s );
                case CASE_UPPER:
                        return loc.toUpper( s );
                case CASE_TITLE:
                {
                        // First letter of each word in capitals, the rest in lower case
                        QString r = loc.toLower( s );
                        bool startOfWord = true;
                        for ( int i = 0; i < r.size(); i++ )
                        {
                                if ( r[i].isLetterOrNumber() )
                                {
                                        if ( startOfWord )
                                        {
                                                r[i] = loc.toUpper( QString( r[i] ) ).at( 0 );
                                        }
                                        startOfWord = false;
                                }
                                else
                                {
                                        startOfWord = true;
                                }
                        }
                        return r;
                }
                default:
                        return s;
                }
        }


        bool TextFormat::tryApply( const QString& value, QString& out ) const
        {
                QString result;

                switch ( type )
                {
                case DATE:
                case TIME:
                {
                        QDateTime dt;
                        if ( !parseDateTime( value, dt ) )
                        {
                                return false;
                        }
                        switch ( offsetUnit )
                        {
                        case SECONDS: dt = dt.addSecs( offsetValue );         break;
                        case MINUTES: dt = dt.addSecs( offsetValue * 60LL );  break;
                        case HOURS:   dt = dt.addSecs( offsetValue * 3600LL ); break;
                        case DAYS:    dt = dt.addDays( offsetValue );         break;
                        case WEEKS:   dt = dt.addDays( offsetValue * 7LL );   break;
                        case MONTHS:  dt = dt.addMonths( offsetValue );       break;
                        case YEARS:   dt = dt.addYears( offsetValue );        break;
                        }
                        QString pat = pattern;
                        if ( pat.isEmpty() )
                        {
                                pat = (type == DATE) ? "dd/MM/yyyy" : "HH:mm";
                        }
                        result = makeLocale( locale ).toString( dt, pat );
                        break;
                }

                case NUMBER:
                {
                        QString v = value.trimmed();
                        if ( v.isEmpty() )
                        {
                                return false;
                        }
                        bool ok = false;
                        double d = makeLocale( locale ).toDouble( v, &ok );
                        if ( !ok ) d = QLocale::c().toDouble( v, &ok );
                        if ( !ok )
                        {
                                return false;
                        }
                        result = formatNumber( d );
                        break;
                }

                default:
                        result = value;
                        break;
                }

                out = prefix + applyCase( result ) + suffix;
                return true;
        }


        QString TextFormat::apply( const QString& value ) const
        {
                QString out;
                return tryApply( value, out ) ? out : value;
        }


        bool TextFormat::suppressed( const QString&       ownValue,
                                     const merge::Record& record,
                                     const Variables&     variables ) const
        {
                switch ( suppressMode )
                {
                case SUPPRESS_IF_EMPTY:
                        return ownValue.trimmed().isEmpty();

                case SUPPRESS_IF_FIELD:
                {
                        QString v;
                        if ( record.contains( suppressField ) )
                        {
                                v = record.value( suppressField );
                        }
                        else if ( variables.contains( suppressField ) )
                        {
                                v = variables[suppressField].value();
                        }

                        switch ( suppressCond )
                        {
                        case COND_EMPTY:      return v.trimmed().isEmpty();
                        case COND_NOT_EMPTY:  return !v.trimmed().isEmpty();
                        case COND_EQUALS:     return v == suppressValue;
                        case COND_NOT_EQUALS: return v != suppressValue;
                        case COND_CONTAINS:   return v.contains( suppressValue );
                        }
                        return false;
                }

                default:
                        return false;
                }
        }


        bool TextFormat::ReplaceAction::operator==( const ReplaceAction& o ) const
        {
                return description == o.description && kind == o.kind && find == o.find &&
                       replace == o.replace && syntax == o.syntax && firstOnly == o.firstOnly;
        }


        QString TextFormat::applyReplaceActions( const QString& value ) const
        {
                QString s = value;

                for ( const ReplaceAction& a : replaceActions )
                {
                        if ( a.kind == ReplaceAction::TRIM )
                        {
                                s = s.trimmed();
                                continue;
                        }

                        if ( a.find.isEmpty() )
                        {
                                continue;
                        }

                        if ( a.syntax == ReplaceAction::EXACT )
                        {
                                if ( a.firstOnly )
                                {
                                        int i = s.indexOf( a.find );
                                        if ( i >= 0 ) s.replace( i, a.find.size(), a.replace );
                                }
                                else
                                {
                                        s.replace( a.find, a.replace );
                                }
                                continue;
                        }

                        QRegularExpression re = makeRegex( a );
                        if ( !re.isValid() )
                        {
                                continue;
                        }

                        if ( a.firstOnly )
                        {
                                QRegularExpressionMatch m = re.match( s );
                                if ( m.hasMatch() )
                                {
                                        QString rep = a.replace;
                                        for ( int g = 9; g >= 1; g-- )
                                        {
                                                rep.replace( QString( "\\%1" ).arg( g ), m.captured( g ) );
                                        }
                                        s.replace( m.capturedStart(), m.capturedLength(), rep );
                                }
                        }
                        else
                        {
                                s.replace( re, a.replace );
                        }
                }

                return s;
        }


        QString TextFormat::process( const QString&       value,
                                     const merge::Record& record,
                                     const Variables&     variables ) const
        {
                return apply( preProcess( value, record, variables ) );
        }


        // The data after search/replace, script and serialization, before the format
        QString TextFormat::preProcess( const QString&       value,
                                        const merge::Record& record,
                                        const Variables&     variables ) const
        {
                QString v = value;

                if ( !replaceActions.isEmpty() )
                {
                        v = applyReplaceActions( v );
                }

                if ( !script.trimmed().isEmpty() )
                {
                        QMap<QString,QString> fields;
                        for ( auto it = variables.constBegin(); it != variables.constEnd(); ++it )
                        {
                                fields.insert( it.key(), it.value().value() );
                        }
                        for ( auto it = record.constBegin(); it != record.constEnd(); ++it )
                        {
                                fields.insert( it.key(), it.value() );
                        }
                        // Para Etiqueta() y Total() del script: numero de esta etiqueta en la tirada y cuantas son
                        fields.insert( "__etiqueta", QString::number( variables.itemCount() + 1 ) );
                        fields.insert( "__total", QString::number( variables.totalItems() > 0 ? variables.totalItems() : 1 ) );
                        QString out;
                        if ( TextScript::run( script, v, fields, out ) )
                        {
                                v = out;
                        }
                }

                if ( serialMode != SERIAL_NONE )
                {
                        long long count = 0;
                        switch ( serialEvent )
                        {
                        case EVENT_ITEM: count = variables.itemCount(); break;
                        case EVENT_COPY: count = variables.copyCount(); break;
                        case EVENT_PAGE: count = variables.pageCount(); break;
                        }
                        v = applySerial( v, count );
                }

                return v;
        }


        QString TextFormat::applySerial( const QString& value, long long count ) const
        {
                if ( serialMode == SERIAL_NONE )
                {
                        return value;
                }
                long long k = ( count / qMax( 1, serialInterval ) ) * serialStep;
                if ( serialMode == SERIAL_DECREMENT ) k = -k;
                return serialAdd( value, k, serialMethod, serialLowerCase, serialPreserve );
        }

}
