//  Gs1Wizard.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "Gs1Wizard.hpp"

#include <QComboBox>
#include <QCoreApplication>
#include <QFormLayout>
#include <QFrame>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QLabel>
#include <QRadioButton>
#include <QRegularExpression>
#include <QStackedWidget>
#include <QTableWidget>
#include <QTreeWidget>
#include <QVBoxLayout>


namespace glabels
{

        namespace Gs1 = model::Gs1;
        using Gs1::Ai;

        namespace
        {
                // Translation context of this file (the page classes have no Q_OBJECT)
                QString T( const char* text )
                {
                        return QCoreApplication::translate( "glabels::Gs1Wizard", text );
                }
        }

        namespace
        {
                // The "Sample" box shown at the bottom of every page
                QLineEdit* addSampleBox( QVBoxLayout* layout )
                {
                        auto* box = new QGroupBox( T("Sample") );
                        auto* boxLayout = new QVBoxLayout( box );
                        auto* edit = new QLineEdit();
                        edit->setReadOnly( true );
                        boxLayout->addWidget( edit );
                        layout->addWidget( box );
                        return edit;
                }

                QString shortName( const Ai& ai )
                {
                        // "Fecha de caducidad (AAMMDD)" -> "Fecha de caducidad"
                        QString d = ai.description;
                        int i = d.indexOf( " (" );
                        return i > 0 ? d.left( i ) : d;
                }

                class Gs1Page : public QWizardPage
                {
                public:
                        Gs1Page()
                        {
                                mMain = new QVBoxLayout( this );
                        }

                protected:
                        Gs1Wizard* gw() const { return static_cast<Gs1Wizard*>( wizard() ); }

                        void finishLayout( bool includeCurrent )
                        {
                                mIncludeCurrent = includeCurrent;
                                mMain->addStretch( 1 );
                                mSample = addSampleBox( mMain );
                        }

                        void refreshSample()
                        {
                                if ( mSample && wizard() )
                                {
                                        mSample->setText( gw()->sampleText( mIncludeCurrent ) );
                                }
                        }

                        QVBoxLayout* mMain;
                        QLineEdit*   mSample{ nullptr };
                        bool         mIncludeCurrent{ false };
                };


                ///////////////////////////////////////////////////////////
                // 1. Application Identifiers
                ///////////////////////////////////////////////////////////
                class Gs1AiPage : public Gs1Page
                {
                public:
                        Gs1AiPage()
                        {
                                setTitle( T("Application identifiers") );
                                setSubTitle( T("Select the application identifier (AI) to be used.") );
                                setFinalPage( true );

                                mTable = new QTableWidget( 0, 2 );
                                mTable->setHorizontalHeaderLabels( { T("AI"), T("Description") } );
                                mTable->verticalHeader()->hide();
                                mTable->setSelectionBehavior( QAbstractItemView::SelectRows );
                                mTable->setSelectionMode( QAbstractItemView::SingleSelection );
                                mTable->setEditTriggers( QAbstractItemView::NoEditTriggers );
                                mTable->horizontalHeader()->setStretchLastSection( true );
                                mTable->setColumnWidth( 0, 56 );
                                mTable->setMinimumHeight( 200 );

                                const auto& list = Gs1::aiList();
                                mTable->setRowCount( list.size() );
                                for ( int i = 0; i < list.size(); i++ )
                                {
                                        mTable->setItem( i, 0, new QTableWidgetItem( list[i].ai ) );
                                        mTable->setItem( i, 1, new QTableWidgetItem( list[i].description ) );
                                }

                                mSearch = new QLineEdit();
                                auto* searchRow = new QHBoxLayout();
                                searchRow->addStretch( 1 );
                                searchRow->addWidget( new QLabel( T("Search (AI or description):") ) );
                                searchRow->addWidget( mSearch, 1 );

                                mMain->addWidget( mTable, 1 );
                                mMain->addLayout( searchRow );
                                finishLayout( false );

                                connect( mTable, &QTableWidget::itemSelectionChanged, this, [this]() { emit completeChanged(); } );
                                connect( mTable, &QTableWidget::cellDoubleClicked, this, [this]() { if ( isComplete() ) wizard()->next(); } );
                                connect( mSearch, &QLineEdit::textChanged, this, [this]( const QString& text ) { filter( text ); } );
                        }

                        void initializePage() override
                        {
                                refreshSample();
                                if ( mTable->currentRow() < 0 )
                                {
                                        mTable->selectRow( 0 );
                                }
                        }

                        bool isComplete() const override
                        {
                                return mTable->currentRow() >= 0 && !mTable->isRowHidden( mTable->currentRow() );
                        }

                        bool validatePage() override
                        {
                                int row = mTable->currentRow();
                                if ( row < 0 ) return false;
                                gw()->mCurrentAi = Gs1::findAi( mTable->item( row, 0 )->text() );
                                if ( !gw()->mCurrentAi ) return false;
                                gw()->mCurrent = Gs1Wizard::Component();
                                gw()->mCurrent.ai = gw()->mCurrentAi->ai;
                                gw()->mCurrentCommitted = false;
                                return true;
                        }

                private:
                        void filter( const QString& text )
                        {
                                for ( int i = 0; i < mTable->rowCount(); i++ )
                                {
                                        bool match = text.trimmed().isEmpty() ||
                                                     mTable->item( i, 0 )->text().contains( text.trimmed(), Qt::CaseInsensitive ) ||
                                                     mTable->item( i, 1 )->text().contains( text.trimmed(), Qt::CaseInsensitive );
                                        mTable->setRowHidden( i, !match );
                                }
                                // keep a visible row selected
                                if ( mTable->currentRow() < 0 || mTable->isRowHidden( mTable->currentRow() ) )
                                {
                                        for ( int i = 0; i < mTable->rowCount(); i++ )
                                        {
                                                if ( !mTable->isRowHidden( i ) ) { mTable->selectRow( i ); break; }
                                        }
                                }
                                emit completeChanged();
                        }

                        QTableWidget* mTable;
                        QLineEdit*    mSearch;
                };


                ///////////////////////////////////////////////////////////
                // 2. Ready to configure the data component
                ///////////////////////////////////////////////////////////
                class Gs1ReadyPage : public Gs1Page
                {
                public:
                        Gs1ReadyPage()
                        {
                                setTitle( T("Ready to configure the data component") );
                                setFinalPage( true );

                                mInfo = new QLabel();
                                mInfo->setWordWrap( true );
                                mTree = new QTreeWidget();
                                mTree->setHeaderHidden( true );
                                mTree->setMinimumHeight( 160 );
                                auto* legend = new QLabel( T("✔ = Finished     ➔ = Next") );
                                legend->setAlignment( Qt::AlignRight );

                                mMain->addWidget( mInfo );
                                mMain->addWidget( mTree, 1 );
                                mMain->addWidget( legend );
                                finishLayout( true );
                        }

                        void initializePage() override
                        {
                                const Ai* ai = gw()->mCurrentAi;
                                mInfo->setText( T("Press Next to start configuring the data source of the data component %1.")
                                                .arg( ai ? shortName( *ai ) : QString() ) );
                                fillTree( mTree, gw(), true );
                                refreshSample();
                        }

                        static void fillTree( QTreeWidget* tree, Gs1Wizard* w, bool withCurrent )
                        {
                                tree->clear();
                                auto add = [tree]( const Ai& ai, bool done )
                                {
                                        auto* folder = new QTreeWidgetItem( tree, { shortName( ai ) } );
                                        new QTreeWidgetItem( folder, { QString( "✔ " ) + T("AI code (%1)").arg( ai.ai ) } );
                                        auto* comp = new QTreeWidgetItem( folder, { QString( done ? "✔ " : "➔ " ) + shortName( ai ) } );
                                        if ( !done ) comp->setForeground( 0, QColor( "#1f7ae0" ) );
                                        folder->setExpanded( true );
                                };
                                for ( const auto& c : w->mComponents )
                                {
                                        if ( const Ai* ai = Gs1::findAi( c.ai ) ) add( *ai, true );
                                }
                                if ( withCurrent && w->mCurrentAi && !w->mCurrentCommitted )
                                {
                                        add( *w->mCurrentAi, false );
                                }
                        }

                private:
                        QLabel*      mInfo;
                        QTreeWidget* mTree;
                };


                ///////////////////////////////////////////////////////////
                // 3. Type of data source
                ///////////////////////////////////////////////////////////
                class Gs1SourcePage : public Gs1Page
                {
                public:
                        Gs1SourcePage()
                        {
                                setTitle( T("Select the type of the data source") );
                                setFinalPage( true );

                                mComponent = new QLabel();
                                mFormat    = new QLabel();
                                auto* form = new QFormLayout();
                                form->addRow( T("Component:"), mComponent );
                                form->addRow( T("Data format:"), mFormat );

                                mType = new QComboBox();
                                mType->addItem( T("Embedded data") );
                                mType->addItem( T("Merge field") );
                                mType->addItem( T("Variable") );
                                auto* typeForm = new QFormLayout();
                                typeForm->addRow( T("Type:"), mType );

                                mDescription = new QLabel();
                                mDescription->setWordWrap( true );
                                mDescription->setFrameShape( QFrame::StyledPanel );
                                mDescription->setMargin( 8 );
                                mDescription->setMinimumHeight( 70 );

                                mMain->addLayout( form );
                                mMain->addSpacing( 12 );
                                mMain->addWidget( new QLabel( T("Select the type of the new data source:") ) );
                                mMain->addLayout( typeForm );
                                mMain->addWidget( mDescription );
                                finishLayout( true );

                                connect( mType, QOverload<int>::of( &QComboBox::currentIndexChanged ), this, [this]( int ) { updateDescription(); } );
                        }

                        void initializePage() override
                        {
                                const Ai* ai = gw()->mCurrentAi;
                                if ( ai )
                                {
                                        mComponent->setText( shortName( *ai ) );
                                        mFormat->setText( Gs1::formatDescription( *ai ) );
                                }
                                mType->setCurrentIndex( int( gw()->mCurrent.source ) );
                                updateDescription();
                                refreshSample();
                        }

                        bool validatePage() override
                        {
                                gw()->mCurrent.source = Gs1Wizard::Source( mType->currentIndex() );
                                return true;
                        }

                private:
                        void updateDescription()
                        {
                                switch ( mType->currentIndex() )
                                {
                                case 0:
                                        mDescription->setText( T("The embedded data source stores the data in the document. It is used mainly to type "
                                                                  "static data with the keyboard, but it can also be used for dynamic data, such as counters.") );
                                        break;
                                case 1:
                                        mDescription->setText( T("The value is taken from a field of the merge data file (Merge tab). "
                                                                  "Each label uses the value of its own record.") );
                                        break;
                                default:
                                        mDescription->setText( T("The value is taken from a variable of the project (Variables tab), "
                                                                  "for example a counter.") );
                                        break;
                                }
                        }

                        QLabel*    mComponent;
                        QLabel*    mFormat;
                        QComboBox* mType;
                        QLabel*    mDescription;
                };


                ///////////////////////////////////////////////////////////
                // 4. The value
                ///////////////////////////////////////////////////////////
                class Gs1ValuePage : public Gs1Page
                {
                public:
                        Gs1ValuePage()
                        {
                                setFinalPage( true );
                                mComponent = new QLabel();
                                mFormat    = new QLabel();
                                auto* form = new QFormLayout();
                                form->addRow( T("Component:"), mComponent );
                                form->addRow( T("Data format:"), mFormat );
                                mMain->addLayout( form );
                                mMain->addSpacing( 12 );

                                mStack = new QStackedWidget();

                                // Embedded
                                auto* embedded = new QWidget();
                                auto* eLayout = new QVBoxLayout( embedded );
                                eLayout->setContentsMargins( 0, 0, 0, 0 );
                                eLayout->addWidget( new QLabel( T("Enter the text for the embedded data source.") ) );
                                mText = new QLineEdit();
                                eLayout->addWidget( mText );
                                mError = new QLabel();
                                mError->setStyleSheet( "color: #c0392b;" );
                                mError->setWordWrap( true );
                                eLayout->addWidget( mError );
                                eLayout->addStretch( 1 );
                                mStack->addWidget( embedded );

                                // Merge field / variable
                                auto* named = new QWidget();
                                auto* nLayout = new QVBoxLayout( named );
                                nLayout->setContentsMargins( 0, 0, 0, 0 );
                                mNamedLabel = new QLabel();
                                nLayout->addWidget( mNamedLabel );
                                mName = new QComboBox();
                                mName->setEditable( true );
                                nLayout->addWidget( mName );
                                mNote = new QLabel();
                                mNote->setWordWrap( true );
                                nLayout->addWidget( mNote );
                                nLayout->addStretch( 1 );
                                mStack->addWidget( named );

                                mMain->addWidget( mStack, 1 );
                                finishLayout( true );

                                connect( mText, &QLineEdit::textChanged, this, [this]() { onEdited(); } );
                                connect( mName, &QComboBox::editTextChanged, this, [this]() { onEdited(); } );
                        }

                        void initializePage() override
                        {
                                Gs1Wizard* w = gw();

                                // Coming back from "add more data?": take the component out again so
                                // that it is not added twice when the user goes forward.
                                if ( w->mCurrentCommitted && !w->mComponents.isEmpty() )
                                {
                                        w->mCurrent = w->mComponents.takeLast();
                                        w->mCurrentCommitted = false;
                                        w->mCurrentAi = Gs1::findAi( w->mCurrent.ai );
                                }

                                const Ai* ai = w->mCurrentAi;
                                if ( ai )
                                {
                                        mComponent->setText( shortName( *ai ) );
                                        mFormat->setText( Gs1::formatDescription( *ai ) );
                                }

                                bool embedded = ( w->mCurrent.source == Gs1Wizard::EMBEDDED );
                                mStack->setCurrentIndex( embedded ? 0 : 1 );

                                if ( embedded )
                                {
                                        setTitle( T("Embedded data") );
                                        setSubTitle( T("Embedded data is provided using the keyboard.") );
                                        mText->setText( w->mCurrent.value );
                                        mText->setFocus();
                                        mText->selectAll();
                                }
                                else
                                {
                                        bool isField = ( w->mCurrent.source == Gs1Wizard::MERGE_FIELD );
                                        setTitle( isField ? T("Merge field") : T("Variable") );
                                        setSubTitle( isField ? T("Choose the merge field that provides the value.")
                                                             : T("Choose the variable that provides the value.") );
                                        mNamedLabel->setText( isField ? T("Merge field:") : T("Variable:") );
                                        mName->blockSignals( true );
                                        mName->clear();
                                        mName->addItems( isField ? w->mFieldNames : w->mVariableNames );
                                        mName->setCurrentText( w->mCurrent.value );
                                        mName->blockSignals( false );
                                        mNote->setText( ai && ai->check
                                                        ? T("The check digit is added automatically: the value must have %1 digits.").arg( ai->maxLen - 1 )
                                                        : QString() );
                                }
                                onEdited();
                        }

                        bool isComplete() const override
                        {
                                Gs1Wizard* w = gw();
                                if ( w->mCurrent.source == Gs1Wizard::EMBEDDED )
                                {
                                        return w->mCurrentAi && Gs1::validate( *w->mCurrentAi, mText->text(), nullptr ).isEmpty();
                                }
                                return !mName->currentText().trimmed().isEmpty();
                        }

                        bool validatePage() override
                        {
                                Gs1Wizard* w = gw();
                                if ( w->mCurrent.source == Gs1Wizard::EMBEDDED )
                                {
                                        QString finalValue;
                                        if ( !Gs1::validate( *w->mCurrentAi, mText->text(), &finalValue ).isEmpty() ) return false;
                                        w->mCurrent.value = finalValue;
                                }
                                else
                                {
                                        w->mCurrent.value = mName->currentText().trimmed();
                                }
                                w->commitCurrent();
                                return true;
                        }

                private:
                        void onEdited()
                        {
                                Gs1Wizard* w = gw();
                                if ( w->mCurrent.source == Gs1Wizard::EMBEDDED )
                                {
                                        w->mCurrent.value = mText->text();
                                        mError->setText( mText->text().isEmpty() || !w->mCurrentAi
                                                         ? QString() : Gs1::validate( *w->mCurrentAi, mText->text(), nullptr ) );
                                }
                                else
                                {
                                        w->mCurrent.value = mName->currentText().trimmed();
                                }
                                refreshSample();
                                emit completeChanged();
                        }

                        QLabel*         mComponent;
                        QLabel*         mFormat;
                        QStackedWidget* mStack;
                        QLineEdit*      mText;
                        QLabel*         mError;
                        QLabel*         mNamedLabel;
                        QComboBox*      mName;
                        QLabel*         mNote;
                };


                ///////////////////////////////////////////////////////////
                // 5. Add more data?
                ///////////////////////////////////////////////////////////
                class Gs1MorePage : public Gs1Page
                {
                public:
                        Gs1MorePage()
                        {
                                setTitle( T("Do you want to add more data?") );

                                mMain->addWidget( new QLabel( T("You have completed the configuration of this application identifier. "
                                                                 "Do you want to add another application identifier?") ) );
                                mYes = new QRadioButton( T("Yes, I want to add another") );
                                mNo  = new QRadioButton( T("No, I do not need more") );
                                mYes->setChecked( true );
                                mMain->addWidget( mYes );
                                mMain->addWidget( mNo );

                                mTree = new QTreeWidget();
                                mTree->setHeaderHidden( true );
                                mTree->setMinimumHeight( 140 );
                                mMain->addWidget( mTree, 1 );
                                auto* legend = new QLabel( T("✔ = Finished") );
                                legend->setAlignment( Qt::AlignRight );
                                mMain->addWidget( legend );
                                finishLayout( false );

                                connect( mYes, &QRadioButton::toggled, this, [this]( bool yes )
                                {
                                        gw()->mAddAnother = yes;
                                        setFinalPage( true );
                                } );
                        }

                        void initializePage() override
                        {
                                Gs1ReadyPage::fillTree( mTree, gw(), false );
                                gw()->mAddAnother = mYes->isChecked();
                                setFinalPage( true );
                                refreshSample();
                        }

                        // Going Back from here: take the component out again, so that pressing
                        // Next once more does not add it twice.
                        void cleanupPage() override
                        {
                                Gs1Wizard* w = gw();
                                // (QWizard also calls this on every page when it closes: ignore that)
                                if ( !w->mFinishing && w->mCurrentCommitted && !w->mComponents.isEmpty() )
                                {
                                        w->mCurrent = w->mComponents.takeLast();
                                        w->mCurrentCommitted = false;
                                        w->mCurrentAi = Gs1::findAi( w->mCurrent.ai );
                                }
                        }

                private:
                        QRadioButton* mYes;
                        QRadioButton* mNo;
                        QTreeWidget*  mTree;
                };
        }


        ///////////////////////////////////////////////////////////////////
        // Gs1Wizard
        ///////////////////////////////////////////////////////////////////

        Gs1Wizard::Gs1Wizard( const QString&     currentData,
                              const QStringList& fieldNames,
                              const QStringList& variableNames,
                              QWidget*           parent )
                : QWizard( parent ), mFieldNames( fieldNames ), mVariableNames( variableNames )
        {
                setWindowTitle( T("GS1 application identifier data source wizard") );
                setWizardStyle( QWizard::ModernStyle );
                setOption( QWizard::HaveFinishButtonOnEarlyPages, true );
                setOption( QWizard::NoBackButtonOnStartPage, false );
                setButtonText( QWizard::FinishButton, T("Finish") );
                setButtonText( QWizard::BackButton,   T("< Back") );
                setButtonText( QWizard::NextButton,   T("Next >") );
                setButtonText( QWizard::CancelButton, T("Cancel") );
                setMinimumSize( 560, 540 );

                setPage( PAGE_AI,     new Gs1AiPage() );
                setPage( PAGE_READY,  new Gs1ReadyPage() );
                setPage( PAGE_SOURCE, new Gs1SourcePage() );
                setPage( PAGE_VALUE,  new Gs1ValuePage() );
                setPage( PAGE_MORE,   new Gs1MorePage() );
                setStartId( PAGE_AI );

                prefill( currentData );
        }


        // QWizard cannot show the same page id twice in its history, so every round of
        // "add another identifier" gets its own set of pages (id = round*10 + page type).
        int Gs1Wizard::nextId() const
        {
                int round = currentId() / 10;
                int type  = currentId() % 10;
                int next  = -1;

                switch ( type )
                {
                case PAGE_AI:     next = PAGE_READY  + round*10; break;
                case PAGE_READY:  next = PAGE_SOURCE + round*10; break;
                case PAGE_SOURCE: next = PAGE_VALUE  + round*10; break;
                case PAGE_VALUE:  next = PAGE_MORE   + round*10; break;
                case PAGE_MORE:   next = mAddAnother ? PAGE_AI + (round+1)*10 : -1; break;
                default:          next = -1;
                }

                Gs1Wizard* self = const_cast<Gs1Wizard*>( this );
                if ( next >= 0 && !page( next ) )
                {
                        switch ( next % 10 )
                        {
                        case PAGE_AI:     self->setPage( next, new Gs1AiPage() );     break;
                        case PAGE_READY:  self->setPage( next, new Gs1ReadyPage() );  break;
                        case PAGE_SOURCE: self->setPage( next, new Gs1SourcePage() ); break;
                        case PAGE_VALUE:  self->setPage( next, new Gs1ValuePage() );  break;
                        case PAGE_MORE:   self->setPage( next, new Gs1MorePage() );   break;
                        }
                }
                return next;
        }

        void Gs1Wizard::done( int result )
        {
                mFinishing = true;
                if ( result == QDialog::Accepted && !mCurrentCommitted && mCurrentAi && currentIsValid() )
                {
                        commitCurrent();   // Finish pressed with a valid value already typed
                }
                QWizard::done( result );
        }


        bool Gs1Wizard::currentIsValid( QString* error, QString* finalValue ) const
        {
                if ( !mCurrentAi )
                {
                        return false;
                }
                if ( mCurrent.source == EMBEDDED )
                {
                        QString err = Gs1::validate( *mCurrentAi, mCurrent.value, finalValue );
                        if ( error ) *error = err;
                        return err.isEmpty();
                }
                if ( finalValue ) *finalValue = mCurrent.value;
                return !mCurrent.value.trimmed().isEmpty();
        }


        void Gs1Wizard::commitCurrent()
        {
                QString finalValue;
                if ( currentIsValid( nullptr, &finalValue ) )
                {
                        Component c = mCurrent;
                        c.value = finalValue;
                        if ( mCurrentCommitted && !mComponents.isEmpty() )
                        {
                                mComponents.last() = c;    // already added (validated twice): replace, never repeat
                        }
                        else
                        {
                                mComponents.append( c );
                        }
                        mCurrentCommitted = true;
                }
        }


        QString Gs1Wizard::sampleText( bool includeCurrent ) const
        {
                auto part = [this]( const Component& c, const QString& value ) -> QString
                {
                        const Ai* ai = Gs1::findAi( c.ai );
                        QString v = value;
                        if ( c.source != EMBEDDED )
                        {
                                v = "{" + value + "}";
                                if ( ai && ai->check ) v += T(" + check digit");
                        }
                        return "(" + c.ai + ") " + v;
                };

                QStringList parts;
                for ( const Component& c : mComponents )
                {
                        parts << part( c, c.value );
                }

                if ( includeCurrent && mCurrentAi && !mCurrentCommitted )
                {
                        QString finalValue;
                        if ( currentIsValid( nullptr, &finalValue ) )
                        {
                                parts << part( mCurrent, finalValue );
                        }
                }

                return parts.join( " " );
        }


        QString Gs1Wizard::dataString() const
        {
                QString data;
                for ( const Component& c : mComponents )
                {
                        const Ai* ai = Gs1::findAi( c.ai );
                        data += "[" + c.ai + "]";
                        if ( c.source == EMBEDDED )
                        {
                                data += c.value;
                        }
                        else
                        {
                                data += "${" + c.value + ( ai && ai->check ? ":c" : "" ) + "}";
                        }
                }
                return data;
        }


        // Reads data like [01]09501101530003[10]${lote} so the wizard can edit it
        void Gs1Wizard::prefill( const QString& data )
        {
                const QRegularExpression re( "[\\[(](\\d{2,4})[\\])]" );
                QList<QRegularExpressionMatch> matches;
                auto it = re.globalMatch( data );
                while ( it.hasNext() ) matches << it.next();
                if ( matches.isEmpty() ) return;

                QList<Component> parsed;
                for ( int i = 0; i < matches.size(); i++ )
                {
                        const Ai* ai = Gs1::findAi( matches[i].captured( 1 ) );
                        if ( !ai ) return;   // unknown AI: leave the wizard empty

                        int start = matches[i].capturedEnd();
                        int end = ( i + 1 < matches.size() ) ? matches[i + 1].capturedStart() : data.size();
                        QString value = data.mid( start, end - start );

                        Component c;
                        c.ai = ai->ai;
                        QRegularExpressionMatch m = QRegularExpression( "^\\$\\{([^}:]+)(:c)?\\}$" ).match( value );
                        if ( m.hasMatch() )
                        {
                                QString name = m.captured( 1 );
                                c.source = ( mVariableNames.contains( name ) && !mFieldNames.contains( name ) ) ? VARIABLE : MERGE_FIELD;
                                c.value = name;
                        }
                        else if ( value.contains( "${" ) )
                        {
                                return;         // mixed text and fields: too complex for the wizard
                        }
                        else
                        {
                                c.source = EMBEDDED;
                                c.value = value;
                        }
                        parsed << c;
                }
                mComponents = parsed;
        }

}
