//  Gs1.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "Gs1.hpp"

#include <QCoreApplication>
#include <QRegularExpression>


namespace glabels::model::Gs1
{

        namespace
        {
                QString tr( const char* text )
                {
                        return QCoreApplication::translate( "Gs1", text );
                }

                QList<Ai> buildCatalog()
                {
                        using K = Kind;
                        QList<Ai> l;

                        // Identification
                        l << Ai{ "00",  "Identificación de una unidad logística (SSCC)", K::NUMERIC, 18, 18, true };
                        l << Ai{ "01",  "Identificación de un artículo comercial (GTIN)", K::NUMERIC, 14, 14, true };
                        l << Ai{ "02",  "GTIN de los artículos comerciales contenidos en una unidad logística", K::NUMERIC, 14, 14, true };

                        // Batch, dates, variants, serial
                        l << Ai{ "10",  "Número de lote", K::ALNUM, 1, 20, false };
                        l << Ai{ "11",  "Fecha de producción (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "12",  "Fecha de vencimiento del importe de la nómina (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "13",  "Fecha de envasado (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "15",  "Fecha de caducidad (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "16",  "Fecha límite de venta (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "17",  "Fecha de vencimiento (AAMMDD)", K::DATE, 6, 6, false };
                        l << Ai{ "20",  "Variante interna del producto", K::NUMERIC, 2, 2, false };
                        l << Ai{ "21",  "Número de serie", K::ALNUM, 1, 20, false };
                        l << Ai{ "22",  "Variante de productos para clientes", K::ALNUM, 1, 20, false };
                        l << Ai{ "235", "Extensión serializada de GTIN controlada por terceros (TPX)", K::ALNUM, 1, 28, false };
                        l << Ai{ "240", "Identificación adicional del producto asignada por el fabricante", K::ALNUM, 1, 30, false };
                        l << Ai{ "241", "Número de pieza del cliente", K::ALNUM, 1, 30, false };
                        l << Ai{ "242", "Número de variación de producto hecho a pedido", K::NUMERIC, 1, 6, false };
                        l << Ai{ "250", "Número de serie secundario", K::ALNUM, 1, 30, false };
                        l << Ai{ "251", "Referencia a la entidad de origen", K::ALNUM, 1, 30, false };

                        // Quantities and measures
                        l << Ai{ "30",  "Cantidad variable", K::NUMERIC, 1, 8, false };
                        l << Ai{ "37",  "Número de unidades contenidas", K::NUMERIC, 1, 8, false };
                        for ( int n = 0; n <= 5; n++ )
                        {
                                l << Ai{ QString( "310%1" ).arg( n ), QString( "Peso neto, kg (%1 decimales)" ).arg( n ), K::NUMERIC, 6, 6, false };
                        }
                        for ( int n = 0; n <= 5; n++ )
                        {
                                l << Ai{ QString( "320%1" ).arg( n ), QString( "Peso neto, libras (%1 decimales)" ).arg( n ), K::NUMERIC, 6, 6, false };
                        }

                        // Trade and logistics references
                        l << Ai{ "400", "Número de pedido del cliente", K::ALNUM, 1, 30, false };
                        l << Ai{ "401", "Identificador global de envío (GINC)", K::ALNUM, 1, 30, false };
                        l << Ai{ "402", "Número global de envío (GSIN)", K::NUMERIC, 17, 17, true };
                        l << Ai{ "410", "Entregar a (GLN)", K::NUMERIC, 13, 13, true };
                        l << Ai{ "411", "Facturar a (GLN)", K::NUMERIC, 13, 13, true };
                        l << Ai{ "412", "Comprado a (GLN)", K::NUMERIC, 13, 13, true };
                        l << Ai{ "413", "Enviar para (GLN)", K::NUMERIC, 13, 13, true };
                        l << Ai{ "414", "Identificación de una ubicación física (GLN)", K::NUMERIC, 13, 13, true };
                        l << Ai{ "415", "GLN de la parte que factura", K::NUMERIC, 13, 13, true };
                        l << Ai{ "420", "Código postal de destino", K::ALNUM, 1, 20, false };

                        // Assets, services, others
                        l << Ai{ "8004", "Identificador individual de activos (GIAI)", K::ALNUM, 1, 30, false };
                        l << Ai{ "8017", "Relación de servicio, prestador (GSRN)", K::NUMERIC, 18, 18, true };
                        l << Ai{ "8018", "Relación de servicio, destinatario (GSRN)", K::NUMERIC, 18, 18, true };
                        l << Ai{ "8200", "Dirección URL ampliada del paquete", K::ALNUM, 1, 70, false };

                        // Internal use
                        l << Ai{ "90",  "Información entre socios comerciales", K::ALNUM, 1, 30, false };
                        for ( int n = 91; n <= 99; n++ )
                        {
                                l << Ai{ QString::number( n ), "Información interna de la empresa", K::ALNUM, 1, 90, false };
                        }

                        return l;
                }
        }


        const QList<Ai>& aiList()
        {
                static const QList<Ai> catalog = buildCatalog();
                return catalog;
        }


        const Ai* findAi( const QString& ai )
        {
                for ( const Ai& a : aiList() )
                {
                        if ( a.ai == ai )
                        {
                                return &a;
                        }
                }
                return nullptr;
        }


        QString checkDigit( const QString& digits )
        {
                int sum = 0;
                for ( int i = 0; i < digits.size(); i++ )
                {
                        int d = digits[digits.size() - 1 - i].digitValue();
                        sum += d * ( i % 2 == 0 ? 3 : 1 );
                }
                return QString::number( ( 10 - sum % 10 ) % 10 );
        }


        bool hasValidCheckDigit( const QString& digits )
        {
                if ( digits.size() < 2 ) return false;
                return checkDigit( digits.left( digits.size() - 1 ) ) == digits.right( 1 );
        }


        QString formatDescription( const Ai& ai )
        {
                QString kind = ( ai.kind == Kind::ALNUM ) ? tr( "alfanuméricos" ) : tr( "numéricos" );
                if ( ai.isFixed() )
                {
                        return tr( "%1 caracteres %2" ).arg( ai.maxLen ).arg( kind );
                }
                return tr( "Hasta %1 caracteres %2" ).arg( ai.maxLen ).arg( kind );
        }


        QString validate( const Ai& ai, const QString& input, QString* finalValue )
        {
                if ( finalValue ) finalValue->clear();

                if ( input.isEmpty() )
                {
                        return tr( "Escriba un valor." );
                }

                if ( ai.kind == Kind::ALNUM )
                {
                        for ( QChar c : input )
                        {
                                if ( c.unicode() < 32 || c.unicode() > 126 )
                                {
                                        return tr( "Solo se permiten caracteres ASCII imprimibles." );
                                }
                                if ( QString( "[]()^" ).contains( c ) )
                                {
                                        return tr( "No se permiten los caracteres [ ] ( ) ^ en este dato." );
                                }
                        }
                        if ( input.size() > ai.maxLen )
                        {
                                return tr( "Máximo %1 caracteres." ).arg( ai.maxLen );
                        }
                        if ( finalValue ) *finalValue = input;
                        return QString();
                }

                // Numeric and date values
                if ( !QRegularExpression( "^\\d+$" ).match( input ).hasMatch() )
                {
                        return tr( "Solo se permiten dígitos." );
                }

                QString value = input;

                if ( ai.check )
                {
                        if ( input.size() == ai.maxLen - 1 )
                        {
                                value = input + checkDigit( input );   // check digit added automatically
                        }
                        else if ( input.size() == ai.maxLen )
                        {
                                if ( !hasValidCheckDigit( input ) )
                                {
                                        return tr( "El dígito verificador no es correcto (debería ser %1)." )
                                                .arg( checkDigit( input.left( ai.maxLen - 1 ) ) );
                                }
                        }
                        else
                        {
                                return tr( "Escriba %1 dígitos; el dígito verificador se calcula solo." ).arg( ai.maxLen - 1 );
                        }
                }
                else if ( ai.isFixed() )
                {
                        if ( input.size() != ai.maxLen )
                        {
                                return tr( "Debe tener exactamente %1 dígitos." ).arg( ai.maxLen );
                        }
                }
                else if ( input.size() > ai.maxLen )
                {
                        return tr( "Máximo %1 dígitos." ).arg( ai.maxLen );
                }

                if ( ai.kind == Kind::DATE )
                {
                        int month = value.mid( 2, 2 ).toInt();
                        int day   = value.mid( 4, 2 ).toInt();
                        if ( month < 1 || month > 12 || day > 31 )
                        {
                                return tr( "La fecha debe ser AAMMDD con mes 01-12 y día 00-31." );
                        }
                }

                if ( finalValue ) *finalValue = value;
                return QString();
        }

}
