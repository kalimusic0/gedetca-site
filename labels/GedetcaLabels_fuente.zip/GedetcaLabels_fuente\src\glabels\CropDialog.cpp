//  CropDialog.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels).
//

#include "CropDialog.hpp"

#include "UndoRedoModel.hpp"
#include "model/ModelObject.hpp"

#include <QDialogButtonBox>
#include <QGridLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPainter>
#include <QPushButton>
#include <QSvgRenderer>
#include <QVBoxLayout>
#include <QtMath>


namespace glabels
{

        namespace
        {
                const double MAX_CROP = 0.95;      // at least 5% of each side stays
                const double GRAB     = 7.0;       // pixels around an edge that grab it

                enum { EdgeLeft = 1, EdgeTop = 2, EdgeRight = 4, EdgeBottom = 8, MoveAll = 16 };
        }


        //
        // CropWidget
        //
        CropWidget::CropWidget( const QImage& image, const QMarginsF& margins, QWidget* parent )
                : QWidget( parent ), mImage( image ), mMargins( margins )
        {
                setMouseTracking( true );
                setMinimumSize( 420, 320 );
        }


        QSize CropWidget::sizeHint() const
        {
                return QSize( 560, 420 );
        }


        QMarginsF CropWidget::margins() const
        {
                return mMargins;
        }


        void CropWidget::setMargins( const QMarginsF& margins )
        {
                mMargins = margins;
                clampMargins();
                update();
        }


        void CropWidget::clampMargins()
        {
                auto c = []( double v ) { return qBound( 0.0, v, MAX_CROP ); };
                mMargins.setLeft( c( mMargins.left() ) );
                mMargins.setTop( c( mMargins.top() ) );
                mMargins.setRight( c( mMargins.right() ) );
                mMargins.setBottom( c( mMargins.bottom() ) );
                if ( mMargins.left() + mMargins.right() > MAX_CROP )
                {
                        mMargins.setRight( MAX_CROP - mMargins.left() );
                }
                if ( mMargins.top() + mMargins.bottom() > MAX_CROP )
                {
                        mMargins.setBottom( MAX_CROP - mMargins.top() );
                }
        }


        // Where the whole picture is drawn (fit in the widget, keeping proportions)
        QRectF CropWidget::imageRect() const
        {
                const double pad = 12;
                QRectF avail( pad, pad, width() - 2*pad, height() - 2*pad );
                if ( mImage.isNull() || avail.width() <= 0 || avail.height() <= 0 ) return avail;

                double s = qMin( avail.width() / mImage.width(), avail.height() / mImage.height() );
                double w = mImage.width() * s;
                double h = mImage.height() * s;
                return QRectF( avail.center().x() - w/2, avail.center().y() - h/2, w, h );
        }


        QRectF CropWidget::cropRect() const
        {
                QRectF r = imageRect();
                return QRectF( r.left() + mMargins.left() * r.width(),
                               r.top()  + mMargins.top()  * r.height(),
                               r.width()  * ( 1 - mMargins.left() - mMargins.right() ),
                               r.height() * ( 1 - mMargins.top()  - mMargins.bottom() ) );
        }


        int CropWidget::hitTest( const QPointF& p ) const
        {
                QRectF c = cropRect();
                int mode = 0;
                bool inY = p.y() >= c.top() - GRAB && p.y() <= c.bottom() + GRAB;
                bool inX = p.x() >= c.left() - GRAB && p.x() <= c.right() + GRAB;

                if ( inY && qAbs( p.x() - c.left() )   <= GRAB ) mode |= EdgeLeft;
                if ( inY && qAbs( p.x() - c.right() )  <= GRAB ) mode |= EdgeRight;
                if ( inX && qAbs( p.y() - c.top() )    <= GRAB ) mode |= EdgeTop;
                if ( inX && qAbs( p.y() - c.bottom() ) <= GRAB ) mode |= EdgeBottom;

                if ( mode == 0 && c.contains( p ) ) mode = MoveAll;
                return mode;
        }


        void CropWidget::paintEvent( QPaintEvent* )
        {
                QPainter p( this );
                p.fillRect( rect(), palette().window() );

                QRectF img = imageRect();

                // Checkerboard under the picture (shows transparency)
                p.save();
                p.setClipRect( img );
                const int cell = 8;
                for ( int y = 0; y * cell < img.height(); y++ )
                {
                        for ( int x = 0; x * cell < img.width(); x++ )
                        {
                                p.fillRect( QRectF( img.left() + x*cell, img.top() + y*cell, cell, cell ),
                                            ( (x + y) % 2 ) ? QColor( 200, 200, 200 ) : QColor( 235, 235, 235 ) );
                        }
                }
                p.restore();

                if ( !mImage.isNull() )
                {
                        p.setRenderHint( QPainter::SmoothPixmapTransform );
                        p.drawImage( img, mImage );
                }

                // Dim what will be cut
                QRectF c = cropRect();
                QPainterPath cut;
                cut.addRect( img );
                QPainterPath keep;
                keep.addRect( c );
                p.fillPath( cut.subtracted( keep ), QColor( 0, 0, 0, 150 ) );

                // Rectangle and handles
                p.setPen( QPen( QColor( 0, 200, 230 ), 2 ) );
                p.setBrush( Qt::NoBrush );
                p.drawRect( c );

                p.setPen( QPen( Qt::white, 1 ) );
                p.setBrush( QColor( 0, 200, 230 ) );
                const double h = 4;
                QPointF pts[] = { c.topLeft(), QPointF( c.center().x(), c.top() ), c.topRight(),
                                  QPointF( c.left(), c.center().y() ), QPointF( c.right(), c.center().y() ),
                                  c.bottomLeft(), QPointF( c.center().x(), c.bottom() ), c.bottomRight() };
                for ( const QPointF& q : pts )
                {
                        p.drawRect( QRectF( q.x() - h, q.y() - h, 2*h, 2*h ) );
                }
        }


        void CropWidget::mousePressEvent( QMouseEvent* event )
        {
                if ( event->button() == Qt::LeftButton )
                {
                        mDragMode = hitTest( event->position() );
                        mDragStart = event->position();
                        mDragMargins = mMargins;
                }
        }


        void CropWidget::mouseMoveEvent( QMouseEvent* event )
        {
                if ( mDragMode == 0 || !( event->buttons() & Qt::LeftButton ) )
                {
                        int m = hitTest( event->position() );
                        if ( m == MoveAll )                                     setCursor( Qt::SizeAllCursor );
                        else if ( m == ( EdgeLeft | EdgeTop ) || m == ( EdgeRight | EdgeBottom ) ) setCursor( Qt::SizeFDiagCursor );
                        else if ( m == ( EdgeRight | EdgeTop ) || m == ( EdgeLeft | EdgeBottom ) ) setCursor( Qt::SizeBDiagCursor );
                        else if ( m & ( EdgeLeft | EdgeRight ) )                setCursor( Qt::SizeHorCursor );
                        else if ( m & ( EdgeTop | EdgeBottom ) )                setCursor( Qt::SizeVerCursor );
                        else                                                    setCursor( Qt::ArrowCursor );
                        return;
                }

                QRectF img = imageRect();
                if ( img.width() <= 0 || img.height() <= 0 ) return;
                double dx = ( event->position().x() - mDragStart.x() ) / img.width();
                double dy = ( event->position().y() - mDragStart.y() ) / img.height();

                QMarginsF m = mDragMargins;
                if ( mDragMode == MoveAll )
                {
                        // keep the size, slide the rectangle inside the picture
                        dx = qBound( -m.left(), dx, m.right() );
                        dy = qBound( -m.top(),  dy, m.bottom() );
                        m.setLeft( m.left() + dx );  m.setRight( m.right() - dx );
                        m.setTop( m.top() + dy );    m.setBottom( m.bottom() - dy );
                }
                else
                {
                        if ( mDragMode & EdgeLeft )   m.setLeft( m.left() + dx );
                        if ( mDragMode & EdgeRight )  m.setRight( m.right() - dx );
                        if ( mDragMode & EdgeTop )    m.setTop( m.top() + dy );
                        if ( mDragMode & EdgeBottom ) m.setBottom( m.bottom() - dy );
                }
                mMargins = m;
                clampMargins();
                update();
                emit changed();
        }


        void CropWidget::mouseReleaseEvent( QMouseEvent* )
        {
                mDragMode = 0;
        }


        //
        // CropDialog
        //
        CropDialog::CropDialog( const QImage& image, const QMarginsF& margins, QWidget* parent )
                : QDialog( parent )
        {
                setWindowTitle( tr("Crop image") );

                mWidget = new CropWidget( image, margins );

                auto makeSpin = []()
                {
                        auto* s = new QDoubleSpinBox();
                        s->setRange( 0, 95 );
                        s->setDecimals( 1 );
                        s->setSuffix( " %" );
                        return s;
                };
                mLeft = makeSpin();  mTop = makeSpin();  mRight = makeSpin();  mBottom = makeSpin();

                auto* grid = new QGridLayout();
                grid->addWidget( new QLabel( tr("Left:") ),   0, 0 );  grid->addWidget( mLeft,   0, 1 );
                grid->addWidget( new QLabel( tr("Top:") ),    0, 2 );  grid->addWidget( mTop,    0, 3 );
                grid->addWidget( new QLabel( tr("Right:") ),  1, 0 );  grid->addWidget( mRight,  1, 1 );
                grid->addWidget( new QLabel( tr("Bottom:") ), 1, 2 );  grid->addWidget( mBottom, 1, 3 );

                auto* resetButton = new QPushButton( tr("Remove crop") );
                connect( resetButton, &QPushButton::clicked, this, [this]() { mWidget->setMargins( QMarginsF() ); onWidgetChanged(); } );

                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
                connect( buttons, &QDialogButtonBox::accepted, this, &QDialog::accept );
                connect( buttons, &QDialogButtonBox::rejected, this, &QDialog::reject );

                auto* hint = new QLabel( tr("Drag the edges or corners of the rectangle; drag inside to move it.") );
                hint->setWordWrap( true );

                auto* layout = new QVBoxLayout( this );
                layout->addWidget( hint );
                layout->addWidget( mWidget, 1 );
                layout->addLayout( grid );
                layout->addWidget( resetButton, 0, Qt::AlignLeft );
                layout->addWidget( buttons );

                connect( mWidget, &CropWidget::changed, this, &CropDialog::onWidgetChanged );
                for ( QDoubleSpinBox* s : { mLeft, mTop, mRight, mBottom } )
                {
                        connect( s, &QDoubleSpinBox::valueChanged, this, &CropDialog::onSpinsChanged );
                }

                onWidgetChanged();
        }


        QMarginsF CropDialog::margins() const
        {
                return mWidget->margins();
        }


        void CropDialog::onWidgetChanged()
        {
                mBlocked = true;
                QMarginsF m = mWidget->margins();
                mLeft->setValue( m.left() * 100 );
                mTop->setValue( m.top() * 100 );
                mRight->setValue( m.right() * 100 );
                mBottom->setValue( m.bottom() * 100 );
                mBlocked = false;
        }


        void CropDialog::onSpinsChanged()
        {
                if ( mBlocked ) return;
                mWidget->setMargins( QMarginsF( mLeft->value() / 100, mTop->value() / 100,
                                                mRight->value() / 100, mBottom->value() / 100 ) );
                onWidgetChanged();   // show the values after limits
        }


        bool CropDialog::run( QWidget* parent, model::ModelObject* object, UndoRedoModel* undoRedoModel )
        {
                if ( !object ) return false;

                QImage preview = object->image();
                if ( preview.isNull() && !object->svg().isEmpty() )
                {
                        QSvgRenderer r( object->svg() );
                        QSize s = r.defaultSize();
                        if ( s.isEmpty() ) s = QSize( 400, 300 );
                        double k = 800.0 / qMax( s.width(), s.height() );
                        preview = QImage( qMax( 1, int( s.width() * k ) ), qMax( 1, int( s.height() * k ) ),
                                          QImage::Format_ARGB32_Premultiplied );
                        preview.fill( Qt::transparent );
                        QPainter p( &preview );
                        r.render( &p );
                }
                if ( preview.isNull() )
                {
                        return false;   // an image taken from a field has nothing to show here
                }

                CropDialog dialog( preview, object->imageCrop(), parent );
                if ( dialog.exec() != QDialog::Accepted )
                {
                        return false;
                }

                if ( undoRedoModel ) undoRedoModel->checkpoint( tr("Crop") );
                object->setImageCrop( dialog.margins() );
                return true;
        }

}
