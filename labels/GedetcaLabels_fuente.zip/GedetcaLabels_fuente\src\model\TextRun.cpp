//  TextRun.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels).
//

#include "TextRun.hpp"

#include <QStringList>
#include <QUrl>


namespace glabels::model
{

        bool TextRun::isDefault() const
        {
                return bold < 0 && italic < 0 && underline < 0 && size <= 0 && family.isEmpty();
        }


        bool TextRun::sameStyle( const TextRun& o ) const
        {
                return bold == o.bold && italic == o.italic && underline == o.underline &&
                       size == o.size && family == o.family;
        }


        static QString flagToString( int v )
        {
                return v < 0 ? QString("-") : QString::number( v ? 1 : 0 );
        }

        static int flagFromString( const QString& s )
        {
                return s == "1" ? 1 : s == "0" ? 0 : -1;
        }


        QString TextRun::toString( const QList<TextRun>& runs )
        {
                QStringList items;
                for ( const TextRun& r : runs )
                {
                        if ( r.length <= 0 || r.isDefault() ) continue;

                        QStringList f;
                        f << QString::number( r.start )
                          << QString::number( r.length )
                          << flagToString( r.bold )
                          << flagToString( r.italic )
                          << flagToString( r.underline )
                          << ( r.size > 0 ? QString::number( r.size ) : QString("-") )
                          << ( r.family.isEmpty() ? QString("-") : QString::fromLatin1( QUrl::toPercentEncoding( r.family ) ) );
                        items << f.join( "|" );
                }
                return items.join( ";" );
        }


        QList<TextRun> TextRun::fromString( const QString& string )
        {
                QList<TextRun> runs;
                for ( const QString& item : string.split( ';', Qt::SkipEmptyParts ) )
                {
                        QStringList f = item.split( '|' );
                        if ( f.size() < 7 ) continue;

                        TextRun r;
                        r.start     = f[0].toInt();
                        r.length    = f[1].toInt();
                        r.bold      = flagFromString( f[2] );
                        r.italic    = flagFromString( f[3] );
                        r.underline = flagFromString( f[4] );
                        r.size      = f[5] == "-" ? 0 : f[5].toDouble();
                        r.family    = f[6] == "-" ? QString() : QUrl::fromPercentEncoding( f[6].toLatin1() );
                        if ( r.start >= 0 && r.length > 0 ) runs << r;
                }
                return runs;
        }


        TextRun TextRun::styleAt( const QList<TextRun>& runs, int index )
        {
                for ( const TextRun& r : runs )
                {
                        if ( index >= r.start && index < r.start + r.length )
                        {
                                return r;
                        }
                }
                return TextRun();
        }

}
