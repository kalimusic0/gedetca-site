//  FormatToolBar.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "FormatToolBar.hpp"

#include "PositionToolBar.hpp"
#include "UndoRedoModel.hpp"

#include "model/Distance.hpp"
#include "model/Model.hpp"
#include "model/ModelObject.hpp"

#include <QAction>
#include <QColorDialog>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QFontComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QPainter>
#include <QPixmap>
#include <QToolButton>


namespace glabels
{

        namespace
        {
                const double sizes[] = { 5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 60, 72, 96 };
        }


        FormatToolBar::FormatToolBar( QWidget* parent )
                : QToolBar( tr("Format"), parent )
        {
                setMovable( false );
                setIconSize( QSize( 20, 20 ) );

                mFontCombo = new QFontComboBox();
                mFontCombo->setToolTip( tr("Font") );
                mFontCombo->setMaximumWidth( 170 );
                addWidget( mFontCombo );
                connect( mFontCombo, SIGNAL(textActivated(QString)), this, SLOT(onFontFamily(QString)) );

                mSizeCombo = new QComboBox();
                mSizeCombo->setEditable( true );
                mSizeCombo->setToolTip( tr("Font size (pt)") );
                mSizeCombo->setMaximumWidth( 64 );
                for ( double s : sizes )
                {
                        mSizeCombo->addItem( QString::number( s ) );
                }
                addWidget( mSizeCombo );
                connect( mSizeCombo, SIGNAL(activated(int)), this, SLOT(onFontSize()) );
                connect( mSizeCombo->lineEdit(), SIGNAL(editingFinished()), this, SLOT(onFontSize()) );

                mBold = addToggle( "B", tr("Bold") );
                mBold->setStyleSheet( "font-weight: bold;" );
                mItalic = addToggle( "I", tr("Italic") );
                mItalic->setStyleSheet( "font-style: italic;" );
                mUnderline = addToggle( "U", tr("Underline") );
                mUnderline->setStyleSheet( "text-decoration: underline;" );
                connect( mBold,      SIGNAL(clicked(bool)), this, SLOT(onBold(bool)) );
                connect( mItalic,    SIGNAL(clicked(bool)), this, SLOT(onItalic(bool)) );
                connect( mUnderline, SIGNAL(clicked(bool)), this, SLOT(onUnderline(bool)) );

                addSeparator();

                mHAlign[0] = addIconButton( "text-left",   tr("Align text left"),   0, 0 );
                mHAlign[1] = addIconButton( "text-center", tr("Center text"),       0, 1 );
                mHAlign[2] = addIconButton( "text-right",  tr("Align text right"),  0, 2 );
                addSeparator();
                mVAlign[0] = addIconButton( "text-top",    tr("Align text to top"),    1, 0 );
                mVAlign[1] = addIconButton( "text-middle", tr("Align text to middle"), 1, 1 );
                mVAlign[2] = addIconButton( "text-bottom", tr("Align text to bottom"), 1, 2 );

                addSeparator();

                // Colors: click picks a color; the arrow menu of fill/line also offers "none"
                mTextColor = new QToolButton();
                mTextColor->setToolTip( tr("Text color") );
                mTextColor->setText( "A" );
                mTextColor->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
                mTextColor->setFocusPolicy( Qt::NoFocus );
                addWidget( mTextColor );
                connect( mTextColor, SIGNAL(clicked()), this, SLOT(onTextColor()) );

                mFillColor = new QToolButton();
                mFillColor->setToolTip( tr("Fill color") );
                mFillColor->setText( tr("Fill") );
                mFillColor->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
                mFillColor->setPopupMode( QToolButton::MenuButtonPopup );
                auto* fillMenu = new QMenu( mFillColor );
                fillMenu->addAction( tr("No fill"), this, SLOT(onNoFill()) );
                mFillColor->setMenu( fillMenu );
                mFillColor->setFocusPolicy( Qt::NoFocus );
                addWidget( mFillColor );
                connect( mFillColor, SIGNAL(clicked()), this, SLOT(onFillColor()) );

                mLineColor = new QToolButton();
                mLineColor->setToolTip( tr("Line color") );
                mLineColor->setText( tr("Line") );
                mLineColor->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
                mLineColor->setPopupMode( QToolButton::MenuButtonPopup );
                auto* lineMenu = new QMenu( mLineColor );
                lineMenu->addAction( tr("No line"), this, SLOT(onNoLine()) );
                mLineColor->setMenu( lineMenu );
                mLineColor->setFocusPolicy( Qt::NoFocus );
                addWidget( mLineColor );
                connect( mLineColor, SIGNAL(clicked()), this, SLOT(onLineColor()) );

                setEnabled( false );
        }


        QToolButton* FormatToolBar::addToggle( const QString& text, const QString& tip )
        {
                auto* button = new QToolButton();
                button->setText( text );
                button->setToolTip( tip );
                button->setCheckable( true );
                button->setMinimumWidth( 26 );
                button->setFocusPolicy( Qt::NoFocus );
                addWidget( button );
                return button;
        }


        QToolButton* FormatToolBar::addIconButton( const QString& iconName, const QString& tip, int group, int index )
        {
                auto* button = new QToolButton();
                button->setIcon( PositionToolBar::makeIcon( iconName ) );
                button->setToolTip( tip );
                button->setCheckable( true );
                button->setFocusPolicy( Qt::NoFocus );
                addWidget( button );
                if ( group == 0 )
                {
                        connect( button, &QToolButton::clicked, this, [this, index]() { onHAlign( index ); } );
                }
                else
                {
                        connect( button, &QToolButton::clicked, this, [this, index]() { onVAlign( index ); } );
                }
                return button;
        }


        void FormatToolBar::setModel( model::Model* model, UndoRedoModel* undoRedoModel )
        {
                mModel = model;
                mUndoRedoModel = undoRedoModel;

                connect( mModel, SIGNAL(selectionChanged()), this, SLOT(onModelChanged()) );
                connect( mModel, SIGNAL(changed()), this, SLOT(onModelChanged()) );

                onModelChanged();
        }


        void FormatToolBar::setSwatch( QToolButton* button, const QColor& color, bool none )
        {
                QPixmap pix( 16, 16 );
                pix.fill( Qt::transparent );
                QPainter painter( &pix );
                if ( none || color.alpha() == 0 )
                {
                        painter.setPen( QPen( Qt::red, 2 ) );
                        painter.drawRect( 1, 1, 13, 13 );
                        painter.drawLine( 1, 14, 14, 1 );
                }
                else
                {
                        painter.fillRect( 0, 0, 16, 16, color );
                        painter.setPen( Qt::black );
                        painter.drawRect( 0, 0, 15, 15 );
                }
                painter.end();
                button->setIcon( QIcon( pix ) );
        }


        ///
        /// Show the state of the selected objects
        ///
        void FormatToolBar::onModelChanged()
        {
                if ( !mModel || mUpdating )
                {
                        return;
                }
                mUpdating = true;

                auto selection = mModel->getSelection();
                setEnabled( !selection.isEmpty() );

                bool text = mModel->canSelectionText();
                bool fill = mModel->canSelectionFill();
                bool line = mModel->canSelectionLineColor();

                mFontCombo->setEnabled( text );
                mSizeCombo->setEnabled( text );
                mBold->setEnabled( text );
                mItalic->setEnabled( text );
                mUnderline->setEnabled( text );
                for ( int i = 0; i < 3; i++ )
                {
                        mHAlign[i]->setEnabled( text );
                        mVAlign[i]->setEnabled( text );
                }
                mTextColor->setEnabled( text );
                mFillColor->setEnabled( fill );
                mLineColor->setEnabled( line );


                if ( !selection.isEmpty() )
                {
                        model::ModelObject* o = selection.first();

                        if ( text )
                        {
                                mFontCombo->setCurrentFont( QFont( o->fontFamily() ) );
                                if ( !mSizeCombo->lineEdit()->hasFocus() )
                                {
                                        mSizeCombo->setCurrentText( QString::number( o->fontSize(), 'g', 4 ) );
                                }
                                mBold->setChecked( o->fontWeight() >= QFont::DemiBold );
                                mItalic->setChecked( o->fontItalicFlag() );
                                mUnderline->setChecked( o->fontUnderlineFlag() );

                                Qt::Alignment h = o->textHAlign();
                                mHAlign[0]->setChecked( h & Qt::AlignLeft );
                                mHAlign[1]->setChecked( h & Qt::AlignHCenter );
                                mHAlign[2]->setChecked( h & Qt::AlignRight );
                                Qt::Alignment v = o->textVAlign();
                                mVAlign[0]->setChecked( v & Qt::AlignTop );
                                mVAlign[1]->setChecked( v & Qt::AlignVCenter );
                                mVAlign[2]->setChecked( v & Qt::AlignBottom );

                                setSwatch( mTextColor, o->textColorNode().color(), false );
                        }
                        if ( fill )
                        {
                                setSwatch( mFillColor, o->fillColorNode().color(), false );
                        }
                        if ( line )
                        {
                                setSwatch( mLineColor, o->lineColorNode().color(), false );
                        }
                }

                mUpdating = false;
        }


        void FormatToolBar::onFontFamily( const QString& family )
        {
                if ( mUpdating || !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Font") );
                mModel->setSelectionFontFamily( family );
                emit applied();
        }


        void FormatToolBar::onFontSize()
        {
                if ( mUpdating || !mModel ) return;
                bool ok = false;
                double size = mSizeCombo->currentText().toDouble( &ok );
                if ( !ok || size <= 0 ) return;
                mUndoRedoModel->checkpoint( tr("Font size") );
                mModel->setSelectionFontSize( size );
                emit applied();
        }


        void FormatToolBar::onBold( bool on )
        {
                if ( mUpdating || !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Bold") );
                mModel->setSelectionFontWeight( on ? QFont::Bold : QFont::Normal );
                emit applied();
        }


        void FormatToolBar::onItalic( bool on )
        {
                if ( mUpdating || !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Italic") );
                mModel->setSelectionFontItalicFlag( on );
                emit applied();
        }


        void FormatToolBar::onUnderline( bool on )
        {
                if ( mUpdating || !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Underline") );
                mModel->setSelectionFontUnderlineFlag( on );
                emit applied();
        }


        void FormatToolBar::onHAlign( int index )
        {
                if ( mUpdating || !mModel ) return;
                static const Qt::Alignment a[] = { Qt::AlignLeft, Qt::AlignHCenter, Qt::AlignRight };
                mUndoRedoModel->checkpoint( tr("Text alignment") );
                mModel->setSelectionTextHAlign( a[index] );
                emit applied();
        }


        void FormatToolBar::onVAlign( int index )
        {
                if ( mUpdating || !mModel ) return;
                static const Qt::Alignment a[] = { Qt::AlignTop, Qt::AlignVCenter, Qt::AlignBottom };
                mUndoRedoModel->checkpoint( tr("Text alignment") );
                mModel->setSelectionTextVAlign( a[index] );
                emit applied();
        }


        void FormatToolBar::pickColor( bool text, bool fill )
        {
                auto selection = mModel ? mModel->getSelection() : QList<model::ModelObject*>();
                if ( selection.isEmpty() ) return;

                model::ModelObject* o = selection.first();
                QColor current = text ? o->textColorNode().color()
                                      : ( fill ? o->fillColorNode().color() : o->lineColorNode().color() );
                QColor color = QColorDialog::getColor( current, this, text ? tr("Text color")
                                                                           : ( fill ? tr("Fill color") : tr("Line color") ),
                                                       QColorDialog::ShowAlphaChannel );
                if ( !color.isValid() ) return;

                mUndoRedoModel->checkpoint( text ? tr("Text color") : ( fill ? tr("Fill color") : tr("Line color") ) );
                if ( text )      mModel->setSelectionTextColorNode( model::ColorNode( color ) );
                else if ( fill ) mModel->setSelectionFillColorNode( model::ColorNode( color ) );
                else             mModel->setSelectionLineColorNode( model::ColorNode( color ) );
        }


        void FormatToolBar::onTextColor() { pickColor( true,  false ); }
        void FormatToolBar::onFillColor() { pickColor( false, true  ); }
        void FormatToolBar::onLineColor() { pickColor( false, false ); }


        void FormatToolBar::onNoFill()
        {
                if ( !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Fill color") );
                mModel->setSelectionFillColorNode( model::ColorNode( QColor( 0, 0, 0, 0 ) ) );
                emit applied();
        }


        void FormatToolBar::onNoLine()
        {
                if ( !mModel ) return;
                mUndoRedoModel->checkpoint( tr("Line color") );
                mModel->setSelectionLineColorNode( model::ColorNode( QColor( 0, 0, 0, 0 ) ) );
                emit applied();
        }

}
