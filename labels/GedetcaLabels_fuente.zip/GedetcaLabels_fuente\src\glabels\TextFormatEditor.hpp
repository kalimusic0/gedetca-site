//  TextFormatEditor.hpp
//
//  Editor for the data format (text / date / time / number) of a text object.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef TextFormatEditor_hpp
#define TextFormatEditor_hpp


#include "model/TextFormat.hpp"

#include <QCheckBox>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QSpinBox>
#include <QWidget>


namespace glabels
{

        class TextFormatEditor : public QWidget
        {
                Q_OBJECT

        public:
                explicit TextFormatEditor( QWidget* parent = nullptr );

                model::TextFormat format() const;
                void setFormat( const model::TextFormat& format );

                // Literal text of the object, used to build the example line
                void setSampleText( const QString& text );

        signals:
                void changed();

        private slots:
                void onTypeChanged();
                void onListSelectionChanged();
                void onControlsChanged();

        private:
                void rebuildList();
                void updateVisibility();
                void updateExample();

                QString currentLocaleName() const;

                QComboBox*    mTypeCombo;
                QComboBox*    mCaseCombo;
                QComboBox*    mLocaleCombo;
                QListWidget*  mFormatList;
                QLineEdit*    mPatternEdit;
                QCheckBox*    mGroupingCheck;
                QCheckBox*    mLeadingZeroCheck;
                QComboBox*    mPrecisionModeCombo;
                QSpinBox*     mDecimalsSpin;
                QComboBox*    mNegativeCombo;
                QLabel*       mExampleLabel;

                // Row widgets that are shown/hidden depending on the type
                QList<QWidget*> mLocaleRow;
                QList<QWidget*> mDateTimeRow;
                QList<QWidget*> mNumberRow;

                QString       mSampleText;
                bool          mBlocked{ false };
        };

}


#endif // TextFormatEditor_hpp
