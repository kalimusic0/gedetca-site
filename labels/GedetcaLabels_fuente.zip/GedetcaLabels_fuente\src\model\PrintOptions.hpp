//  PrintOptions.hpp
//
//  This file is part of gLabels-qt (Gedetca Labels).

#ifndef model_PrintOptions_hpp
#define model_PrintOptions_hpp


namespace glabels::model
{

        ///
        /// Options that change how labels are drawn when printing (set by the batch front-end)
        ///
        struct PrintOptions
        {
                // Draw without edge smoothing (anti-aliasing): 1-bit thermal printers (203 dpi) get hard black
                // and white dots instead of grey edges that the driver has to dither.
                static bool& noAntialias()
                {
                        static bool value = false;
                        return value;
                }
        };

}


#endif // model_PrintOptions_hpp
