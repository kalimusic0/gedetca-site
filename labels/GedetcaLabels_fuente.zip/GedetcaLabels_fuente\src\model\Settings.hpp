//  Settings.hpp
//
//  Copyright (C) 2016-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef model_Settings_hpp
#define model_Settings_hpp


#include "Distance.hpp"
#include "Units.hpp"

#include <QListView>
#include <QSettings>
#include <QStringList>

#include <memory>


namespace glabels::model
{

        ///
        /// Settings Singleton Class
        ///
        class Settings : public QSettings
        {
                Q_OBJECT

        public:
                enum PageSizeFamily { ISO, US, };
                enum GridOrigin { ORIGIN_TL, ORIGIN_CENTER };
                enum ColorScheme { LIGHT_COLOR_SCHEME, DARK_COLOR_SCHEME, SYSTEM_COLOR_SCHEME };
                enum IconStyle { FLAT_ICON_STYLE, VECTOR_ICON_STYLE };


                /////////////////////////////////
                // Life Cycle
                /////////////////////////////////
        private:
                Settings() = default;

        public:
                static void init();
                static Settings* instance();


                /////////////////////////////////
                // Signals
                /////////////////////////////////
        signals:
                void changed();


                /////////////////////////////////
                // Accessors
                /////////////////////////////////
        public:
                static Units units();
                static void setUnits( Units units );

                static PageSizeFamily preferedPageSizeFamily();
                static void setPreferedPageSizeFamily( PageSizeFamily preferedPageSizeFamily );

                static bool searchIsoPaperSizes();
                static void setSearchIsoPaperSizes( bool searchIsoPaperSizes );

                static bool searchUsPaperSizes();
                static void setSearchUsPaperSizes( bool searchUsPaperSizes );

                static bool searchOtherPaperSizes();
                static void setSearchOtherPaperSizes( bool searchOtherPaperSizes );

                static bool searchAllCategories();
                static void setSearchAllCategories( bool searchAllCategories );

                static QStringList searchCategoryList();
                static void setSearchCategoryList( const QStringList& searchCategoryList );

                static QString exportDirectory();
                static void setExportDirectory( const QString& directory );
                static int exportDpi();
                static void setExportDpi( int dpi );
                static bool exportTransparent();
                static void setExportTransparent( bool transparent );

                static QListView::ViewMode templatePickerMode();
                static void setTemplatePickerMode( QListView::ViewMode viewMode );

                static QStringList recentTemplateList();
                static void addToRecentTemplateList( const QString& name );

                static int maxRecentFiles();
                static QStringList recentFileList();
                static void addToRecentFileList( const QString& filePath );
                static void removeFromRecentFileList( const QString& filePath );

                static QString recentPrinter();
                static void setRecentPrinter( const QString& printer );

                static GridOrigin gridOrigin();
                static void setGridOrigin( GridOrigin origin );

                static Distance gridSpacing();
                static void setGridSpacing( Distance spacing );
                static void resetGridSpacing();

                static ColorScheme colorScheme();
                static void setColorScheme( ColorScheme scheme );

                static IconStyle iconStyle();
                static void setIconStyle( IconStyle style );

                static QString startupPath();
                static void setStartupPath( const QString& path );


        private:
                static std::unique_ptr<Settings> mInstance;
                static const int mMaxRecentFiles{5};

        };

}


#endif // model_Settings_hpp
