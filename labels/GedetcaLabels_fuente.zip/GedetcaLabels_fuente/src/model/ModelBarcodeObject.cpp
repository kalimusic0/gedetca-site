//  ModelBarcodeObject.cpp
//
//  Copyright (C) 2017-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "ModelBarcodeObject.hpp"

#include "Size.hpp"

#include "barcode/Backends.hpp"

#include "glbarcode/Factory.hpp"
#include "glbarcode/QtRenderer.hpp"

#include <QBrush>
#include <QDebug>
#include <QFont>
#include <QFontMetricsF>
#include <QStringList>
#include <QPen>
#include <QRegularExpression>
#include <QTextBlock>
#include <QTextDocument>


//
// Private
//
namespace
{
        using namespace glabels::model;

        const QColor fillColor = QColor( 224, 224, 224, 255 );
        const Distance pad = Distance::pt(4);
        const Distance minW = Distance::pt(18);
        const Distance minH = Distance::mm(4);
        const double MIN_POINT_SIZE = 0.4; // Less than ~0.37 causes issues for QFontMetricsF
}


namespace glabels::model
{
        ///
        /// Constructor
        ///
        ModelBarcodeObject::ModelBarcodeObject()
        {
                mOutline.setOwner( this );

                mHandles.push_back( Handle( this, Handle::NW ) );
                mHandles.push_back( Handle( this, Handle::N ) );
                mHandles.push_back( Handle( this, Handle::NE ) );
                mHandles.push_back( Handle( this, Handle::E ) );
                mHandles.push_back( Handle( this, Handle::SE ) );
                mHandles.push_back( Handle( this, Handle::S ) );
                mHandles.push_back( Handle( this, Handle::SW ) );
                mHandles.push_back( Handle( this, Handle::W ) );

                mBcStyle        = barcode::Backends::defaultStyle();
                mBcTextFlag     = mBcStyle.canText();
                mBcChecksumFlag = mBcStyle.canChecksum();
                mBcFormatDigits = mBcStyle.preferedN();
                mBcData         = "";
                mBcColorNode    = ColorNode( Qt::black );

                update(); // Initialize cached editor layouts
        }


        ///
        /// Constructor
        ///
        ModelBarcodeObject::ModelBarcodeObject( Distance              x0,
                                                Distance              y0,
                                                Distance              w,
                                                Distance              h,
                                                bool                  lockAspectRatio,
                                                const barcode::Style& bcStyle,
                                                bool                  bcTextFlag,
                                                bool                  bcChecksumFlag,
                                                QString               bcData,
                                                const ColorNode&      bcColorNode,
                                                const QTransform&     matrix,
                                                const BarcodeTextOptions& textOptions )
        : ModelObject( x0, y0, w, h, lockAspectRatio, matrix )
        {
                mOutline.setOwner( this );

                mHandles.push_back( Handle( this, Handle::NW ) );
                mHandles.push_back( Handle( this, Handle::N ) );
                mHandles.push_back( Handle( this, Handle::NE ) );
                mHandles.push_back( Handle( this, Handle::E ) );
                mHandles.push_back( Handle( this, Handle::SE ) );
                mHandles.push_back( Handle( this, Handle::S ) );
                mHandles.push_back( Handle( this, Handle::SW ) );
                mHandles.push_back( Handle( this, Handle::W ) );

                mBcStyle        = bcStyle;
                mBcTextFlag     = bcTextFlag;
                mBcChecksumFlag = bcChecksumFlag;
                mBcFormatDigits = mBcStyle.preferedN();
                mBcData         = bcData;
                mBcColorNode    = bcColorNode;
                mBcTextOptions  = textOptions;

                update(); // Initialize cached editor layouts
        }


        ///
        /// Copy constructor
        ///
        ModelBarcodeObject::ModelBarcodeObject( const ModelBarcodeObject* object )
                : ModelObject(object)
        {
                mBcStyle        = object->mBcStyle;
                mBcTextFlag     = object->mBcTextFlag;
                mBcChecksumFlag = object->mBcChecksumFlag;
                mBcFormatDigits = object->mBcFormatDigits;
                mBcData         = object->mBcData;
                mBcColorNode    = object->mBcColorNode;
                mBcTextOptions  = object->mBcTextOptions;

                update(); // Initialize cached editor layouts
        }


        ///
        /// Base of the automatic name
        ///
        QString ModelBarcodeObject::defaultNameBase() const
        {
                return tr("Barcode");
        }


        ///
        /// Other objects read the data of the barcode (fields already replaced)
        ///
        QString ModelBarcodeObject::referenceValue( const merge::Record& record, const Variables& variables, bool formatted ) const
        {
                return mBcData.expand( record, variables );
        }



        ///
        /// Clone
        ///
        ModelBarcodeObject* ModelBarcodeObject::clone() const
        {
                return new ModelBarcodeObject( this );
        }


        ///
        /// bcData Property Getter
        ///
        QString ModelBarcodeObject::bcData() const
        {
                return mBcData.toString();
        }


        ///
        /// bcData Property Setter
        ///
        void ModelBarcodeObject::setBcData( const QString& value )
        {
                if ( mBcData.toString() != value )
                {
                        mBcData = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// bcTextFlag Property Getter
        ///
        bool ModelBarcodeObject::bcTextFlag() const
        {
                return mBcTextFlag;
        }


        ///
        /// bcTextFlag Property Setter
        ///
        void ModelBarcodeObject::setBcTextFlag( bool value )
        {
                if ( mBcTextFlag != value )
                {
                        mBcTextFlag = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// bcTextOptions Property Getter
        ///
        BarcodeTextOptions ModelBarcodeObject::bcTextOptions() const
        {
                return mBcTextOptions;
        }


        ///
        /// bcTextOptions Property Setter
        ///
        void ModelBarcodeObject::setBcTextOptions( const BarcodeTextOptions& value )
        {
                if ( mBcTextOptions != value )
                {
                        mBcTextOptions = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// bcChecksumFlag Property Getter
        ///
        bool ModelBarcodeObject::bcChecksumFlag() const
        {
                return mBcChecksumFlag;
        }


        ///
        /// bcChecksumFlag Property Setter
        ///
        void ModelBarcodeObject::setBcChecksumFlag( bool value )
        {
                if ( mBcChecksumFlag != value )
                {
                        mBcChecksumFlag = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Barcode Color Node Property Getter
        ///
        ColorNode ModelBarcodeObject::bcColorNode() const
        {
                return mBcColorNode;
        }


        ///
        /// Barcode Color Node Property Setter
        ///
        void ModelBarcodeObject::setBcColorNode( const ColorNode& value )
        {
                if ( mBcColorNode != value )
                {
                        mBcColorNode = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Barcode Style Property Getter
        ///
        barcode::Style ModelBarcodeObject::bcStyle() const
        {
                return mBcStyle;
        }


        ///
        /// Barcode Style Property Setter
        ///
        void ModelBarcodeObject::setBcStyle( const barcode::Style& value )
        {
                if ( mBcStyle != value )
                {
                        mBcStyle = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Barcode Format Digits Property Getter
        ///
        int ModelBarcodeObject::bcFormatDigits() const
        {
                return mBcFormatDigits;
        }


        ///
        /// Barcode Format Digits Property Setter
        ///
        void ModelBarcodeObject::setBcFormatDigits( int value )
        {
                if ( mBcFormatDigits != value )
                {
                        mBcFormatDigits = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Draw shadow of object
        ///
        void ModelBarcodeObject::drawShadow( QPainter*            painter,
                                             bool                 inEditor,
                                             const merge::Record& record,
                                             const Variables&     variables ) const
        {
                // Barcodes don't support shadows.
        }


        ///
        /// Draw object itself
        ///
        void ModelBarcodeObject::drawObject( QPainter*            painter,
                                             bool                 inEditor,
                                             const merge::Record& record,
                                             const Variables&     variables ) const
        {
                QColor bcColor = mBcColorNode.color( record, variables );

                if ( inEditor && mBcData.allFieldsResolved( record, variables ) )
                {
                        drawBc( painter, bcColor, record, variables );
                }
                else if ( inEditor )
                {
                        drawBcInEditor( painter, bcColor );
                }
                else
                {
                        drawBc( painter, bcColor, record, variables );
                }
        }


        ///
        /// Path to test for hover condition
        ///
        QPainterPath ModelBarcodeObject::hoverPath( double scale ) const
        {
                return mHoverPath;
        }


        ///
        /// Size updated
        ///
        void ModelBarcodeObject::sizeUpdated()
        {
                update();
        }


        ///
        /// Update cached information for editor view
        ///
        void ModelBarcodeObject::update()
        {
                //
                // Build barcode from data
                //
                mEditorBarcode.reset( glbarcode::Factory::createBarcode( mBcStyle.fullId().toStdString() ) );
                if ( !mEditorBarcode )
                {
                        qWarning() << "Invalid barcode style" << mBcStyle.fullId() << "using \"code39\".";
                        mBcStyle = barcode::Backends::defaultStyle();
                        mEditorBarcode.reset( glbarcode::Factory::createBarcode( mBcStyle.id().toStdString() ) );
                }
                mEditorBarcode->setChecksum(mBcChecksumFlag);
                mEditorBarcode->setShowText( mBcTextFlag && !ownText() );

                mEditorBarcode->build( mBcData.toStdString(), mW.pt(), qMax( minH.pt(), mH.pt() - textHeightPt() ) );

                //
                // Build a place holder barcode to display in editor, if cannot display actual barcode
                //
                mEditorDefaultBarcode.reset( glbarcode::Factory::createBarcode( mBcStyle.fullId().toStdString() ) );
                if ( !mEditorDefaultBarcode )
                {
                        qWarning() << "Invalid barcode style" << mBcStyle.fullId() << "using \"code39\".";
                        mBcStyle = barcode::Backends::defaultStyle();
                        mEditorDefaultBarcode.reset( glbarcode::Factory::createBarcode( mBcStyle.id().toStdString() ) );
                }
                mEditorDefaultBarcode->setChecksum(mBcChecksumFlag);
                mEditorDefaultBarcode->setShowText( mBcTextFlag && !ownText() );

                mEditorDefaultBarcode->build( mBcStyle.defaultDigits().toStdString(), mW.pt(), qMax( minH.pt(), mH.pt() - textHeightPt() ) );

                //
                // Adjust size
                //
                if ( mEditorBarcode->isDataValid() )
                {
                        mW = Distance::pt( mEditorBarcode->width() );
                        mH = Distance::pt( mEditorBarcode->height() + textHeightPt() );
                }
                else
                {
                        mW = Distance::pt( mEditorDefaultBarcode->width() );
                        mH = Distance::pt( mEditorDefaultBarcode->height() + textHeightPt() );
                }

                QPainterPath path;
                path.addRect( 0, 0, mW.pt(), mH.pt() );
                mHoverPath = path;
        }


        ///
        /// Draw barcode in editor from cached information
        ///
        void ModelBarcodeObject::drawBcInEditor( QPainter* painter, const QColor& color ) const
        {
                if ( mBcData.isEmpty() )
                {
                        drawPlaceHolder( painter, color, tr("No barcode data") );
                }
                else if ( mBcData.hasPlaceHolders() )
                {
                        drawPlaceHolder( painter, color, mBcData.toString() );
                }
                else if ( mEditorBarcode->isDataValid() )
                {
                        painter->setPen( QPen( color ) );
                        painter->save();
                        if ( ownText() && mBcTextOptions.above )
                        {
                                painter->translate( 0, textHeightPt() );
                        }
                        glbarcode::QtRenderer renderer(painter);
                        applyTextStyle( renderer );
                        mEditorBarcode->render( renderer );
                        painter->restore();

                        if ( ownText() )
                        {
                                drawOwnText( painter, color, displayText( mBcData.toString() ) );
                        }
                }
                else
                {
                        drawPlaceHolder( painter, color, tr("Invalid barcode data") );
                }
        }


        ///
        /// Draw barcode in final printout or preview
        ///
        void
        ModelBarcodeObject::drawBc( QPainter*            painter,
                                    const QColor&        color,
                                    const merge::Record& record,
                                    const Variables&     variables ) const
        {
                painter->setPen( QPen( color ) );

                glbarcode::Barcode* bc = glbarcode::Factory::createBarcode( mBcStyle.fullId().toStdString() );
                bc->setChecksum(mBcChecksumFlag);
                bc->setShowText( mBcTextFlag && !ownText() );

                const QString data = mBcData.expand( record, variables );
                bc->build( data.toStdString(), mW.pt(), qMax( minH.pt(), mH.pt() - textHeightPt() ) );

                painter->save();
                if ( ownText() && mBcTextOptions.above )
                {
                        painter->translate( 0, textHeightPt() );
                }
                glbarcode::QtRenderer renderer(painter);
                applyTextStyle( renderer );
                bc->render( renderer );
                painter->restore();

                if ( ownText() )
                {
                        drawOwnText( painter, color, displayText( data ) );
                }

                delete bc;
        }


        ///
        /// Is the text drawn by us (with the format of the text options)?
        /// Always for styles that have no text of their own (QR, Data Matrix...), and
        /// for the others when "custom text format" is on.
        ///
        bool ModelBarcodeObject::ownText() const
        {
                return mBcTextFlag && ( !mBcStyle.canText() || ( mBcTextOptions.custom && !keepsOwnLayout() ) );
        }


        ///
        /// EAN/UPC keep their standard layout (long guard bars, first digit outside, split groups)
        /// when a custom text format is on: only the font is replaced.
        ///
        bool ModelBarcodeObject::keepsOwnLayout() const
        {
                const QString id = mBcStyle.id();
                return mBcStyle.canText() && ( id.startsWith( "ean" ) || id.startsWith( "upc" ) );
        }


        ///
        /// Pass the custom font to the barcode's own text (only for the layouts kept above)
        ///
        void ModelBarcodeObject::applyTextStyle( glbarcode::QtRenderer& renderer ) const
        {
                if ( mBcTextFlag && mBcTextOptions.custom && keepsOwnLayout() )
                {
                        const double REF_POINT_SIZE = 5.25;   // size the UPC/EAN digits have by default
                        renderer.setTextStyle( mBcTextOptions.fontFamily,
                                               mBcTextOptions.bold,
                                               mBcTextOptions.italic,
                                               mBcTextOptions.underline,
                                               qMax( MIN_POINT_SIZE, mBcTextOptions.fontSize ) / REF_POINT_SIZE );
                }
        }


        ///
        /// Height reserved for the text band (points)
        ///
        double ModelBarcodeObject::textHeightPt() const
        {
                return ownText() ? mBcTextOptions.fontSize * 1.3 + 1.0 : 0.0;
        }


        ///
        /// Text shown for the data: GS1 data is shown as "(01) 123... (10) ABC"
        ///
        QString ModelBarcodeObject::displayText( const QString& data ) const
        {
                static const QRegularExpression startsGs1( "^[\\[(]\\d{2,4}[\\])]" );
                if ( !startsGs1.match( data ).hasMatch() )
                {
                        return data;
                }

                static const QRegularExpression marker( "[\\[(](\\d{2,4})[\\])]" );
                QList<QRegularExpressionMatch> matches;
                auto it = marker.globalMatch( data );
                while ( it.hasNext() ) matches << it.next();

                QStringList parts;
                for ( int i = 0; i < matches.size(); i++ )
                {
                        int start = matches[i].capturedEnd();
                        int end   = ( i + 1 < matches.size() ) ? matches[i + 1].capturedStart() : data.size();
                        parts << "(" + matches[i].captured( 1 ) + ") " + data.mid( start, end - start );
                }
                return parts.join( " " );
        }


        ///
        /// Draw the text band
        ///
        void ModelBarcodeObject::drawOwnText( QPainter* painter, const QColor& color, const QString& text ) const
        {
                const double bandH = textHeightPt();
                if ( bandH <= 0 || text.isEmpty() )
                {
                        return;
                }

                const BarcodeTextOptions& o = mBcTextOptions;
                const QRectF band( 0, o.above ? 0 : mH.pt() - bandH, mW.pt(), bandH );

                // Measure at a fixed pixel size and scale the painter, so any point size works
                const double REF = 50.0;
                QFont font( o.fontFamily );
                font.setPixelSize( int( REF ) );
                font.setBold( o.bold );
                font.setItalic( o.italic );
                font.setUnderline( o.underline );
                QFontMetricsF fm( font );

                const double refWidth  = fm.horizontalAdvance( text );
                const double refHeight = fm.height();

                double size = qMax( MIN_POINT_SIZE, o.fontSize );
                double sx = 1.0;
                double widthAtSize = refWidth * size / REF;

                if ( o.stretch && widthAtSize > 0 )
                {
                        sx = band.width() / widthAtSize;                       // fill the width (deforms)
                }
                else if ( o.autoShrink && widthAtSize > band.width() && widthAtSize > 0 )
                {
                        size = qMax( MIN_POINT_SIZE, size * band.width() / widthAtSize );   // shrink to fit
                }

                const double s = size / REF;
                const double drawWidth = refWidth * s * sx;

                double x0 = band.left() + ( band.width() - drawWidth ) / 2;
                if ( o.hAlign & Qt::AlignLeft )  x0 = band.left();
                if ( o.hAlign & Qt::AlignRight ) x0 = band.right() - drawWidth;
                const double y0 = band.top() + ( band.height() - refHeight * s ) / 2;

                painter->save();
                painter->setPen( QPen( color ) );
                painter->setFont( font );
                painter->translate( x0, y0 );
                painter->scale( s * sx, s );
                painter->drawText( QPointF( 0, fm.ascent() ), text );
                painter->restore();
        }


        ///
        /// Draw barcode place holder in editor
        ///
        void
        ModelBarcodeObject::drawPlaceHolder( QPainter*      painter,
                                             const QColor&  color,
                                             const QString& text ) const
        {
                QString shortText = text.left( 32 ); // Don't let the text get out of hand

                //
                // Render box
                //
                painter->setPen( Qt::NoPen );
                painter->setBrush( QBrush( fillColor ) );
                painter->drawRect( QRectF( 0, 0, mW.pt(), mH.pt() ) );

                //
                // Render default barcode
                //
                painter->setPen( QPen( color ) );
                glbarcode::QtRenderer renderer(painter);
                mEditorDefaultBarcode->render( renderer );

                //
                // Determine font size for text
                //
                QFont font( "Sans" );
                font.setPointSizeF( 6 );

                QFontMetricsF fm( font );
                QRectF textRect = fm.boundingRect( shortText );

                double wPts = (mW - 2*pad).pt();
                double hPts = (mH - 2*pad).pt();
                if ( (wPts < textRect.width()) || (hPts < textRect.height()) )
                {
                        double scaleX = wPts / textRect.width();
                        double scaleY = hPts / textRect.height();
                        font.setPointSizeF( std::max( 6 * std::min( scaleX, scaleY ), MIN_POINT_SIZE ) );
                }

                //
                // Render hole for text (font size may have changed above)
                //
                fm = QFontMetricsF( font );
                textRect = fm.boundingRect( shortText );

                QRectF holeRect( (mW.pt() - textRect.width())/2 - pad.pt(),
                                 (mH.pt() - textRect.height())/2 - pad.pt(),
                                 textRect.width() + 2*pad.pt(),
                                 textRect.height() + 2*pad.pt() );

                painter->setPen( Qt::NoPen );
                painter->setBrush( QBrush( fillColor ) );
                painter->drawRect( holeRect );

                //
                // Render text
                //
                painter->setFont( font );
                painter->setPen( QPen( color ) );
                painter->drawText( QRectF( 0, 0, mW.pt(), mH.pt() ), Qt::AlignCenter, shortText );
        }


}