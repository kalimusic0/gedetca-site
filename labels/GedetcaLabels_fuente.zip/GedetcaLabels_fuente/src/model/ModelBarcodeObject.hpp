//  ModelBarcodeObject.hpp
//
//  Copyright (C) 2017-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef model_ModelBarcodeObject_hpp
#define model_ModelBarcodeObject_hpp


#include "ModelObject.hpp"

#include "RawText.hpp"

#include "glbarcode/Barcode.hpp"
#include "glbarcode/QtRenderer.hpp"

#include <memory>


namespace glabels::model
{

        ///
        /// Label Model Line Object
        ///
        class ModelBarcodeObject : public ModelObject
        {
                Q_OBJECT

                ///////////////////////////////////////////////////////////////
                // Lifecycle Methods
                ///////////////////////////////////////////////////////////////
        public:
                ModelBarcodeObject();

                ModelBarcodeObject( Distance              x0,
                                    Distance              y0,
                                    Distance              w,
                                    Distance              h,
                                    bool                  lockAspectRatio,
                                    const barcode::Style& bcStyle,
                                    bool                  bcTextFlag,
                                    bool                  bcChecksumFlag,
                                    QString               bcData,
                                    const ColorNode&      bcColorNode,
                                    const QTransform&     matrix = QTransform(),
                                    const BarcodeTextOptions& textOptions = BarcodeTextOptions() );

                ModelBarcodeObject( const ModelBarcodeObject* object );

                virtual ~ModelBarcodeObject() = default;


                ///////////////////////////////////////////////////////////////
                // Object duplication
                ///////////////////////////////////////////////////////////////
                ModelBarcodeObject* clone() const override;

                QString defaultNameBase() const override;
                QString referenceValue( const merge::Record& record, const Variables& variables, bool formatted ) const override;


                ///////////////////////////////////////////////////////////////
                // Property Implementations
                ///////////////////////////////////////////////////////////////
        public:
                //
                // Barcode Property: bcData
                //
                QString bcData() const override;
                void setBcData( const QString &value ) override;


                //
                // Barcode Property: bcTextFlag
                //
                bool bcTextFlag() const override;
                void setBcTextFlag( bool value ) override;


                //
                // Barcode Property: bcChecksumFlag
                //
                bool bcChecksumFlag() const override;
                void setBcChecksumFlag( bool value ) override;


                //
                // Barcode Property: bcTextOptions (format of the human readable text)
                //
                BarcodeTextOptions bcTextOptions() const override;
                void setBcTextOptions( const BarcodeTextOptions& value ) override;


                //
                // Barcode Property: bcColorNode
                //
                ColorNode bcColorNode() const override;
                void setBcColorNode( const ColorNode &value ) override;


                //
                // Barcode Property: bcStyle
                //
                barcode::Style bcStyle() const override;
                void setBcStyle( const barcode::Style &value ) override;


                //
                // Barcode Property: bcFormatDigits
                //
                int bcFormatDigits() const override;
                void setBcFormatDigits( int value ) override;



                ///////////////////////////////////////////////////////////////
                // Capability Implementations
                ///////////////////////////////////////////////////////////////
        public:


                ///////////////////////////////////////////////////////////////
                // Drawing operations
                ///////////////////////////////////////////////////////////////
        protected:
                void drawShadow( QPainter*            painter,
                                 bool                 inEditor,
                                 const merge::Record& record,
                                 const Variables&     variables ) const override;

                void drawObject( QPainter*            painter,
                                 bool                 inEditor,
                                 const merge::Record& record,
                                 const Variables&     variables ) const override;

                QPainterPath hoverPath( double scale ) const override;


                ///////////////////////////////////////////////////////////////
                // Private methods
                ///////////////////////////////////////////////////////////////
        private:
                void sizeUpdated() override;
                void update();

                void drawBcInEditor( QPainter* painter, const QColor& color ) const;

                void drawBc( QPainter*            painter,
                             const QColor&        color,
                             const merge::Record& record,
                             const Variables&     variables ) const;

                void drawPlaceHolder( QPainter* painter, const QColor& color, const QString& text ) const;

                // Own text (font, alignment, fitting) below or above the symbol
                bool    ownText() const;
                bool    keepsOwnLayout() const;
                void    applyTextStyle( glbarcode::QtRenderer& renderer ) const;
                double  textHeightPt() const;
                QString displayText( const QString& data ) const;
                void    drawOwnText( QPainter* painter, const QColor& color, const QString& text ) const;



                ///////////////////////////////////////////////////////////////
                // Private Members
                ///////////////////////////////////////////////////////////////
        private:
                barcode::Style      mBcStyle;
                bool                mBcTextFlag;
                bool                mBcChecksumFlag;
                int                 mBcFormatDigits;
                RawText             mBcData;
                ColorNode           mBcColorNode;
                BarcodeTextOptions  mBcTextOptions;

                std::unique_ptr<glbarcode::Barcode> mEditorBarcode;
                std::unique_ptr<glbarcode::Barcode> mEditorDefaultBarcode;

                QPainterPath mHoverPath;

        };

}


#endif // model_ModelBarcodeObject_hpp
