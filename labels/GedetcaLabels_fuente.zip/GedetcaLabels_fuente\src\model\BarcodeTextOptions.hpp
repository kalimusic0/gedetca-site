//  BarcodeTextOptions.hpp
//
//  Format of the human readable text of a barcode object: font, alignment,
//  position (below / above) and fitting (stretch / shrink), like other texts.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_BarcodeTextOptions_hpp
#define model_BarcodeTextOptions_hpp


#include <QString>
#include <Qt>


namespace glabels::model
{

        class BarcodeTextOptions
        {
        public:
                QString       fontFamily{ "Liberation Sans" };
                double        fontSize{ 8 };               // points
                bool          bold{ false };
                bool          italic{ false };
                bool          underline{ false };
                Qt::Alignment hAlign{ Qt::AlignHCenter };
                bool          above{ false };              // text above the symbol instead of below
                bool          stretch{ false };            // stretch text to fill the width (deforms)
                bool          autoShrink{ true };          // shrink text when it does not fit
                bool          custom{ false };             // use this format also for styles that have their own text

                QString toString() const;
                static BarcodeTextOptions fromString( const QString& s );

                bool operator==( const BarcodeTextOptions& other ) const;
                bool operator!=( const BarcodeTextOptions& other ) const { return !( *this == other ); }
        };

}


#endif // model_BarcodeTextOptions_hpp
