//  PrintFormDialog.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "PrintFormDialog.hpp"

#include "model/ModelObject.hpp"
#include "model/TextFormat.hpp"
#include "model/Variable.hpp"
#include "model/Variables.hpp"

#include <QColorDialog>
#include <QCoreApplication>
#include <QDateTimeEdit>
#include <QDialogButtonBox>
#include <QDoubleValidator>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QScrollArea>
#include <QSpinBox>
#include <QVBoxLayout>


namespace glabels
{

        namespace
        {
                QString T( const char* s )
                {
                        return QCoreApplication::translate( "glabels::PrintFormDialog", s );
                }

                // Formats the dates of the variables are usually written in
                const QStringList dateFormats = {
                        "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd/MM/yyyy", "d/M/yyyy",
                        "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy HH:mm", "dd-MM-yyyy",
                        "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd",
                        "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd",
                        "MM/dd/yyyy", "yyyyMMdd", "yyyyMMddHHmmss",
                        "HH:mm:ss", "HH:mm"
                };

                // Finds the format of a stored value; returns its pattern (empty if unknown)
                QString detectPattern( const QString& value, QDateTime& dt )
                {
                        for ( const QString& f : dateFormats )
                        {
                                QDateTime d = QDateTime::fromString( value.trimmed(), f );
                                if ( d.isValid() )
                                {
                                        dt = d;
                                        return f;
                                }
                        }
                        dt = QDateTime::fromString( value.trimmed(), Qt::ISODate );
                        return QString();
                }

                QString colorToString( const QColor& c )
                {
                        return c.alpha() == 255 ? c.name() : c.name( QColor::HexArgb );
                }

                void paintColorButton( QPushButton* b, const QColor& c )
                {
                        b->setText( colorToString( c ) );
                        b->setProperty( "color", c );
                        b->setStyleSheet( QString( "QPushButton { background-color: %1; color: %2; }" )
                                          .arg( c.name() )
                                          .arg( c.lightness() < 128 ? "white" : "black" ) );
                }
        }


        QStringList PrintFormDialog::usedVariables( model::Model* model )
        {
                static const QRegularExpression re( "\\$\\{([A-Za-z_][A-Za-z_0-9]*)" );

                QStringList names;
                auto scan = [&]( const QString& text )
                {
                        auto it = re.globalMatch( text );
                        while ( it.hasNext() )
                        {
                                QString n = it.next().captured( 1 );
                                if ( model->variables().hasVariable( n ) && !names.contains( n ) )
                                {
                                        names << n;
                                }
                        }
                };

                for ( model::ModelObject* object : model->objectList() )
                {
                        scan( object->text() );
                        scan( object->bcData() );
                        if ( object->filenameNode().isField() )
                        {
                                scan( "${" + object->filenameNode().data() + "}" );
                        }
                        // A text that takes the value of a variable by name
                        if ( !object->textSourceName().isEmpty() )
                        {
                                scan( "${" + object->textSourceName() + "}" );
                        }
                }

                return names;
        }


        PrintFormDialog::PrintFormDialog( model::Model* model, QWidget* parent )
                : QDialog( parent ), mModel( model )
        {
                setWindowTitle( T( "Data entry form" ) );
                setMinimumWidth( 520 );

                // The format of each variable comes from the objects that show it
                QMap<QString,model::TextFormat> formats;
                static const QRegularExpression re( "\\$\\{([A-Za-z_][A-Za-z_0-9]*)" );
                for ( model::ModelObject* object : model->objectList() )
                {
                        model::TextFormat f = object->textFormat();
                        if ( f.type == model::TextFormat::TEXT ) continue;
                        auto it = re.globalMatch( object->text() );
                        while ( it.hasNext() )
                        {
                                QString n = it.next().captured( 1 );
                                if ( !formats.contains( n ) ) formats.insert( n, f );
                        }
                }

                auto* layout = new QVBoxLayout( this );
                auto* intro = new QLabel( T( "Type the values to print. The preview changes when you accept." ) );
                intro->setWordWrap( true );
                layout->addWidget( intro );

                QStringList names = usedVariables( model );
                if ( names.isEmpty() )
                {
                        layout->addWidget( new QLabel( T( "This label does not use any variable." ) ) );
                }
                else
                {
                        auto* grid = new QGridLayout();
                        grid->setColumnStretch( 2, 1 );
                        grid->setHorizontalSpacing( 14 );
                        grid->addWidget( new QLabel( "<b>" + T( "Variable" ) + "</b>" ), 0, 0 );
                        grid->addWidget( new QLabel( "<b>" + T( "Format" ) + "</b>" ), 0, 1 );
                        grid->addWidget( new QLabel( "<b>" + T( "Value" ) + "</b>" ), 0, 2 );

                        int r = 1;
                        for ( const QString& name : names )
                        {
                                model::Variable var = model->variables().value( name );
                                Row row;
                                row.name     = name;
                                row.original = var.initialValue();

                                QString formatText;
                                model::TextFormat f = formats.value( name );
                                bool hasFormat = formats.contains( name );

                                if ( hasFormat && ( f.type == model::TextFormat::DATE || f.type == model::TextFormat::TIME ) )
                                {
                                        bool hasTime = f.pattern.contains( QRegularExpression( "[Hhms]" ) );
                                        bool hasDate = f.pattern.contains( QRegularExpression( "[dMy]" ) );
                                        if ( f.type == model::TextFormat::TIME && !hasDate ) row.kind = TIME;
                                        else if ( hasTime && hasDate )                         row.kind = DATETIME;
                                        else                                                   row.kind = ( f.type == model::TextFormat::TIME ) ? TIME : DATE;
                                        formatText = ( row.kind == TIME ? T( "Time" ) : row.kind == DATETIME ? T( "Date and time" ) : T( "Date" ) )
                                                     + " (" + f.pattern + ")";
                                }
                                else if ( hasFormat && f.type == model::TextFormat::NUMBER )
                                {
                                        row.kind = NUMBER;
                                        formatText = T( "Number" );
                                }
                                else if ( var.type() == model::Variable::Type::INTEGER )
                                {
                                        row.kind = INTEGER;
                                        formatText = T( "Integer" );
                                }
                                else if ( var.type() == model::Variable::Type::FLOATING_POINT )
                                {
                                        row.kind = DECIMAL;
                                        formatText = T( "Decimal" );
                                }
                                else if ( var.type() == model::Variable::Type::COLOR )
                                {
                                        row.kind = COLOR;
                                        formatText = T( "Color" );
                                }
                                else
                                {
                                        formatText = T( "Text" );
                                }

                                switch ( row.kind )
                                {
                                case DATE:
                                case TIME:
                                case DATETIME:
                                {
                                        QDateTime dt;
                                        QString pattern = detectPattern( row.original, dt );
                                        if ( !dt.isValid() ) dt = QDateTime::currentDateTime();
                                        row.datePattern = !pattern.isEmpty() ? pattern
                                                        : row.kind == TIME     ? "HH:mm:ss"
                                                        : row.kind == DATETIME ? "dd/MM/yyyy HH:mm:ss"
                                                                               : "dd/MM/yyyy";
                                        auto* edit = new QDateTimeEdit( dt );
                                        if ( row.kind == DATE )
                                        {
                                                edit->setDisplayFormat( "dd/MM/yyyy" );
                                                edit->setCalendarPopup( true );
                                        }
                                        else if ( row.kind == TIME )
                                        {
                                                edit->setDisplayFormat( "HH:mm:ss" );
                                        }
                                        else
                                        {
                                                edit->setDisplayFormat( "dd/MM/yyyy HH:mm:ss" );
                                                edit->setCalendarPopup( true );
                                        }
                                        row.editor = edit;
                                        break;
                                }
                                case INTEGER:
                                {
                                        auto* spin = new QSpinBox();
                                        spin->setRange( INT_MIN, INT_MAX );
                                        spin->setValue( row.original.toInt() );
                                        row.editor = spin;
                                        break;
                                }
                                case COLOR:
                                {
                                        auto* button = new QPushButton();
                                        paintColorButton( button, QColor( row.original ) );
                                        connect( button, &QPushButton::clicked, button, [button]()
                                        {
                                                QColor c = QColorDialog::getColor( button->property( "color" ).value<QColor>(), button );
                                                if ( c.isValid() ) paintColorButton( button, c );
                                        } );
                                        row.editor = button;
                                        break;
                                }
                                default:
                                {
                                        auto* edit = new QLineEdit( row.original );
                                        if ( row.kind == DECIMAL || row.kind == NUMBER )
                                        {
                                                auto* v = new QDoubleValidator( edit );
                                                v->setNotation( QDoubleValidator::StandardNotation );
                                                edit->setValidator( v );
                                        }
                                        row.editor = edit;
                                        break;
                                }
                                }

                                grid->addWidget( new QLabel( name ), r, 0 );
                                auto* formatLabel = new QLabel( formatText );
                                formatLabel->setEnabled( false );
                                grid->addWidget( formatLabel, r, 1 );
                                grid->addWidget( row.editor, r, 2 );
                                mRows << row;
                                r++;
                        }

                        auto* holder = new QWidget();
                        holder->setLayout( grid );
                        auto* scroll = new QScrollArea();
                        scroll->setWidgetResizable( true );
                        scroll->setFrameShape( QFrame::NoFrame );
                        scroll->setWidget( holder );
                        scroll->setMinimumHeight( qMin( 80 + 38*int( mRows.size() ), 420 ) );
                        layout->addWidget( scroll, 1 );
                }

                auto* buttons = new QDialogButtonBox();
                auto* ok     = buttons->addButton( T( "OK" ),     QDialogButtonBox::AcceptRole );
                auto* cancel = buttons->addButton( T( "Cancel" ), QDialogButtonBox::RejectRole );
                ok->setDefault( true );
                connect( ok,     &QPushButton::clicked, this, &QDialog::accept );
                connect( cancel, &QPushButton::clicked, this, &QDialog::reject );
                layout->addWidget( buttons );
        }


        QString PrintFormDialog::valueOf( const Row& row ) const
        {
                switch ( row.kind )
                {
                case DATE:
                case TIME:
                case DATETIME:
                        return static_cast<QDateTimeEdit*>( row.editor )->dateTime().toString( row.datePattern );
                case INTEGER:
                        return QString::number( static_cast<QSpinBox*>( row.editor )->value() );
                case COLOR:
                        return colorToString( row.editor->property( "color" ).value<QColor>() );
                default:
                        return static_cast<QLineEdit*>( row.editor )->text();
                }
        }


        void PrintFormDialog::applyValues()
        {
                for ( const Row& row : mRows )
                {
                        QString value = valueOf( row );
                        if ( value == row.original )
                        {
                                continue;
                        }
                        model::Variable v = mModel->variables().value( row.name );
                        v.setInitialValue( value );
                        mModel->variables().replaceVariable( row.name, v );
                }
        }

}
