//  BarcodeTextOptions.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "BarcodeTextOptions.hpp"

#include <QStringList>
#include <QUrl>


namespace glabels::model
{

        QString BarcodeTextOptions::toString() const
        {
                // Do not chain QString::arg() with percent-encoded text (it corrupts it)
                QStringList parts;
                parts << QString::fromLatin1( QUrl::toPercentEncoding( fontFamily ) )
                      << QString::number( fontSize, 'g', 6 )
                      << QString::number( bold ? 1 : 0 )
                      << QString::number( italic ? 1 : 0 )
                      << QString::number( underline ? 1 : 0 )
                      << QString::number( int( hAlign ) )
                      << QString::number( above ? 1 : 0 )
                      << QString::number( stretch ? 1 : 0 )
                      << QString::number( autoShrink ? 1 : 0 )
                      << QString::number( custom ? 1 : 0 );
                return parts.join( ';' );
        }


        BarcodeTextOptions BarcodeTextOptions::fromString( const QString& s )
        {
                BarcodeTextOptions o;
                QStringList p = s.split( ';' );
                if ( p.size() >= 10 )
                {
                        o.fontFamily = QUrl::fromPercentEncoding( p[0].toLatin1() );
                        if ( o.fontFamily.isEmpty() ) o.fontFamily = "Liberation Sans";
                        o.fontSize   = qBound( 1.0, p[1].toDouble(), 200.0 );
                        o.bold       = p[2].toInt() != 0;
                        o.italic     = p[3].toInt() != 0;
                        o.underline  = p[4].toInt() != 0;
                        int a        = p[5].toInt();
                        o.hAlign     = ( a & Qt::AlignLeft ) ? Qt::AlignLeft
                                     : ( a & Qt::AlignRight ) ? Qt::AlignRight : Qt::AlignHCenter;
                        o.above      = p[6].toInt() != 0;
                        o.stretch    = p[7].toInt() != 0;
                        o.autoShrink = p[8].toInt() != 0;
                        o.custom     = p[9].toInt() != 0;
                }
                return o;
        }


        bool BarcodeTextOptions::operator==( const BarcodeTextOptions& o ) const
        {
                return toString() == o.toString();
        }

}
