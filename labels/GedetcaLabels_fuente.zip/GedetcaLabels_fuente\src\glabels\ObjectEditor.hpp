//  ObjectEditor.hpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef ObjectEditor_hpp
#define ObjectEditor_hpp


#include "ui_ObjectEditor.h"

#include "model/Model.hpp"
#include "model/ModelObject.hpp"

#include "BarcodeTextEditor.hpp"
#include "TextFormatEditor.hpp"
#include "TextTransformEditor.hpp"
#include <QButtonGroup>
#include <QDoubleSpinBox>
#include <QFontComboBox>
#include <QToolButton>
#include <QGroupBox>
#include <QLineEdit>
#include <QPushButton>


namespace glabels
{

        // Forward references
        class UndoRedoModel;


        ///
        /// Object Editor Widget
        ///
        class ObjectEditor : public QWidget, public Ui_ObjectEditor
        {
                Q_OBJECT


                /////////////////////////////////
                // Life Cycle
                /////////////////////////////////
        public:
                ObjectEditor( QWidget *parent = nullptr );


                /////////////////////////////////
                // Public methods
                /////////////////////////////////
                void setModel( model::Model* model, UndoRedoModel* undoRedoModel );

                // Compact: only the title and the name of the object (the rest opens in a window)
                void setCompact( bool compact );


                /////////////////////////////////
                // Private methods
                /////////////////////////////////
        private:
                void hidePages();
                void loadImagePage();
                void loadLineFillPage();
                void loadPositionPage();
                void loadRectSizePage();
                void loadLineSizePage();
                void loadTextPage();
                void loadBarcodePage();
                void loadShadowPage();


                /////////////////////////////////
                // Slots
                /////////////////////////////////
        private slots:
                void onSettingsChanged();
                void onLabelSizeChanged();
                void onSelectionChanged();
                void onFieldsAvailableChanged();
                void onObjectChanged();
                void onObjectMoved();
                void onObjectDestroyed();
                void onLineControlsChanged();
                void onFillControlsChanged();
                void onImageFileButtonClicked();
                void onImageKeySelected( QString key );
                void onImageCropChanged();
                void onImageCropDialog();
                void onImageCropClear();
                void onPositionControlsChanged();
                void onRectSizeControlsChanged();
                void onLineSizeControlsChanged();
                void onTextControlsChanged();
                void onSelectionBold( bool on );
                void onSelectionItalic( bool on );
                void onSelectionUnderline( bool on );
                void onSelectionFont( const QFont& font );
                void onSelectionSize( double size );
                void onSelectionClear();
                void onEditorCharFormatChanged( const QTextCharFormat& format );
                void onTextFormatChanged();
                void onTextInsertFieldKeySelected( QString key );
                void onBarcodeControlsChanged();
                void onBarcodeInsertFieldKeySelected( QString key );
                void onBarcodeGs1Wizard();
                void onBarcodeTextChanged();
                void onNameEdited();
                void onResetImageSize();
                void onShadowControlsChanged();
                void onChanged();


                /////////////////////////////////
                // Private data
                /////////////////////////////////
        private:
                void loadTextEdit();
                void updateEditorBaseFont();
                QString collectTextRuns() const;

                QDoubleSpinBox*          mCropSpin[4]{ nullptr, nullptr, nullptr, nullptr };
                QToolButton*             mSelBold{ nullptr };
                QToolButton*             mSelItalic{ nullptr };
                QToolButton*             mSelUnderline{ nullptr };
                QFontComboBox*           mSelFont{ nullptr };
                QDoubleSpinBox*          mSelSize{ nullptr };
                double                   mEditorScale{ 1.0 };   // editor points per label point

                model::Model*            mModel;
                model::ModelObject*      mObject;
                UndoRedoModel*           mUndoRedoModel;

                model::Units             mUnits;
                int                      mSpinDigits;
                double                   mSpinStep;

                QButtonGroup*            textHAlignGroup;
                QButtonGroup*            textVAlignGroup;

                QString                  mImageCwd;

                bool                     mBlocked;
                TextFormatEditor*        textFormatEditor;
                TextTransformEditor*     textTransformEditor;
                QPushButton*             barcodeGs1Button;
                QLineEdit*               nameEdit;
                void                     loadNameRow();
                QGroupBox*               barcodeTextGroup;
                BarcodeTextEditor*       barcodeTextEditor;

        };

}


#endif // ObjectEditor_hpp
