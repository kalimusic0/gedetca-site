//  PositionToolBar.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "PositionToolBar.hpp"

#include <QPainter>
#include <QPixmap>
#include <QSvgRenderer>
#include <cmath>


namespace glabels
{

        namespace
        {
                const char* DARK = "#1c1c1c";
                const char* BLUE = "#1f7ae0";

                // Outline box
                QString box( double x, double y, double w, double h )
                {
                        return QString( "<rect x='%1' y='%2' width='%3' height='%4' fill='white' stroke='%5' stroke-width='1.6'/>" )
                                .arg( x ).arg( y ).arg( w ).arg( h ).arg( DARK );
                }

                // Solid guide bar
                QString bar( double x, double y, double w, double h )
                {
                        return QString( "<rect x='%1' y='%2' width='%3' height='%4' fill='%5'/>" )
                                .arg( x ).arg( y ).arg( w ).arg( h ).arg( DARK );
                }

                // Blue arrow from (x1,y1) to (x2,y2)
                QString arrow( double x1, double y1, double x2, double y2 )
                {
                        double dx = x2 - x1, dy = y2 - y1;
                        double len = std::sqrt( dx*dx + dy*dy );
                        double ux = dx / len, uy = dy / len;
                        double hl = 6.0, hw = 3.6;
                        double bx = x2 - ux * hl, by = y2 - uy * hl;
                        return QString( "<line x1='%1' y1='%2' x2='%3' y2='%4' stroke='%5' stroke-width='2.2'/>"
                                        "<polygon points='%6,%7 %8,%9 %10,%11' fill='%5'/>" )
                                .arg( x1 ).arg( y1 ).arg( bx ).arg( by ).arg( BLUE )
                                .arg( x2 ).arg( y2 )
                                .arg( bx - uy * hw ).arg( by + ux * hw )
                                .arg( bx + uy * hw ).arg( by - ux * hw );
                }

                // Rotation icon: arc with arrow head and a label
                QString rotation( bool clockwise, const QString& label, double sweepDegs )
                {
                        // Arc centered on (16,13), radius 9, starting at top
                        const double cx = 16, cy = 12, r = 9;
                        double a0 = -90.0;                              // start (top)
                        double a1 = clockwise ? a0 + sweepDegs : a0 - sweepDegs;
                        auto pt = [&]( double a ) {
                                double rad = a * M_PI / 180.0;
                                return QPointF( cx + r * std::cos( rad ), cy + r * std::sin( rad ) );
                        };
                        QPointF p0 = pt( a0 ), p1 = pt( a1 );
                        int large = sweepDegs > 180.0 ? 1 : 0;
                        int sweep = clockwise ? 1 : 0;

                        // Arrow head at p1, tangent direction
                        double rad1 = a1 * M_PI / 180.0;
                        double tx = clockwise ? -std::sin( rad1 ) :  std::sin( rad1 );
                        double ty = clockwise ?  std::cos( rad1 ) : -std::cos( rad1 );
                        double hl = 7.0, hw = 4.5;
                        QPointF tip( p1.x() + tx * 3.0, p1.y() + ty * 3.0 );
                        double bx = tip.x() - tx * hl, by = tip.y() - ty * hl;

                        return QString( "<path d='M %1 %2 A %3 %3 0 %4 %5 %6 %7' fill='none' stroke='%8' stroke-width='3'/>"
                                        "<polygon points='%9,%10 %11,%12 %13,%14' fill='%8'/>"
                                        "<text x='16' y='30' font-family='Arial' font-weight='bold' font-size='10.5' "
                                        "text-anchor='middle' fill='%15'>%16</text>" )
                                .arg( p0.x() ).arg( p0.y() ).arg( r ).arg( large ).arg( sweep )
                                .arg( p1.x() ).arg( p1.y() ).arg( BLUE )
                                .arg( tip.x() ).arg( tip.y() )
                                .arg( bx - ty * hw ).arg( by + tx * hw )
                                .arg( bx + ty * hw ).arg( by - tx * hw )
                                .arg( DARK ).arg( label );
                }

                QString svgBody( const QString& name )
                {
                        if ( name == "align-left" )
                                return bar( 3, 3, 2, 26 ) + box( 7, 6, 18, 8 ) + box( 7, 18, 11, 8 ) +
                                       arrow( 22, 10, 8, 10 ) + arrow( 16, 22, 8, 22 );
                        if ( name == "align-right" )
                                return bar( 27, 3, 2, 26 ) + box( 7, 6, 18, 8 ) + box( 14, 18, 11, 8 ) +
                                       arrow( 10, 10, 24, 10 ) + arrow( 16, 22, 24, 22 );
                        if ( name == "align-top" )
                                return bar( 3, 3, 26, 2 ) + box( 6, 7, 8, 18 ) + box( 18, 7, 8, 11 ) +
                                       arrow( 10, 22, 10, 8 ) + arrow( 22, 16, 22, 8 );
                        if ( name == "align-bottom" )
                                return bar( 3, 27, 26, 2 ) + box( 6, 7, 8, 18 ) + box( 18, 14, 8, 11 ) +
                                       arrow( 10, 10, 10, 24 ) + arrow( 22, 16, 22, 24 );
                        if ( name == "align-hcenter" )
                                return bar( 15, 3, 2, 26 ) + box( 5, 6, 22, 8 ) + box( 10, 18, 12, 8 ) +
                                       arrow( 4, 10, 14, 10 ) + arrow( 28, 22, 18, 22 );
                        if ( name == "align-vcenter" )
                                return bar( 3, 15, 26, 2 ) + box( 6, 5, 8, 22 ) + box( 18, 10, 8, 12 ) +
                                       arrow( 10, 4, 10, 14 ) + arrow( 22, 28, 22, 18 );
                        if ( name == "center-horiz" )
                                return bar( 2, 3, 2, 26 ) + bar( 28, 3, 2, 26 ) + box( 12, 9, 8, 14 ) +
                                       arrow( 5, 16, 12, 16 ) + arrow( 27, 16, 20, 16 );
                        if ( name == "center-vert" )
                                return bar( 3, 2, 26, 2 ) + bar( 3, 28, 26, 2 ) + box( 9, 12, 14, 8 ) +
                                       arrow( 16, 5, 16, 12 ) + arrow( 16, 27, 16, 20 );
                        if ( name == "center-both" )
                                return box( 11, 11, 10, 10 ) +
                                       arrow( 16, 2, 16, 10 ) + arrow( 16, 30, 16, 22 ) +
                                       arrow( 2, 16, 10, 16 ) + arrow( 30, 16, 22, 16 );
                        if ( name == "space-horiz" )
                                return bar( 2, 3, 2, 26 ) + bar( 28, 3, 2, 26 ) + box( 8, 9, 5, 14 ) + box( 19, 9, 5, 14 ) +
                                       arrow( 4, 16, 8, 16 ) + arrow( 13, 16, 19, 16 ) + arrow( 24, 16, 28, 16 );
                        if ( name == "space-vert" )
                                return bar( 3, 2, 26, 2 ) + bar( 3, 28, 26, 2 ) + box( 9, 8, 14, 5 ) + box( 9, 19, 14, 5 ) +
                                       arrow( 16, 4, 16, 8 ) + arrow( 16, 13, 16, 19 ) + arrow( 16, 24, 16, 28 );
                        if ( name == "fit-label" )
                                return "<rect x='2' y='6' width='28' height='20' rx='3' fill='none' stroke='#333' stroke-width='2' stroke-dasharray='3 2'/>" +
                                       box( 9, 11, 14, 10 ) +
                                       arrow( 2, 16, 8, 16 ) + arrow( 30, 16, 24, 16 );
                        if ( name == "fit-design" )
                                return "<rect x='2' y='4' width='28' height='24' rx='3' fill='none' stroke='#333' stroke-width='2'/>" +
                                       box( 12, 12, 8, 8 ) +
                                       arrow( 8, 8, 12, 12 ) + arrow( 24, 8, 20, 12 ) +
                                       arrow( 8, 24, 12, 20 ) + arrow( 24, 24, 20, 20 );
                        if ( name == "text-left" )
                                return bar( 4, 6, 24, 3 ) + bar( 4, 12, 14, 3 ) + bar( 4, 18, 24, 3 ) + bar( 4, 24, 14, 3 );
                        if ( name == "text-center" )
                                return bar( 4, 6, 24, 3 ) + bar( 9, 12, 14, 3 ) + bar( 4, 18, 24, 3 ) + bar( 9, 24, 14, 3 );
                        if ( name == "text-right" )
                                return bar( 4, 6, 24, 3 ) + bar( 14, 12, 14, 3 ) + bar( 4, 18, 24, 3 ) + bar( 14, 24, 14, 3 );
                        if ( name == "text-top" )
                                return "<rect x='3' y='3' width='26' height='26' fill='none' stroke='#888' stroke-width='1.5'/>" +
                                       bar( 7, 6, 18, 3 ) + bar( 7, 11, 12, 3 );
                        if ( name == "text-middle" )
                                return "<rect x='3' y='3' width='26' height='26' fill='none' stroke='#888' stroke-width='1.5'/>" +
                                       bar( 7, 11, 18, 3 ) + bar( 7, 16, 12, 3 );
                        if ( name == "text-bottom" )
                                return "<rect x='3' y='3' width='26' height='26' fill='none' stroke='#888' stroke-width='1.5'/>" +
                                       bar( 7, 18, 18, 3 ) + bar( 7, 23, 12, 3 );
                        if ( name == "same-width" )
                                return box( 3, 6, 26, 8 ) + box( 9, 18, 14, 8 ) +
                                       arrow( 9, 22, 3, 22 ) + arrow( 23, 22, 29, 22 );
                        if ( name == "same-height" )
                                return box( 6, 3, 8, 26 ) + box( 18, 9, 8, 14 ) +
                                       arrow( 22, 9, 22, 3 ) + arrow( 22, 23, 22, 29 );
                        if ( name == "rotate-left-90" )  return rotation( false, "90°", 270 );
                        if ( name == "rotate-right-90" ) return rotation( true,  "90°", 270 );
                        if ( name == "rotate-180" )      return rotation( true,  "180°", 180 );
                        if ( name == "rotate-left-1" )   return rotation( false, "1°", 270 );
                        if ( name == "rotate-right-1" )  return rotation( true,  "1°", 270 );
                        return {};
                }
        }


        QIcon PositionToolBar::makeIcon( const QString& name )
        {
                QString svg = QString( "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'>%1</svg>" )
                        .arg( svgBody( name ) );
                QSvgRenderer renderer( svg.toUtf8() );

                QIcon icon;
                for ( int s : { 32, 48, 64 } )
                {
                        QPixmap pix( s, s );
                        pix.fill( Qt::transparent );
                        QPainter painter( &pix );
                        painter.setRenderHint( QPainter::Antialiasing );
                        renderer.render( &painter );
                        painter.end();
                        icon.addPixmap( pix );
                }
                return icon;
        }


        PositionToolBar::PositionToolBar( QWidget* parent )
                : QToolBar( tr("Position"), parent )
        {
                setOrientation( Qt::Vertical );
                setIconSize( QSize( 34, 34 ) );
                setToolButtonStyle( Qt::ToolButtonIconOnly );
                setMovable( false );
        }


        QAction* PositionToolBar::addMirror( const QString& iconName, const QString& toolTip, QAction* target )
        {
                QAction* a = addAction( makeIcon( iconName ), toolTip );
                a->setStatusTip( toolTip );
                a->setEnabled( target->isEnabled() );
                connect( a, &QAction::triggered, target, &QAction::trigger );
                connect( target, &QAction::changed, a, [a, target]() { a->setEnabled( target->isEnabled() ); } );
                return a;
        }

}
