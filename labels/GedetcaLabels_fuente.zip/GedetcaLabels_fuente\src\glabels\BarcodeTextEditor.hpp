//  BarcodeTextEditor.hpp
//
//  Controls for the format of the human readable text of a barcode:
//  font, size, bold/italic/underline, alignment, position and fitting.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef BarcodeTextEditor_hpp
#define BarcodeTextEditor_hpp


#include "model/BarcodeTextOptions.hpp"

#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QFontComboBox>
#include <QToolButton>
#include <QWidget>


namespace glabels
{

        class BarcodeTextEditor : public QWidget
        {
                Q_OBJECT

        public:
                explicit BarcodeTextEditor( QWidget* parent = nullptr );

                model::BarcodeTextOptions options() const;

                // 'canCustomize': the style has its own text, so the format must be switched on
                void setOptions( const model::BarcodeTextOptions& options, bool canCustomize );

        signals:
                void changed();

        private slots:
                void onControlsChanged();

        private:
                void updateEnabled();

                QCheckBox*       mCustomCheck;
                QFontComboBox*   mFontCombo;
                QDoubleSpinBox*  mSizeSpin;
                QToolButton*     mBoldButton;
                QToolButton*     mItalicButton;
                QToolButton*     mUnderlineButton;
                QToolButton*     mLeftButton;
                QToolButton*     mCenterButton;
                QToolButton*     mRightButton;
                QCheckBox*       mAboveCheck;
                QCheckBox*       mShrinkCheck;
                QCheckBox*       mStretchCheck;

                bool             mBlocked{ false };
                bool             mCanCustomize{ false };
        };

}


#endif // BarcodeTextEditor_hpp
