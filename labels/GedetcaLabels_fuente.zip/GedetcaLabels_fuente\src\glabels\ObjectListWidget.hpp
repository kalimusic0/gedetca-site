//  ObjectListWidget.hpp
//
//  List of the objects of the label (by name). Selecting an item selects the
//  object in the work area, and the other way round.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef ObjectListWidget_hpp
#define ObjectListWidget_hpp


#include "model/Model.hpp"

#include <QListWidget>


namespace glabels
{

        class ObjectListWidget : public QListWidget
        {
        public:
                explicit ObjectListWidget( QWidget* parent = nullptr );

                void setModel( model::Model* model );

        private:
                void refresh();
                void syncSelectionFromModel();
                void applySelectionToModel();

                model::Model*                mModel{ nullptr };
                QList<model::ModelObject*>   mShown;
                bool                         mBlocked{ false };
                bool                         mApplying{ false };
        };

}


#endif // ObjectListWidget_hpp
