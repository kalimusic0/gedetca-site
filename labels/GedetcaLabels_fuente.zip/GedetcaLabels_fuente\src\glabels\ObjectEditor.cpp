//  ObjectEditor.cpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "ObjectEditor.hpp"
#include "BarcodeTextEditor.hpp"
#include "Gs1Wizard.hpp"
#include "CropDialog.hpp"
#include <QMessageBox>
#include <QLabel>
#include <QHBoxLayout>

#include "UndoRedoModel.hpp"

#include "model/Model.hpp"
#include "model/ModelObject.hpp"
#include "model/ModelBarcodeObject.hpp"
#include "model/ModelBoxObject.hpp"
#include "model/ModelEllipseObject.hpp"
#include "model/ModelImageObject.hpp"
#include "model/ModelLineObject.hpp"
#include "model/ModelTextObject.hpp"
#include "model/FileUtil.hpp"
#include "model/Settings.hpp"
#include "model/TextRun.hpp"
#include "model/Size.hpp"

#include "merge/Merge.hpp"

#include <QDebug>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextDocument>
#include <QDir>
#include <QFileDialog>
#include <QtMath>


namespace
{
        // Every style can show text now: styles without text of their own (QR, Data Matrix...)
        // draw it with the text format; text is optional for them.
        bool bcTextOptional( const glabels::barcode::Style& style )
        {
                return style.canText() ? style.textOptional() : true;
        }
}


namespace glabels
{

        ///
        /// Constructor
        ///
        ObjectEditor::ObjectEditor( QWidget *parent )
                : mModel(nullptr), mObject(nullptr), mImageCwd("."), mBlocked(false)
        {
                setupUi( this );

                textFormatEditor = new TextFormatEditor( this );
                textFormatEditor->hide();
                connect( textFormatEditor, SIGNAL(changed()), this, SLOT(onTextFormatChanged()) );

                textTransformEditor = new TextTransformEditor( this );

                // GS1 wizard button (next to "Insert field"); only for GS1 styles
                barcodeGs1Button = new QPushButton( tr("GS1 wizard...") );
                barcodeGs1Button->setVisible( false );
                if ( auto* row = findChild<QHBoxLayout*>( "horizontalLayout_15" ) )
                {
                        row->insertWidget( row->indexOf( barcodeInsertFieldButton ) + 1, barcodeGs1Button );
                }
                connect( barcodeGs1Button, SIGNAL(clicked()), this, SLOT(onBarcodeGs1Wizard()) );

                // Crop of the image (percent cut from each side), a group under the file group of the image page
                {
                        auto* cropGroup = new QGroupBox( tr("Crop") );
                        auto* cropGrid = new QGridLayout( cropGroup );
                        const QString names[4] = { tr("Left:"), tr("Top:"), tr("Right:"), tr("Bottom:") };
                        for ( int i = 0; i < 4; i++ )
                        {
                                mCropSpin[i] = new QDoubleSpinBox();
                                mCropSpin[i]->setRange( 0, 95 );
                                mCropSpin[i]->setDecimals( 1 );
                                mCropSpin[i]->setSuffix( " %" );
                                cropGrid->addWidget( new QLabel( names[i] ), i / 2, 2 * ( i % 2 ) );
                                cropGrid->addWidget( mCropSpin[i], i / 2, 2 * ( i % 2 ) + 1 );
                                connect( mCropSpin[i], &QDoubleSpinBox::valueChanged, this, &ObjectEditor::onImageCropChanged );
                        }
                        auto* cropButton = new QPushButton( tr("Crop...") );
                        cropButton->setToolTip( tr("Crop the image dragging a rectangle over it") );
                        auto* cropClear = new QPushButton( tr("Remove crop") );
                        cropGrid->addWidget( cropButton, 2, 0, 1, 2 );
                        cropGrid->addWidget( cropClear, 2, 2, 1, 2 );
                        connect( cropButton, &QPushButton::clicked, this, &ObjectEditor::onImageCropDialog );
                        connect( cropClear,  &QPushButton::clicked, this, &ObjectEditor::onImageCropClear );

                        if ( auto* g = qobject_cast<QGridLayout*>( imagePage->layout() ) )
                        {
                                if ( QLayoutItem* spacer = g->itemAtPosition( 2, 0 ) )
                                {
                                        g->takeAt( g->indexOf( spacer ) );
                                        g->addWidget( cropGroup, 2, 0 );
                                        g->addItem( spacer, 3, 0 );
                                }
                        }
                }

                // Mixed formats inside one text: font, size, bold, italic and underline of the selected text
                textEdit->setAcceptRichText( false );
                {
                        auto* selRow = new QWidget();
                        auto* selLayout = new QHBoxLayout( selRow );
                        selLayout->setContentsMargins( 0, 0, 0, 0 );
                        selLayout->addWidget( new QLabel( tr("Selection:") ) );
                        mSelFont = new QFontComboBox();
                        mSelFont->setToolTip( tr("Font of the selected text") );
                        mSelSize = new QDoubleSpinBox();
                        mSelSize->setRange( 1, 999 );
                        mSelSize->setDecimals( 1 );
                        mSelSize->setSuffix( " pt" );
                        mSelSize->setToolTip( tr("Size of the selected text") );
                        auto makeToggle = []( const QString& label, const QString& style, const QString& tip )
                        {
                                auto* b = new QToolButton();
                                b->setText( label );
                                b->setCheckable( true );
                                b->setStyleSheet( style );
                                b->setToolTip( tip );
                                b->setFocusPolicy( Qt::NoFocus );
                                return b;
                        };
                        mSelBold      = makeToggle( "B", "font-weight: bold;",         tr("Bold (selected text)") );
                        mSelItalic    = makeToggle( "I", "font-style: italic;",        tr("Italic (selected text)") );
                        mSelUnderline = makeToggle( "U", "text-decoration: underline;", tr("Underline (selected text)") );
                        auto* clearButton = new QToolButton();
                        clearButton->setText( tr("Clear") );
                        clearButton->setToolTip( tr("Remove the formats of the selected text (it takes the format of the object)") );
                        clearButton->setFocusPolicy( Qt::NoFocus );
                        selLayout->addWidget( mSelFont, 1 );
                        selLayout->addWidget( mSelSize );
                        selLayout->addWidget( mSelBold );
                        selLayout->addWidget( mSelItalic );
                        selLayout->addWidget( mSelUnderline );
                        selLayout->addWidget( clearButton );
                        if ( auto* g = textEdit->parentWidget() ? textEdit->parentWidget()->findChild<QGridLayout*>( "gridLayout_3" ) : nullptr )
                        {
                                g->addWidget( selRow, g->rowCount(), 0 );
                        }
                        connect( mSelBold,      &QToolButton::clicked, this, &ObjectEditor::onSelectionBold );
                        connect( mSelItalic,    &QToolButton::clicked, this, &ObjectEditor::onSelectionItalic );
                        connect( mSelUnderline, &QToolButton::clicked, this, &ObjectEditor::onSelectionUnderline );
                        connect( clearButton,   &QToolButton::clicked, this, &ObjectEditor::onSelectionClear );
                        connect( mSelFont, &QFontComboBox::currentFontChanged, this, &ObjectEditor::onSelectionFont );
                        connect( mSelSize, &QDoubleSpinBox::valueChanged, this, &ObjectEditor::onSelectionSize );
                        connect( textEdit, &QTextEdit::currentCharFormatChanged, this, &ObjectEditor::onEditorCharFormatChanged );
                }
                // Name of the object (its identity), a row under the title
                nameEdit = new QLineEdit();
                nameEdit->setPlaceholderText( tr("Object name") );
                nameEdit->setToolTip( tr("Name of the object. Other texts can take its value by this name.") );
                auto* nameRow = new QWidget();
                auto* nameLayout = new QHBoxLayout( nameRow );
                nameLayout->setContentsMargins( 0, 0, 0, 0 );
                nameLayout->addWidget( new QLabel( tr("Name:") ) );
                nameLayout->addWidget( nameEdit, 1 );
                if ( auto* grid = qobject_cast<QGridLayout*>( layout() ) )
                {
                        struct Pos { QLayoutItem* item; int r, c, rs, cs; Qt::Alignment al; };
                        QList<Pos> items;
                        for ( int i = 0; i < grid->count(); i++ )
                        {
                                Pos p;
                                p.item = grid->itemAt( i );
                                grid->getItemPosition( i, &p.r, &p.c, &p.rs, &p.cs );
                                p.al = p.item->alignment();
                                items << p;
                        }
                        while ( grid->count() > 0 ) grid->takeAt( 0 );
                        for ( const Pos& p : items )
                        {
                                grid->addItem( p.item, p.r >= 1 ? p.r + 1 : p.r, p.c, p.rs, p.cs, p.al );
                        }
                        grid->addWidget( nameRow, 1, 0, 1, qMax( 1, grid->columnCount() ) );
                }
                connect( nameEdit, SIGNAL(editingFinished()), this, SLOT(onNameEdited()) );
                // Text format of the barcode (font, alignment, fitting); inside "Barcode data"
                barcodeTextGroup = new QGroupBox( tr("Barcode text") );
                auto* textGroupLayout = new QVBoxLayout( barcodeTextGroup );
                barcodeTextEditor = new BarcodeTextEditor();
                textGroupLayout->addWidget( barcodeTextEditor );
                barcodeTextGroup->setVisible( false );
                if ( auto* grid = findChild<QGridLayout*>( "gridLayout_11" ) )
                {
                        grid->addWidget( barcodeTextGroup, 1, 0 );
                }
                connect( barcodeTextEditor, SIGNAL(changed()), this, SLOT(onBarcodeTextChanged()) );
                textTransformEditor->hide();
                connect( textTransformEditor, SIGNAL(changed()), this, SLOT(onTextFormatChanged()) );

                textHAlignGroup = new QButtonGroup( this );
                textHAlignGroup->addButton( textHAlignLeftToggle, Qt::AlignLeft );
                textHAlignGroup->addButton( textHAlignCenterToggle, Qt::AlignHCenter );
                textHAlignGroup->addButton( textHAlignRightToggle, Qt::AlignRight );

                textVAlignGroup = new QButtonGroup( this );
                textVAlignGroup->addButton( textVAlignTopToggle, Qt::AlignTop );
                textVAlignGroup->addButton( textVAlignMiddleToggle, Qt::AlignVCenter );
                textVAlignGroup->addButton( textVAlignBottomToggle, Qt::AlignBottom );

                lineColorButton->init( tr("No line"), QColor(0,0,0,0), QColor(0,0,0,255) );
                fillColorButton->init( tr("No fill"), QColor(0,0,0,0), QColor(0,0,0,255) );
                textColorButton->init( tr("Default"), QColor(0,0,0,255), QColor(0,0,0,255) );
                barcodeColorButton->init( tr("Default"), QColor(0,0,0,255), QColor(0,0,0,255) );
                shadowColorButton->init( tr("Default"), QColor(0,0,0,255), QColor(0,0,0,255) );

                textInsertFieldButton->setText( tr("Insert substitution field") );
                barcodeInsertFieldButton->setText( tr("Insert substitution field") );
                imageFieldButton->setText( tr("Use substitution field") );

                setEnabled( false );
                hidePages();

                connect( model::Settings::instance(), SIGNAL(changed()),
                         this, SLOT(onSettingsChanged()) );

                onSettingsChanged();
        }


        void ObjectEditor::setModel( model::Model* model, UndoRedoModel* undoRedoModel )
        {
                mModel = model;
                mUndoRedoModel = undoRedoModel;

                connect( mModel, SIGNAL(sizeChanged()),
                         this, SLOT(onLabelSizeChanged()) );

                connect( mModel, SIGNAL(selectionChanged()),
                         this, SLOT(onSelectionChanged()) );

                connect( mModel, SIGNAL(mergeSourceChanged()),
                         this, SLOT(onFieldsAvailableChanged()) );

                connect( mModel, SIGNAL(variablesChanged()),
                         this, SLOT(onFieldsAvailableChanged()) );

                onLabelSizeChanged();
                onSelectionChanged();
                onFieldsAvailableChanged();
        }
        void ObjectEditor::setCompact( bool compact )
        {
                notebook->setVisible( !compact );
        }



        void ObjectEditor::hidePages()
        {
                notebook->removeTab( notebook->indexOf(textPage) );
                notebook->removeTab( notebook->indexOf(textFormatEditor) );
                notebook->removeTab( notebook->indexOf(textTransformEditor) );
                notebook->removeTab( notebook->indexOf(barcodePage) );
                notebook->removeTab( notebook->indexOf(imagePage) );
                notebook->removeTab( notebook->indexOf(lineFillPage) );
                notebook->removeTab( notebook->indexOf(posSizePage) );
                notebook->removeTab( notebook->indexOf(shadowPage) );
        }


        void ObjectEditor::loadImagePage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        {
                                QMarginsF c = mObject->imageCrop();
                                mCropSpin[0]->setValue( c.left() * 100 );
                                mCropSpin[1]->setValue( c.top() * 100 );
                                mCropSpin[2]->setValue( c.right() * 100 );
                                mCropSpin[3]->setValue( c.bottom() * 100 );
                        }

                        model::TextNode filenameNode = mObject->filenameNode();

                        if ( filenameNode.isField() )
                        {
                                imageFilenameLineEdit->setText( QString("${%1}").arg(filenameNode.data()) );
                        }
                        else
                        {
                                QString fn = model::FileUtil::makeRelativeIfInDir( mModel->dir(), filenameNode.data() );
                                imageFilenameLineEdit->setText( fn );
                        }

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadLineFillPage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        lineWidthSpin->setValue( mObject->lineWidth().pt() );
                        lineColorButton->setColorNode( mObject->lineColorNode() );
                        fillColorButton->setColorNode( mObject->fillColorNode() );

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadPositionPage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        posXSpin->setDecimals( mSpinDigits );
                        posXSpin->setSingleStep( mSpinStep );
                        posXSpin->setSuffix( " " + mUnits.toIdString() );

                        posYSpin->setDecimals( mSpinDigits );
                        posYSpin->setSingleStep( mSpinStep );
                        posYSpin->setSuffix( " " + mUnits.toIdString() );

                        posXSpin->setValue( mObject->x0().inUnits(mUnits) );
                        posYSpin->setValue( mObject->y0().inUnits(mUnits) );

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadRectSizePage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        sizeWSpin->setDecimals( mSpinDigits );
                        sizeWSpin->setSingleStep( mSpinStep );
                        sizeWSpin->setSuffix( " " + mUnits.toIdString() );

                        sizeHSpin->setDecimals( mSpinDigits );
                        sizeHSpin->setSingleStep( mSpinStep );
                        sizeHSpin->setSuffix( " " + mUnits.toIdString() );

                        sizeWSpin->setValue( mObject->w().inUnits(mUnits) );
                        sizeHSpin->setValue( mObject->h().inUnits(mUnits) );
                        sizeAspectCheck->setChecked( mObject->lockAspectRatio() );

                        model::Size originalSize = mObject->naturalSize();
                        QString originalSizeString = QString( "%1:  %2 x %3 %4" )
                                .arg( tr("Original size") )
                                .arg( originalSize.w().inUnits(mUnits), 0, 'f', mSpinDigits )
                                .arg( originalSize.h().inUnits(mUnits), 0, 'f', mSpinDigits )
                                .arg( mUnits.toIdString() );
                        sizeOriginalSizeLabel->setText( originalSizeString );

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadLineSizePage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        sizeLineLengthSpin->setDecimals( mSpinDigits );
                        sizeLineLengthSpin->setSingleStep( mSpinStep );
                        sizeLineLengthSpin->setSuffix( " " + mUnits.toIdString() );

                        double w = mObject->w().inUnits(mUnits);
                        double h = mObject->h().inUnits(mUnits);
                        sizeLineLengthSpin->setValue( sqrt( w*w + h*h ) );
                        sizeLineAngleSpin->setValue( qRadiansToDegrees( qAtan2( h, w ) ) );

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadTextPage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        int wrapIndex = 0;
                        switch (mObject->textWrapMode())
                        {
                        case QTextOption::WordWrap:     wrapIndex = 0; break;
                        case QTextOption::WrapAnywhere: wrapIndex = 1; break;
                        default:                        wrapIndex = 2; break;
                        }

                        textFontFamilyCombo->setCurrentText( mObject->fontFamily() );
                        textFontSizeSpin->setValue( mObject->fontSize() );
                        textFontBoldToggle->setChecked( mObject->fontWeight() == QFont::Bold );
                        textFontItalicToggle->setChecked( mObject->fontItalicFlag() );
                        textFontUnderlineToggle->setChecked( mObject->fontUnderlineFlag() );
                        textColorButton->setColorNode( mObject->textColorNode() );
                        textHAlignGroup->button( mObject->textHAlign() )->setChecked( true );
                        textVAlignGroup->button( mObject->textVAlign() )->setChecked( true );
                        textWrapModeCombo->setCurrentIndex( wrapIndex );
                        textLineSpacingSpin->setValue( mObject->textLineSpacing() );
                        textAutoShrinkCheck->setChecked( mObject->textAutoShrink() );
                        textStretchCheck->setChecked( mObject->textStretch() );
                        loadTextEdit();
                        textFormatEditor->setFormat( mObject->textFormat() );
                        textFormatEditor->setSampleText( mObject->text() );
                        textTransformEditor->setFormat( mObject->textFormat() );
                        {
                                QStringList objectNames;
                                if ( mModel )
                                {
                                        for ( const QString& n : mModel->objectNames() )
                                        {
                                                if ( n != mObject->name() ) objectNames << n;
                                        }
                                }
                                textTransformEditor->setObjectNames( objectNames );
                                textTransformEditor->setSource( mObject->textSourceName(), mObject->textSourceKind() );
                                textEdit->setEnabled( mObject->textSourceName().isEmpty() );
                        }
                        if ( mModel )
                        {
                                QStringList names;
                                if ( mModel->merge() ) names << mModel->merge()->keys();
                                names << mModel->variables().keys();
                                names.removeDuplicates();
                                textTransformEditor->setFieldNames( names );
                        }

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadBarcodePage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        barcode::Style bcStyle = mObject->bcStyle();

                        barcodeShowTextCheck->setEnabled( bcTextOptional( bcStyle ) );
                        barcodeChecksumCheck->setEnabled( bcStyle.checksumOptional() );

                        // May need to adjust current text flag, if style changed
                        bool textFlag = mObject->bcTextFlag() || !bcTextOptional( bcStyle );
                        mObject->setBcTextFlag( textFlag );

                        // May need to adjust current checksum flag, if style changed
                        bool csFlag = (mObject->bcChecksumFlag() && bcStyle.canChecksum())
                                ||  (bcStyle.canChecksum() && !bcStyle.checksumOptional());
                        mObject->setBcChecksumFlag( csFlag );

                        barcodeStyleButton->setBcStyle( bcStyle );
                        barcodeGs1Button->setVisible( bcStyle.id() == "gs1-128" || bcStyle.id() == "gs1qr" || bcStyle.id() == "rssexp" || bcStyle.id() == "rssse" );
                        barcodeTextGroup->setVisible( textFlag );
                        barcodeShowTextCheck->setChecked( textFlag );
                        barcodeChecksumCheck->setChecked( csFlag );
                        barcodeColorButton->setColorNode( mObject->bcColorNode() );
                        barcodeDataEdit->setText( mObject->bcData() );
                        barcodeTextEditor->setOptions( mObject->bcTextOptions(), bcStyle.canText() );

                        mBlocked = false;
                }
        }


        void ObjectEditor::loadShadowPage()
        {
                if ( mObject )
                {
                        mBlocked = true;

                        shadowXSpin->setDecimals( mSpinDigits );
                        shadowXSpin->setSingleStep( mSpinStep );
                        shadowXSpin->setSuffix( " " + mUnits.toIdString() );

                        shadowYSpin->setDecimals( mSpinDigits );
                        shadowYSpin->setSingleStep( mSpinStep );
                        shadowYSpin->setSuffix( " " + mUnits.toIdString() );

                        shadowEnableCheck->setChecked( mObject->shadow() );
                        shadowXSpin->setValue( mObject->shadowX().inUnits(mUnits) );
                        shadowYSpin->setValue( mObject->shadowY().inUnits(mUnits) );
                        shadowColorButton->setColorNode( mObject->shadowColorNode() );
                        shadowOpacitySpin->setValue( 100*mObject->shadowOpacity() );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onSettingsChanged()
        {
                mUnits = model::Settings::units();
                mSpinDigits = mUnits.resolutionDigits();
                mSpinStep = mUnits.resolution();

                /* Must now update limits and reload any active pages with appropriate units. */
                onLabelSizeChanged();
                onSelectionChanged();
        }


        void ObjectEditor::onLabelSizeChanged()
        {
                if ( mModel )
                {
                        mBlocked = true;

                        model::Distance whMax = std::max( mModel->w(), mModel->h() );

                        posXSpin->setRange( -whMax.inUnits(mUnits), 2*whMax.inUnits(mUnits) );
                        posYSpin->setRange( -whMax.inUnits(mUnits), 2*whMax.inUnits(mUnits) );
                        sizeWSpin->setRange( 0, 2*whMax.inUnits(mUnits) );
                        sizeHSpin->setRange( 0, 2*whMax.inUnits(mUnits) );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onSelectionChanged()
        {
                if ( mModel )
                {
                        if ( mObject )
                        {
                                disconnect( mObject, nullptr, this, nullptr );
                        }

                        hidePages();

                        if ( mModel->isSelectionAtomic() )
                        {
                                mObject = mModel->getFirstSelectedObject();
                                loadNameRow();

                                if ( dynamic_cast<model::ModelBoxObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-box" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Box object properties") );

                                        notebook->addTab( lineFillPage, tr("line/fill") );
                                        notebook->addTab( posSizePage, tr("position/size") );
                                        notebook->addTab( shadowPage, tr("shadow") );

                                        fillFrame->setVisible( true );
                                        sizeRectFrame->setVisible( true );
                                        sizeOriginalSizeGroup->setVisible( false );
                                        sizeLineFrame->setVisible( false );

                                        loadLineFillPage();
                                        loadPositionPage();
                                        loadRectSizePage();
                                        loadShadowPage();

                                        setEnabled( true );
                                }
                                else if ( dynamic_cast<model::ModelEllipseObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-ellipse" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Ellipse object properties") );

                                        notebook->addTab( lineFillPage, tr("line/fill") );
                                        notebook->addTab( posSizePage, tr("position/size") );
                                        notebook->addTab( shadowPage, tr("shadow") );

                                        fillFrame->setVisible( true );
                                        sizeRectFrame->setVisible( true );
                                        sizeOriginalSizeGroup->setVisible( false );
                                        sizeLineFrame->setVisible( false );

                                        loadLineFillPage();
                                        loadPositionPage();
                                        loadRectSizePage();
                                        loadShadowPage();

                                        setEnabled( true );
                                }
                                else if ( dynamic_cast<model::ModelImageObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-image" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Image object properties") );

                                        notebook->addTab( imagePage, tr("image") );
                                        notebook->addTab( posSizePage, tr("position/size") );
                                        notebook->addTab( shadowPage, tr("shadow") );

                                        sizeRectFrame->setVisible( true );
                                        sizeOriginalSizeGroup->setVisible( true );
                                        sizeLineFrame->setVisible( false );

                                        loadImagePage();
                                        loadPositionPage();
                                        loadRectSizePage();
                                        loadShadowPage();

                                        setEnabled( true );
                                }
                                else if ( dynamic_cast<model::ModelLineObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-line" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Line object properties") );

                                        notebook->addTab( lineFillPage, tr("line/fill") );
                                        notebook->addTab( posSizePage, tr("position/size") );
                                        notebook->addTab( shadowPage, tr("shadow") );

                                        fillFrame->setVisible( false );
                                        sizeRectFrame->setVisible( false );
                                        sizeOriginalSizeGroup->setVisible( false );
                                        sizeLineFrame->setVisible( true );

                                        loadLineFillPage();
                                        loadPositionPage();
                                        loadLineSizePage();
                                        loadShadowPage();

                                        setEnabled( true );
                                }
                                else if ( dynamic_cast<model::ModelTextObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-text" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Text object properties") );

                                        notebook->addTab( textPage, tr("text") );
                                        notebook->addTab( textFormatEditor, tr("format") );
                                        notebook->addTab( textTransformEditor, tr("transform") );
                                        notebook->addTab( posSizePage, tr("position/size") );
                                        notebook->addTab( shadowPage, tr("shadow") );

                                        sizeRectFrame->setVisible( true );
                                        sizeOriginalSizeGroup->setVisible( false );
                                        sizeLineFrame->setVisible( false );

                                        loadTextPage();
                                        loadPositionPage();
                                        loadRectSizePage();
                                        loadShadowPage();

                                        setEnabled( true );
                                }
                                else if ( dynamic_cast<model::ModelBarcodeObject*>(mObject) )
                                {
                                        titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-barcode" ).pixmap( 24 ) );
                                        titleLabel->setText( tr("Barcode object properties") );

                                        notebook->addTab( barcodePage, tr("barcode") );
                                        notebook->addTab( posSizePage, tr("position/size") );

                                        sizeRectFrame->setVisible( true );
                                        sizeOriginalSizeGroup->setVisible( false );
                                        sizeLineFrame->setVisible( false );

                                        loadBarcodePage();
                                        loadPositionPage();
                                        loadRectSizePage();

                                        setEnabled( true );
                                }
                                else
                                {
                                        Q_ASSERT_X( false, "ObjectEditor::onSelectionChanged", "Invalid object" );
                                }

                                connect( mObject, SIGNAL(changed()), this, SLOT(onObjectChanged()) );
                                connect( mObject, SIGNAL(moved()), this, SLOT(onObjectMoved()) );
                                connect( mObject, SIGNAL(destroyed(QObject*)), this, SLOT(onObjectDestroyed()) );
                        }
                        else
                        {
                                mObject = nullptr;

                                titleImageLabel->setPixmap( QIcon::fromTheme( "glabels-object-properties" ).pixmap( 24 ) );
                                titleLabel->setText( tr("Object properties") );
                                setEnabled( false );
                        }
                }
        }


        void ObjectEditor::onFieldsAvailableChanged()
        {
                if ( !mBlocked )
                {
                        lineColorButton->setKeys( mModel->merge(), mModel->variables() );
                        fillColorButton->setKeys( mModel->merge(), mModel->variables() );
                        textColorButton->setKeys( mModel->merge(), mModel->variables() );
                        barcodeColorButton->setKeys( mModel->merge(), mModel->variables() );
                        shadowColorButton->setKeys( mModel->merge(), mModel->variables() );

                        textInsertFieldButton->setKeys( mModel->merge(), mModel->variables() );
                        barcodeInsertFieldButton->setKeys( mModel->merge(), mModel->variables() );
                        imageFieldButton->setKeys( mModel->merge(), mModel->variables() );
                }
        }


        void ObjectEditor::onObjectChanged()
        {
                if ( !mBlocked )
                {
                        if ( !nameEdit->hasFocus() ) loadNameRow();
                        loadLineFillPage();
                        loadRectSizePage();
                        loadLineSizePage();
                        loadImagePage();
                        loadShadowPage();
                }
        }


        void ObjectEditor::onObjectMoved()
        {
                if ( !mBlocked )
                {
                        loadPositionPage();
                }
        }


        void ObjectEditor::onObjectDestroyed()
        {
                disconnect( mObject, nullptr, this, nullptr );
                mObject = nullptr;
        }


        void ObjectEditor::onLineControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Line") );

                        mObject->setLineWidth( model::Distance::pt(lineWidthSpin->value()) );
                        mObject->setLineColorNode( lineColorButton->colorNode() );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onFillControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Fill") );

                        mObject->setFillColorNode( fillColorButton->colorNode() );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onImageFileButtonClicked()
        {
                // Either use saved CWD from a previous open or the current file, if it exists
                QString cwd = mImageCwd;
                if ( !mObject->filenameNode().isField() )
                {
                        QFileInfo fileInfo( mObject->filenameNode().data() );
                        if ( fileInfo.isFile() )
                        {
                                cwd = fileInfo.filePath();
                        }
                }

                QString filters =
                        tr("Image files (*.png *.jpg *.jpeg *.gif *.bmp *.pbm *.pgm *.ppm *.xbm *.xpm *.svg)") + ";;" +
                        tr("All files (*)") + ";;" +
                        tr("PNG - Portable Network Graphics (*.png)") + ";;" +
                        tr("BMP - Windows Bitmap (*.bmp)") + ";;" +
                        tr("GIF - Graphics Interchange Format (*.gif)") + ";;" +
                        tr("JPEG - Joint Photographic Experts Group (*.jpg *.jpeg)") + ";;" +
                        tr("PBM - Portable Bitmap (*.pbm)") + ";;" +
                        tr("PGM - Portable Graymap (*.pgm)") + ";;" +
                        tr("PPM - Portable Pixmap (*.ppm)") + ";;" +
                        tr("SVG - Scalable Vector Graphics (*.svg)") + ";;" +
                        tr("XBM - X11 Bitmap (*.xbm)") + ";;" +
                        tr("XPM - X11 Pixmap (*.xpm)");

                QString filename =
                        QFileDialog::getOpenFileName( this->window(),
                                                      tr("gLabels - Select image file"),
                                                      cwd, filters );

                if ( !filename.isEmpty() )
                {
                        mUndoRedoModel->checkpoint( tr("Set image") );
                        mObject->setFilenameNode( model::TextNode( false, filename ) );

                        // Save CWD for next open
                        QFileInfo fileInfo( filename );
                        mImageCwd = fileInfo.absolutePath();
                }
        }


        void ObjectEditor::onImageKeySelected( QString key )
        {
                if ( mObject )
                {
                        mUndoRedoModel->checkpoint( tr("Set image") );
                        mObject->setFilenameNode( model::TextNode( true, key ) );
                }
        }


        void ObjectEditor::onPositionControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Position") );

                        model::Distance x = model::Distance(posXSpin->value(), mUnits);
                        model::Distance y = model::Distance(posYSpin->value(), mUnits);

                        mObject->setPosition( x, y );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onRectSizeControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Size") );

                        model::Distance spinW = model::Distance(sizeWSpin->value(), mUnits);
                        model::Distance spinH = model::Distance(sizeHSpin->value(), mUnits);

                        if ( sizeAspectCheck->isChecked() )
                        {
                                mObject->setLockAspectRatio( true );
                                if ( fabs(spinW - mObject->w()) > fabs(spinH - mObject->h()) )
                                {
                                        mObject->setWHonorAspect( spinW );
                                        sizeHSpin->setValue( mObject->h().inUnits(mUnits) );
                                }
                                else
                                {
                                        mObject->setHHonorAspect( spinH );
                                        sizeWSpin->setValue( mObject->w().inUnits(mUnits) );
                                }
                        }
                        else
                        {
                                mObject->setLockAspectRatio( false );
                                mObject->setSize( spinW, spinH );
                        }

                        mBlocked = false;
                }
        }


        void ObjectEditor::onLineSizeControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Size") );

                        model::Distance spinLength = model::Distance(sizeLineLengthSpin->value(), mUnits);
                        double spinAngleRads = qDegreesToRadians( sizeLineAngleSpin->value() );

                        mObject->setSize( spinLength*qCos(spinAngleRads),
                                          spinLength*qSin(spinAngleRads) );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onTextControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Text") );

                        QTextOption::WrapMode wrapMode;
                        switch (textWrapModeCombo->currentIndex())
                        {
                        case 0:  wrapMode = QTextOption::WordWrap;     break;
                        case 1:  wrapMode = QTextOption::WrapAnywhere; break;
                        default: wrapMode = QTextOption::NoWrap;       break;
                        }

                        mObject->setFontFamily( textFontFamilyCombo->currentText() );
                        mObject->setFontSize( textFontSizeSpin->value() );
                        mObject->setFontWeight( textFontBoldToggle->isChecked() ? QFont::Bold : QFont::Normal );
                        mObject->setFontItalicFlag( textFontItalicToggle->isChecked() );
                        mObject->setFontUnderlineFlag( textFontUnderlineToggle->isChecked() );
                        mObject->setTextColorNode( textColorButton->colorNode() );
                        mObject->setTextHAlign( Qt::AlignmentFlag( textHAlignGroup->checkedId() ) );
                        mObject->setTextVAlign( Qt::AlignmentFlag( textVAlignGroup->checkedId() ) );
                        mObject->setTextWrapMode( wrapMode );
                        mObject->setTextLineSpacing( textLineSpacingSpin->value() );
                        mObject->setTextAutoShrink( textAutoShrinkCheck->isChecked() );
                        mObject->setTextStretch( textStretchCheck->isChecked() );
                        updateEditorBaseFont();
                        mObject->setTextRuns( collectTextRuns() );
                        mObject->setText( textEdit->toPlainText() );
                        textFormatEditor->setSampleText( textEdit->toPlainText() );

                        mBlocked = false;
                }
        }


        ///
        /// Editor shows the text with the base font of the object (formats of runs are the differences)
        ///
        void ObjectEditor::updateEditorBaseFont()
        {
                if ( !mObject ) return;

                // Keep very large label fonts readable in the editor: everything is scaled by the same factor
                mEditorScale = mObject->fontSize() > 14.0 ? 14.0 / mObject->fontSize() : 1.0;

                QFont f( mObject->fontFamily() );
                f.setPointSizeF( qMax( 1.0, mObject->fontSize() * mEditorScale ) );
                f.setBold( mObject->fontWeight() >= QFont::DemiBold );
                f.setItalic( mObject->fontItalicFlag() );
                f.setUnderline( mObject->fontUnderlineFlag() );
                textEdit->document()->setDefaultFont( f );
        }


        ///
        /// Fill the text editor from the object: its text and the formats of its runs
        ///
        void ObjectEditor::loadTextEdit()
        {
                updateEditorBaseFont();
                textEdit->setPlainText( mObject->text() );

                const QList<model::TextRun> runs = model::TextRun::fromString( mObject->textRuns() );
                const int total = textEdit->document()->characterCount() - 1;
                QTextCursor cursor( textEdit->document() );
                cursor.beginEditBlock();
                for ( const model::TextRun& r : runs )
                {
                        if ( r.start >= total ) continue;

                        QTextCharFormat f;
                        if ( r.bold >= 0 )      f.setFontWeight( r.bold ? QFont::Bold : QFont::Normal );
                        if ( r.italic >= 0 )    f.setFontItalic( r.italic );
                        if ( r.underline >= 0 ) f.setFontUnderline( r.underline );
                        if ( !r.family.isEmpty() ) f.setFontFamilies( QStringList( r.family ) );
                        if ( r.size > 0 )       f.setFontPointSize( r.size * mEditorScale );

                        cursor.setPosition( r.start );
                        cursor.setPosition( qMin( r.start + r.length, total ), QTextCursor::KeepAnchor );
                        cursor.mergeCharFormat( f );
                }
                cursor.endEditBlock();
                textEdit->document()->setModified( false );
                onEditorCharFormatChanged( textEdit->currentCharFormat() );
        }


        ///
        /// Formats of the characters in the editor that differ from the object's own, as runs
        ///
        QString ObjectEditor::collectTextRuns() const
        {
                const bool   baseBold      = mObject->fontWeight() >= QFont::DemiBold;
                const bool   baseItalic    = mObject->fontItalicFlag();
                const bool   baseUnderline = mObject->fontUnderlineFlag();
                const QString baseFamily   = mObject->fontFamily();
                const double baseSize      = mObject->fontSize();

                QList<model::TextRun> runs;
                for ( QTextBlock block = textEdit->document()->begin(); block.isValid(); block = block.next() )
                {
                        for ( QTextBlock::iterator it = block.begin(); !it.atEnd(); ++it )
                        {
                                QTextFragment frag = it.fragment();
                                if ( !frag.isValid() ) continue;

                                const QTextCharFormat f = frag.charFormat();
                                model::TextRun r;
                                r.start  = frag.position();
                                r.length = frag.length();

                                if ( f.hasProperty( QTextFormat::FontWeight ) )
                                {
                                        bool b = f.fontWeight() >= QFont::DemiBold;
                                        if ( b != baseBold ) r.bold = b ? 1 : 0;
                                }
                                if ( f.hasProperty( QTextFormat::FontItalic ) && f.fontItalic() != baseItalic )
                                {
                                        r.italic = f.fontItalic() ? 1 : 0;
                                }
                                if ( f.hasProperty( QTextFormat::TextUnderlineStyle ) && f.fontUnderline() != baseUnderline )
                                {
                                        r.underline = f.fontUnderline() ? 1 : 0;
                                }
                                if ( !f.fontFamilies().toStringList().isEmpty() )
                                {
                                        QString fam = f.fontFamilies().toStringList().first();
                                        if ( fam != baseFamily ) r.family = fam;
                                }
                                if ( f.hasProperty( QTextFormat::FontPointSize ) )
                                {
                                        double size = f.fontPointSize() / mEditorScale;
                                        if ( qAbs( size - baseSize ) > 0.05 ) r.size = size;
                                }

                                if ( r.isDefault() ) continue;

                                if ( !runs.isEmpty() && runs.last().start + runs.last().length == r.start && runs.last().sameStyle( r ) )
                                {
                                        runs.last().length += r.length;
                                }
                                else
                                {
                                        runs << r;
                                }
                        }
                }
                return model::TextRun::toString( runs );
        }


        void ObjectEditor::onSelectionBold( bool on )
        {
                QTextCharFormat f;
                f.setFontWeight( on ? QFont::Bold : QFont::Normal );
                textEdit->mergeCurrentCharFormat( f );
                textEdit->setFocus();
        }


        void ObjectEditor::onSelectionItalic( bool on )
        {
                QTextCharFormat f;
                f.setFontItalic( on );
                textEdit->mergeCurrentCharFormat( f );
                textEdit->setFocus();
        }


        void ObjectEditor::onSelectionUnderline( bool on )
        {
                QTextCharFormat f;
                f.setFontUnderline( on );
                textEdit->mergeCurrentCharFormat( f );
                textEdit->setFocus();
        }


        void ObjectEditor::onSelectionFont( const QFont& font )
        {
                if ( mBlocked ) return;
                QTextCharFormat f;
                f.setFontFamilies( QStringList( font.family() ) );
                textEdit->mergeCurrentCharFormat( f );
        }


        void ObjectEditor::onSelectionSize( double size )
        {
                if ( mBlocked ) return;
                QTextCharFormat f;
                f.setFontPointSize( size * mEditorScale );
                textEdit->mergeCurrentCharFormat( f );
        }


        void ObjectEditor::onSelectionClear()
        {
                QTextCursor cursor = textEdit->textCursor();
                if ( cursor.hasSelection() )
                {
                        cursor.setCharFormat( QTextCharFormat() );
                        textEdit->setTextCursor( cursor );
                }
                else
                {
                        textEdit->setCurrentCharFormat( QTextCharFormat() );
                }
                textEdit->setFocus();
        }


        ///
        /// The cursor moved: show the formats of the character at the cursor
        ///
        void ObjectEditor::onEditorCharFormatChanged( const QTextCharFormat& format )
        {
                if ( !mObject || !mSelBold ) return;

                bool saved = mBlocked;
                mBlocked = true;

                mSelBold->setChecked( format.hasProperty( QTextFormat::FontWeight ) ? format.fontWeight() >= QFont::DemiBold
                                                                                    : mObject->fontWeight() >= QFont::DemiBold );
                mSelItalic->setChecked( format.hasProperty( QTextFormat::FontItalic ) ? format.fontItalic()
                                                                                      : mObject->fontItalicFlag() );
                mSelUnderline->setChecked( format.hasProperty( QTextFormat::TextUnderlineStyle ) ? format.fontUnderline()
                                                                                                  : mObject->fontUnderlineFlag() );

                QStringList fams = format.fontFamilies().toStringList();
                mSelFont->setCurrentFont( QFont( fams.isEmpty() ? mObject->fontFamily() : fams.first() ) );
                mSelSize->setValue( format.hasProperty( QTextFormat::FontPointSize ) ? format.fontPointSize() / mEditorScale
                                                                                      : mObject->fontSize() );

                mBlocked = saved;
        }


        void ObjectEditor::onTextFormatChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Format") );

                        model::TextFormat f = textFormatEditor->format();
                        textTransformEditor->fillFormat( f );
                        mObject->setTextFormat( f );
                        mObject->setTextSource( textTransformEditor->sourceName(), textTransformEditor->sourceKind() );
                        textEdit->setEnabled( textTransformEditor->sourceName().isEmpty() );

                        mBlocked = false;
                }
        }

        void ObjectEditor::onTextInsertFieldKeySelected( QString key )
        {
                textEdit->insertPlainText( "${" + key + "}" );
        }


        void ObjectEditor::onBarcodeControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Barcode") );

                        barcode::Style bcStyle = barcodeStyleButton->bcStyle();

                        barcodeShowTextCheck->setEnabled( bcTextOptional( bcStyle ) );
                        barcodeChecksumCheck->setEnabled( bcStyle.checksumOptional() );

                        // May need to adjust current text flag, if style changed
                        bool textFlag = barcodeShowTextCheck->isChecked() || !bcTextOptional( bcStyle );
                        barcodeShowTextCheck->setChecked( textFlag );

                        // May need to adjust current checksum flag, if style changed
                        bool csFlag = (barcodeChecksumCheck->isChecked() && bcStyle.canChecksum())
                                ||  (bcStyle.canChecksum() && !bcStyle.checksumOptional());
                        barcodeChecksumCheck->setChecked( csFlag );

                        mObject->setBcStyle( bcStyle );
                        barcodeGs1Button->setVisible( bcStyle.id() == "gs1-128" || bcStyle.id() == "gs1qr" || bcStyle.id() == "rssexp" || bcStyle.id() == "rssse" );
                        barcodeTextGroup->setVisible( textFlag );
                        mObject->setBcTextFlag( textFlag );
                        mObject->setBcChecksumFlag( csFlag );
                        mObject->setBcColorNode( barcodeColorButton->colorNode() );
                        mObject->setBcData( barcodeDataEdit->toPlainText() );
                        barcodeTextEditor->setOptions( mObject->bcTextOptions(), bcStyle.canText() );

                        mBlocked = false;
                }
        }
        void ObjectEditor::loadNameRow()
        {
                bool was = nameEdit->blockSignals( true );
                nameEdit->setText( mObject ? mObject->name() : QString() );
                nameEdit->blockSignals( was );
        }


        void ObjectEditor::onNameEdited()
        {
                if ( !mObject || !mModel )
                {
                        return;
                }

                QString name = nameEdit->text().trimmed();
                if ( name == mObject->name() )
                {
                        return;
                }

                model::ModelObject* other = mModel->objectByName( name );
                if ( name.isEmpty() || ( other && other != mObject ) )
                {
                        QMessageBox::warning( this, tr("Object name"),
                                              name.isEmpty() ? tr("The name cannot be empty.")
                                                             : tr("Another object already has the name \"%1\".").arg( name ) );
                        loadNameRow();
                        return;
                }

                mUndoRedoModel->checkpoint( tr("Rename object") );
                mModel->renameObject( mObject, name );
                loadNameRow();
        }

        void ObjectEditor::onBarcodeTextChanged()
        {
                if ( !mBlocked && mObject )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Barcode text") );
                        mObject->setBcTextOptions( barcodeTextEditor->options() );

                        mBlocked = false;
                }
        }

        void ObjectEditor::onBarcodeGs1Wizard()
        {
                QStringList fields, variables;
                if ( mModel )
                {
                        if ( mModel->merge() ) fields = mModel->merge()->keys();
                        variables = mModel->variables().keys();
                }

                Gs1Wizard wizard( barcodeDataEdit->toPlainText(), fields, variables, this );
                if ( wizard.exec() == QDialog::Accepted && !wizard.dataString().isEmpty() )
                {
                        barcodeDataEdit->setPlainText( wizard.dataString() );   // updates the object
                }
        }



        void ObjectEditor::onBarcodeInsertFieldKeySelected( QString key )
        {
                barcodeDataEdit->insertPlainText( "${" + key + "}" );
        }


        void ObjectEditor::onImageCropChanged()
        {
                if ( mBlocked || !mObject ) return;
                mBlocked = true;

                mUndoRedoModel->checkpoint( tr("Crop") );
                mObject->setImageCrop( QMarginsF( mCropSpin[0]->value() / 100, mCropSpin[1]->value() / 100,
                                                  mCropSpin[2]->value() / 100, mCropSpin[3]->value() / 100 ) );
                // show the values after the limits
                QMarginsF c = mObject->imageCrop();
                mCropSpin[0]->setValue( c.left() * 100 );   mCropSpin[1]->setValue( c.top() * 100 );
                mCropSpin[2]->setValue( c.right() * 100 );  mCropSpin[3]->setValue( c.bottom() * 100 );

                mBlocked = false;
        }


        void ObjectEditor::onImageCropDialog()
        {
                if ( mObject && CropDialog::run( this, mObject, mUndoRedoModel ) )
                {
                        loadImagePage();
                }
        }


        void ObjectEditor::onImageCropClear()
        {
                if ( !mObject ) return;
                mUndoRedoModel->checkpoint( tr("Crop") );
                mObject->setImageCrop( QMarginsF() );
                loadImagePage();
        }


        void ObjectEditor::onResetImageSize()
        {
                mUndoRedoModel->checkpoint( tr("Reset") );

                mObject->setSize( mObject->naturalSize() );
        }


        void ObjectEditor::onShadowControlsChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        mUndoRedoModel->checkpoint( tr("Shadow") );

                        mObject->setShadow( shadowEnableCheck->isChecked() );
                        mObject->setShadowX( model::Distance(shadowXSpin->value(), mUnits) );
                        mObject->setShadowY( model::Distance(shadowYSpin->value(), mUnits) );
                        mObject->setShadowColorNode( shadowColorButton->colorNode() );
                        mObject->setShadowOpacity( shadowOpacitySpin->value()/100.0 );

                        mBlocked = false;
                }
        }


        void ObjectEditor::onChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        qDebug() << "Form changed.";

                        mBlocked = false;
                }
        }

} // namespace glabels
