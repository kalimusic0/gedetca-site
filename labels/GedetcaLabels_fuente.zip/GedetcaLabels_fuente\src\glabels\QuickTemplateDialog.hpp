//  QuickTemplateDialog.hpp
//
//  One-window creation of a custom product template (name, shape, size and
//  how many labels fit on the sheet), with a live preview. A simple alternative
//  to the multi-page Product Template Designer.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef QuickTemplateDialog_hpp
#define QuickTemplateDialog_hpp


#include "model/Template.hpp"

#include <QDialog>
#include <QString>


namespace glabels
{

        class QuickTemplateDialog : public QDialog
        {
        public:
                explicit QuickTemplateDialog( QWidget* parent = nullptr, const model::Template* existing = nullptr );

                // Can the template be edited with this window? (one rectangular, round or elliptical frame, one layout)
                static bool canEdit( const model::Template& tmplate );

                // Brand and part number of the template that was saved (empty if cancelled)
                QString savedBrand() const { return mBrand; }
                QString savedPart()  const { return mPart; }

        private:
                bool save();

                struct Widgets;
                Widgets* w{ nullptr };

                QString mBrand;
                QString mPart;
                bool    mEditing{ false };
                QString mOldBrand;
                QString mOldPart;
        };

}


#endif // QuickTemplateDialog_hpp
