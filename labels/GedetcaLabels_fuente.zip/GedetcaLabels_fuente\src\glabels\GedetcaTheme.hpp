//  GedetcaTheme.hpp
//
//  Gedetca look (palette "Oceano": turquoise + blue + mint) for the Qt widgets.
//  Colors derived from gedetca_web/static/tema.css (hue 187).
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef GedetcaTheme_hpp
#define GedetcaTheme_hpp


#include <QPalette>
#include <QString>


namespace glabels::GedetcaTheme
{

        // Use the color theme of gedetca_web (hue, saturation factor, lightness offset in %):
        // the same formulas as static/tema.css, for the dark and the light mode
        void setCustom( double h, double ss, double lb );

        QPalette palette( bool dark );

        QString  styleSheet( bool dark );

}


#endif // GedetcaTheme_hpp
