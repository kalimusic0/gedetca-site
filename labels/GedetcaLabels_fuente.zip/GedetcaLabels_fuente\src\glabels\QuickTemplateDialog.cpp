//  QuickTemplateDialog.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "QuickTemplateDialog.hpp"

#include "model/Db.hpp"
#include "model/Distance.hpp"
#include "model/Frame.hpp"
#include "model/FrameEllipse.hpp"
#include "model/FrameRect.hpp"
#include "model/FrameRound.hpp"
#include "model/Layout.hpp"
#include "model/Markup.hpp"
#include "model/Paper.hpp"
#include "model/Settings.hpp"
#include "model/Template.hpp"
#include "model/Units.hpp"

#include <QCoreApplication>
#include <QDoubleSpinBox>
#include <QComboBox>
#include <QFileInfo>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QPainter>
#include <QPushButton>
#include <QSpinBox>
#include <QVBoxLayout>
#include <QWidget>
#include <algorithm>
#include <cmath>


namespace glabels
{

        namespace
        {
                QString T( const char* s )
                {
                        return QCoreApplication::translate( "glabels::QuickTemplateDialog", s );
                }

                enum Shape { RECT = 0, ROUNDED = 1, ELLIPSE = 2, CIRCLE = 3 };

                // Everything in the units chosen in the preferences
                struct Spec
                {
                        double pageW{ 100 }, pageH{ 100 };
                        double w{ 100 }, h{ 100 }, r{ 0 };
                        int    shape{ RECT };
                        int    nx{ 1 }, ny{ 1 };
                        double x0{ 0 }, y0{ 0 }, dx{ 100 }, dy{ 100 };
                };

                // Sheet with the labels drawn on it
                class Preview : public QWidget
                {
                public:
                        Preview()
                        {
                                setMinimumSize( 240, 240 );
                                setSizePolicy( QSizePolicy::Expanding, QSizePolicy::Expanding );
                        }

                        void setSpec( const Spec& s )
                        {
                                mS = s;
                                update();
                        }

                protected:
                        void paintEvent( QPaintEvent* ) override
                        {
                                QPainter p( this );
                                p.setRenderHint( QPainter::Antialiasing );

                                const double pad = 12;
                                double sx = ( width()  - 2*pad ) / std::max( mS.pageW, 0.001 );
                                double sy = ( height() - 2*pad ) / std::max( mS.pageH, 0.001 );
                                double k  = std::min( sx, sy );
                                double ox = ( width()  - mS.pageW*k ) / 2;
                                double oy = ( height() - mS.pageH*k ) / 2;

                                p.setPen( QPen( QColor( "#8a9aa0" ), 1 ) );
                                p.setBrush( Qt::white );
                                p.drawRect( QRectF( ox, oy, mS.pageW*k, mS.pageH*k ) );

                                p.setPen( QPen( QColor( "#0a7f8f" ), 1.4 ) );
                                p.setBrush( QColor( 10, 127, 143, 30 ) );
                                for ( int j = 0; j < mS.ny; j++ )
                                {
                                        for ( int i = 0; i < mS.nx; i++ )
                                        {
                                                QRectF r( ox + ( mS.x0 + i*mS.dx )*k, oy + ( mS.y0 + j*mS.dy )*k, mS.w*k, mS.h*k );
                                                if ( mS.shape == ELLIPSE || mS.shape == CIRCLE )
                                                {
                                                        p.drawEllipse( r );
                                                }
                                                else if ( mS.shape == ROUNDED )
                                                {
                                                        p.drawRoundedRect( r, mS.r*k, mS.r*k );
                                                }
                                                else
                                                {
                                                        p.drawRect( r );
                                                }
                                        }
                                }
                        }

                private:
                        Spec mS;
                };

                QDoubleSpinBox* makeSpin( double value, double min = 0 )
                {
                        model::Units u = model::Settings::units();
                        auto* s = new QDoubleSpinBox();
                        s->setSuffix( " " + u.toTrName() );
                        s->setDecimals( u.resolutionDigits() );
                        s->setSingleStep( u.resolution() );
                        s->setRange( min, 5000 );
                        s->setValue( value );
                        return s;
                }
        }


        struct QuickTemplateDialog::Widgets
        {
                QLineEdit*      name;
                QComboBox*      shape;
                QLabel*         wLabel;
                QDoubleSpinBox* wSpin;
                QLabel*         hLabel;
                QDoubleSpinBox* hSpin;
                QLabel*         rLabel;
                QDoubleSpinBox* rSpin;
                QComboBox*      mode;
                QWidget*        sheetBox;
                QComboBox*      paper;
                QDoubleSpinBox* pageW;
                QDoubleSpinBox* pageH;
                QSpinBox*       nx;
                QSpinBox*       ny;
                QDoubleSpinBox* x0;
                QDoubleSpinBox* y0;
                QDoubleSpinBox* gx;
                QDoubleSpinBox* gy;
                Preview*        preview;

                Spec spec() const
                {
                        Spec s;
                        s.shape = shape->currentIndex();
                        s.w     = wSpin->value();
                        s.h     = ( s.shape == CIRCLE ) ? s.w : hSpin->value();
                        s.r     = std::min( rSpin->value(), std::min( s.w, s.h ) / 2 );

                        if ( mode->currentIndex() == 0 )
                        {
                                // One label per sheet: the sheet is the label
                                s.pageW = s.w;
                                s.pageH = s.h;
                                s.nx = s.ny = 1;
                                s.x0 = s.y0 = 0;
                                s.dx = s.w;
                                s.dy = s.h;
                        }
                        else
                        {
                                s.pageW = pageW->value();
                                s.pageH = pageH->value();
                                s.nx = nx->value();
                                s.ny = ny->value();
                                s.x0 = x0->value();
                                s.y0 = y0->value();
                                s.dx = s.w + gx->value();
                                s.dy = s.h + gy->value();
                        }
                        return s;
                }
        };


        QuickTemplateDialog::QuickTemplateDialog( QWidget* parent, const model::Template* existing )
                : QDialog( parent ), w( new Widgets )
        {
                setWindowTitle( T( "Quick template" ) );
                model::Units units = model::Settings::units();
                bool mm = ( units.toEnum() == model::Units::MM );

                w->name = new QLineEdit();
                w->name->setPlaceholderText( T( "e.g. Label 100x100" ) );

                // --- Label
                w->shape = new QComboBox();
                w->shape->addItems( { T( "Rectangle" ), T( "Rounded corners" ), T( "Ellipse" ), T( "Circle" ) } );
                w->wLabel = new QLabel( T( "Width:" ) );
                w->wSpin  = makeSpin( mm ? 100 : 4, 0.1 );
                w->hLabel = new QLabel( T( "Height:" ) );
                w->hSpin  = makeSpin( mm ? 100 : 4, 0.1 );
                w->rLabel = new QLabel( T( "Corner radius:" ) );
                w->rSpin  = makeSpin( mm ? 3 : 0.125 );

                auto* labelBox = new QGroupBox( T( "Label" ) );
                auto* labelGrid = new QGridLayout( labelBox );
                labelGrid->addWidget( new QLabel( T( "Shape:" ) ), 0, 0 );
                labelGrid->addWidget( w->shape, 0, 1 );
                labelGrid->addWidget( w->wLabel, 1, 0 );
                labelGrid->addWidget( w->wSpin,  1, 1 );
                labelGrid->addWidget( w->hLabel, 2, 0 );
                labelGrid->addWidget( w->hSpin,  2, 1 );
                labelGrid->addWidget( w->rLabel, 3, 0 );
                labelGrid->addWidget( w->rSpin,  3, 1 );

                // --- Sheet
                w->mode = new QComboBox();
                w->mode->addItems( { T( "One label per sheet (roll or single label)" ), T( "Several labels per sheet" ) } );

                w->paper = new QComboBox();
                w->paper->addItem( T( "Custom" ) );
                w->paper->addItems( model::Db::paperNames() );
                {
                        int i = w->paper->findText( "A4" );
                        w->paper->setCurrentIndex( i >= 0 ? i : 0 );
                }
                w->pageW = makeSpin( mm ? 210 : 8.5, 1 );
                w->pageH = makeSpin( mm ? 297 : 11, 1 );
                w->nx = new QSpinBox(); w->nx->setRange( 1, 200 ); w->nx->setValue( 2 );
                w->ny = new QSpinBox(); w->ny->setRange( 1, 200 ); w->ny->setValue( 4 );
                w->x0 = makeSpin( 0 );
                w->y0 = makeSpin( 0 );
                w->gx = makeSpin( 0 );
                w->gy = makeSpin( 0 );
                auto* centerButton = new QPushButton( T( "Center on sheet" ) );

                w->sheetBox = new QWidget();
                auto* sheetGrid = new QGridLayout( w->sheetBox );
                sheetGrid->setContentsMargins( 0, 0, 0, 0 );
                sheetGrid->addWidget( new QLabel( T( "Paper:" ) ), 0, 0 );
                sheetGrid->addWidget( w->paper, 0, 1, 1, 3 );
                sheetGrid->addWidget( new QLabel( T( "Sheet width:" ) ), 1, 0 );
                sheetGrid->addWidget( w->pageW, 1, 1 );
                sheetGrid->addWidget( new QLabel( T( "Sheet height:" ) ), 1, 2 );
                sheetGrid->addWidget( w->pageH, 1, 3 );
                sheetGrid->addWidget( new QLabel( T( "Columns:" ) ), 2, 0 );
                sheetGrid->addWidget( w->nx, 2, 1 );
                sheetGrid->addWidget( new QLabel( T( "Rows:" ) ), 2, 2 );
                sheetGrid->addWidget( w->ny, 2, 3 );
                sheetGrid->addWidget( new QLabel( T( "Left margin:" ) ), 3, 0 );
                sheetGrid->addWidget( w->x0, 3, 1 );
                sheetGrid->addWidget( new QLabel( T( "Top margin:" ) ), 3, 2 );
                sheetGrid->addWidget( w->y0, 3, 3 );
                sheetGrid->addWidget( new QLabel( T( "Horizontal gap:" ) ), 4, 0 );
                sheetGrid->addWidget( w->gx, 4, 1 );
                sheetGrid->addWidget( new QLabel( T( "Vertical gap:" ) ), 4, 2 );
                sheetGrid->addWidget( w->gy, 4, 3 );
                sheetGrid->addWidget( centerButton, 5, 0, 1, 4 );

                auto* sheetBox = new QGroupBox( T( "Sheet" ) );
                auto* sheetLayout = new QVBoxLayout( sheetBox );
                sheetLayout->addWidget( w->mode );
                sheetLayout->addWidget( w->sheetBox );

                w->preview = new Preview();

                auto* left = new QVBoxLayout();
                auto* nameRow = new QHBoxLayout();
                nameRow->addWidget( new QLabel( T( "Name:" ) ) );
                nameRow->addWidget( w->name, 1 );
                left->addLayout( nameRow );
                left->addWidget( labelBox );
                left->addWidget( sheetBox );
                left->addStretch( 1 );

                auto* saveButton   = new QPushButton( T( "Save" ) );
                auto* cancelButton = new QPushButton( T( "Cancel" ) );
                saveButton->setDefault( true );
                auto* buttons = new QHBoxLayout();
                buttons->addStretch( 1 );
                buttons->addWidget( saveButton );
                buttons->addWidget( cancelButton );

                auto* body = new QHBoxLayout();
                body->addLayout( left, 1 );
                body->addWidget( w->preview, 1 );

                auto* main = new QVBoxLayout( this );
                main->addLayout( body, 1 );
                main->addLayout( buttons );

                // --- Behavior
                Widgets* ws = w;
                auto refresh = [ws]()
                {
                        int shape = ws->shape->currentIndex();
                        ws->hLabel->setVisible( shape != CIRCLE );
                        ws->hSpin->setVisible( shape != CIRCLE );
                        ws->rLabel->setVisible( shape == ROUNDED );
                        ws->rSpin->setVisible( shape == ROUNDED );
                        ws->wLabel->setText( shape == CIRCLE ? T( "Diameter:" ) : T( "Width:" ) );

                        ws->sheetBox->setVisible( ws->mode->currentIndex() == 1 );
                        bool custom = ( ws->paper->currentIndex() == 0 );
                        ws->pageW->setEnabled( custom );
                        ws->pageH->setEnabled( custom );

                        ws->preview->setSpec( ws->spec() );
                };

                connect( w->paper, &QComboBox::currentIndexChanged, this, [ws, refresh]( int i )
                {
                        if ( i > 0 )
                        {
                                auto paper = model::Db::lookupPaperFromName( ws->paper->currentText() );
                                model::Units u = model::Settings::units();
                                ws->pageW->setValue( paper.width().inUnits( u ) );
                                ws->pageH->setValue( paper.height().inUnits( u ) );
                        }
                        refresh();
                } );

                for ( auto* combo : { w->shape, w->mode } )
                {
                        connect( combo, &QComboBox::currentIndexChanged, this, [refresh]( int ) { refresh(); } );
                }
                for ( auto* spin : { w->wSpin, w->hSpin, w->rSpin, w->pageW, w->pageH, w->x0, w->y0, w->gx, w->gy } )
                {
                        connect( spin, &QDoubleSpinBox::valueChanged, this, [refresh]( double ) { refresh(); } );
                }
                for ( auto* spin : { w->nx, w->ny } )
                {
                        connect( spin, &QSpinBox::valueChanged, this, [refresh]( int ) { refresh(); } );
                }

                connect( centerButton, &QPushButton::clicked, this, [ws]()
                {
                        Spec s = ws->spec();
                        double usedW = s.nx*s.w + ( s.nx - 1 )*ws->gx->value();
                        double usedH = s.ny*s.h + ( s.ny - 1 )*ws->gy->value();
                        ws->x0->setValue( std::max( 0.0, ( s.pageW - usedW ) / 2 ) );
                        ws->y0->setValue( std::max( 0.0, ( s.pageH - usedH ) / 2 ) );
                } );

                connect( saveButton,   &QPushButton::clicked, this, [this]() { if ( save() ) accept(); } );
                connect( cancelButton, &QPushButton::clicked, this, &QDialog::reject );

                // set the sheet from the default paper
                if ( w->paper->currentIndex() > 0 )
                {
                        auto paper = model::Db::lookupPaperFromName( w->paper->currentText() );
                        w->pageW->setValue( paper.width().inUnits( units ) );
                        w->pageH->setValue( paper.height().inUnits( units ) );
                }

                if ( existing )
                {
                        setWindowTitle( T( "Edit template" ) );
                        mEditing = true;
                        mOldBrand = existing->brand();
                        mOldPart  = existing->part();
                        w->name->setText( existing->part() );

                        const model::Frame* f = existing->frame();
                        auto I = [units]( model::Distance d ) { return d.inUnits( units ); };

                        if ( auto* rc = dynamic_cast<const model::FrameRect*>( f ) )
                        {
                                w->shape->setCurrentIndex( rc->r().pt() > 0.01 ? ROUNDED : RECT );
                                w->wSpin->setValue( I( rc->w() ) );
                                w->hSpin->setValue( I( rc->h() ) );
                                w->rSpin->setValue( I( rc->r() ) );
                        }
                        else if ( dynamic_cast<const model::FrameRound*>( f ) )
                        {
                                w->shape->setCurrentIndex( CIRCLE );
                                w->wSpin->setValue( I( f->w() ) );
                        }
                        else
                        {
                                w->shape->setCurrentIndex( ELLIPSE );
                                w->wSpin->setValue( I( f->w() ) );
                                w->hSpin->setValue( I( f->h() ) );
                        }

                        const model::Layout& layout = f->layouts().front();
                        bool single = layout.nx() == 1 && layout.ny() == 1 &&
                                      std::fabs( layout.x0().pt() ) < 0.01 && std::fabs( layout.y0().pt() ) < 0.01 &&
                                      std::fabs( existing->pageWidth().pt()  - f->w().pt() ) < 0.5 &&
                                      std::fabs( existing->pageHeight().pt() - f->h().pt() ) < 0.5;
                        if ( single )
                        {
                                w->mode->setCurrentIndex( 0 );
                        }
                        else
                        {
                                w->mode->setCurrentIndex( 1 );
                                if ( model::Db::isPaperIdKnown( existing->paperId() ) )
                                {
                                        int i = w->paper->findText( model::Db::lookupPaperNameFromId( existing->paperId() ) );
                                        w->paper->setCurrentIndex( i >= 0 ? i : 0 );
                                }
                                else
                                {
                                        w->paper->setCurrentIndex( 0 );
                                }
                                if ( w->paper->currentIndex() == 0 )
                                {
                                        w->pageW->setValue( I( existing->pageWidth() ) );
                                        w->pageH->setValue( I( existing->pageHeight() ) );
                                }
                                w->nx->setValue( layout.nx() );
                                w->ny->setValue( layout.ny() );
                                w->x0->setValue( I( layout.x0() ) );
                                w->y0->setValue( I( layout.y0() ) );
                                w->gx->setValue( std::max( 0.0, I( layout.dx() ) - I( f->w() ) ) );
                                w->gy->setValue( std::max( 0.0, I( layout.dy() ) - I( f->h() ) ) );
                        }
                }
                refresh();
        }


        bool QuickTemplateDialog::canEdit( const model::Template& tmplate )
        {
                if ( tmplate.isNull() || !tmplate.isUserDefined() )
                {
                        return false;
                }
                const model::Frame* f = tmplate.frame();
                if ( !f || f->layouts().size() != 1 )
                {
                        return false;
                }
                return dynamic_cast<const model::FrameRect*>( f )    ||
                       dynamic_cast<const model::FrameRound*>( f )   ||
                       dynamic_cast<const model::FrameEllipse*>( f );
        }


        bool QuickTemplateDialog::save()
        {
                QString part = w->name->text().trimmed();
                if ( part.isEmpty() )
                {
                        QMessageBox::warning( this, T( "Quick template" ), T( "Enter a name for the template." ) );
                        w->name->setFocus();
                        return false;
                }

                Spec s = w->spec();
                // The labels must fit on the sheet
                double tol = 0.01;
                if ( s.x0 + ( s.nx - 1 )*s.dx + s.w > s.pageW + tol || s.y0 + ( s.ny - 1 )*s.dy + s.h > s.pageH + tol )
                {
                        QMessageBox::warning( this, T( "Quick template" ),
                                              T( "The labels do not fit on the sheet. Adjust the margins, gaps or the number of labels." ) );
                        return false;
                }

                model::Units u = model::Settings::units();
                auto D = [u]( double v ) { return model::Distance( v, u ); };

                const QString brand = mEditing ? mOldBrand : QString( "Gedetca" );
                QString paperId;
                if ( w->mode->currentIndex() == 1 && w->paper->currentIndex() > 0 )
                {
                        paperId = model::Db::lookupPaperIdFromName( w->paper->currentText() );
                }

                bool sameAsOld = mEditing && part == mOldPart;
                QString filename = model::Db::userTemplateFileName( brand, part );
                if ( mEditing && !sameAsOld && ( QFileInfo::exists( filename ) || model::Db::isTemplateKnown( brand, part ) ) )
                {
                        QMessageBox::warning( this, T( "Quick template" ),
                                              T( "A template named \"%1\" already exists." ).arg( part ) );
                        return false;
                }
                if ( !mEditing && QFileInfo::exists( filename ) )
                {
                        QMessageBox box( this );
                        box.setWindowTitle( T( "Quick template" ) );
                        box.setIcon( QMessageBox::Warning );
                        box.setText( T( "A template named \"%1\" already exists." ).arg( part ) );
                        box.setInformativeText( T( "Do you want to replace it?" ) );
                        auto* yes = box.addButton( T( "Replace" ), QMessageBox::YesRole );
                        auto* no  = box.addButton( T( "Cancel" ),  QMessageBox::NoRole );
                        box.setDefaultButton( no );
                        box.exec();
                        if ( box.clickedButton() != yes )
                        {
                                return false;
                        }
                        model::Db::deleteUserTemplateByBrandPart( brand, part );
                }

                QString desc = QString( "%1 x %2 %3" ).arg( s.w ).arg( s.h ).arg( u.toTrName() );
                model::Template t( brand, part, desc, paperId, D( s.pageW ), D( s.pageH ), D( 0 ), "", true );

                if ( s.shape == CIRCLE )
                {
                        model::FrameRound frame( D( s.w / 2 ), D( 0 ) );
                        frame.addMarkup( model::MarkupMargin( D( 0 ) ) );
                        frame.addLayout( model::Layout( s.nx, s.ny, D( s.x0 ), D( s.y0 ), D( s.dx ), D( s.dy ) ) );
                        t.addFrame( frame );
                }
                else if ( s.shape == ELLIPSE )
                {
                        model::FrameEllipse frame( D( s.w ), D( s.h ), D( 0 ) );
                        frame.addMarkup( model::MarkupMargin( D( 0 ) ) );
                        frame.addLayout( model::Layout( s.nx, s.ny, D( s.x0 ), D( s.y0 ), D( s.dx ), D( s.dy ) ) );
                        t.addFrame( frame );
                }
                else
                {
                        model::FrameRect frame( D( s.w ), D( s.h ), D( s.shape == ROUNDED ? s.r : 0 ), D( 0 ), D( 0 ) );
                        frame.addMarkup( model::MarkupMargin( D( 0 ), D( 0 ) ) );
                        frame.addLayout( model::Layout( s.nx, s.ny, D( s.x0 ), D( s.y0 ), D( s.dx ), D( s.dy ) ) );
                        t.addFrame( frame );
                }

                if ( mEditing && sameAsOld )
                {
                        model::Db::deleteUserTemplateByBrandPart( brand, part );   // replaced by the edited one
                }
                model::Db::registerUserTemplate( t );
                if ( mEditing && !sameAsOld )
                {
                        model::Db::deleteUserTemplateByBrandPart( mOldBrand, mOldPart );   // it was renamed
                }
                mBrand = brand;
                mPart  = part;
                return true;
        }

}
