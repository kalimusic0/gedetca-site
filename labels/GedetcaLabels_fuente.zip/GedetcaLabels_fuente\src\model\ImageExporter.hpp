//  ImageExporter.hpp
//
//  Exports a label to PNG image(s): one image per selected merge record
//  (or a single image when the project has no merge).
//
//  The target can be a file name or a folder, and may contain tokens:
//      {name}      project name            {date}   yyyyMMdd
//      {time}      HHmmss                  {datetime} yyyyMMdd_HHmmss
//      {n}         image number (0001...)  {field}  any merge field / variable
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_ImageExporter_hpp
#define model_ImageExporter_hpp


#include "Model.hpp"
#include "Variables.hpp"

#include "merge/Record.hpp"

#include <QImage>
#include <QString>
#include <QStringList>


namespace glabels::model
{

        class ImageExporter
        {
        public:
                struct Options
                {
                        double dpi{ 300 };
                        bool   transparent{ false };   // transparent background instead of white
                        bool   clipToShape{ false };   // cut the image to the label shape (round, ellipse...)
                };

                // Renders one label with the given merge record
                static QImage render( const Model*        model,
                                      const merge::Record& record,
                                      const Variables&     variables,
                                      const Options&       options );

                // Writes the PNG file(s).  Returns the list of files written; on error the
                // list is empty (or partial) and 'error' receives the reason.
                static QStringList exportPng( Model*          model,
                                              const QString&  target,
                                              const Options&  options,
                                              QString*        error = nullptr );

                // The folder used when 'target' is not given
                static QString defaultFolder();

                // Replaces the tokens of a file name pattern
                static QString expandPattern( const QString&       pattern,
                                              const QString&       projectName,
                                              int                  index,
                                              int                  count,
                                              const merge::Record& record,
                                              const Variables&     variables );
        };

}


#endif // model_ImageExporter_hpp
