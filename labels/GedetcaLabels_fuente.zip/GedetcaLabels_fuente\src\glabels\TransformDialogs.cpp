//  TransformDialogs.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "TransformDialogs.hpp"

#include "model/TextScript.hpp"

#include <QDialogButtonBox>
#include <QFontDatabase>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QTextCursor>
#include <QToolButton>
#include <QVBoxLayout>


namespace glabels
{

        using Action = model::TextFormat::ReplaceAction;


        ///////////////////////////////////////////////////////////////////
        // SearchReplaceDialog
        ///////////////////////////////////////////////////////////////////

        SearchReplaceDialog::SearchReplaceDialog( const QList<Action>& actions, QWidget* parent )
                : QDialog( parent ), mActions( actions )
        {
                setWindowTitle( tr("Search and replace") );
                resize( 620, 440 );

                // Left: list of actions
                auto* listLabel = new QLabel( tr("Actions:") );
                mList = new QListWidget();

                auto* addButton = new QToolButton();    addButton->setText( "+" );     addButton->setToolTip( tr("Add action") );
                auto* removeButton = new QToolButton(); removeButton->setText( "−" );  removeButton->setToolTip( tr("Remove action") );
                auto* upButton = new QToolButton();     upButton->setText( "▲" );      upButton->setToolTip( tr("Move up") );
                auto* downButton = new QToolButton();   downButton->setText( "▼" );    downButton->setToolTip( tr("Move down") );
                auto* listButtons = new QHBoxLayout();
                listButtons->addWidget( addButton );
                listButtons->addWidget( removeButton );
                listButtons->addWidget( upButton );
                listButtons->addWidget( downButton );
                listButtons->addStretch( 1 );

                auto* left = new QVBoxLayout();
                left->addWidget( listLabel );
                left->addWidget( mList, 1 );
                left->addLayout( listButtons );

                // Right: action options
                auto* box = new QGroupBox( tr("Action options") );
                auto* form = new QFormLayout( box );

                mDescription = new QLineEdit();
                form->addRow( tr("Description:"), mDescription );

                mKind = new QComboBox();
                mKind->addItem( tr("Search and replace" ) );
                mKind->addItem( tr("Trim spaces (start and end)" ) );
                form->addRow( tr("Action:"), mKind );

                mFind = new QPlainTextEdit();
                mFind->setMaximumHeight( 80 );
                form->addRow( tr("Search:"), mFind );

                mSyntax = new QComboBox();
                mSyntax->addItem( tr("Use wildcards (* and ?)") );
                mSyntax->addItem( tr("Exact text") );
                mSyntax->addItem( tr("Regular expression") );
                form->addRow( tr("Syntax:"), mSyntax );

                mFirstOnly = new QCheckBox( tr("First instance only") );
                form->addRow( mFirstOnly );

                mReplace = new QPlainTextEdit();
                mReplace->setMaximumHeight( 80 );
                form->addRow( tr("Replace with:"), mReplace );

                auto* testButton = new QPushButton( tr("Test...") );
                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );

                auto* bottom = new QHBoxLayout();
                bottom->addWidget( testButton );
                bottom->addStretch( 1 );
                bottom->addWidget( buttons );

                auto* top = new QHBoxLayout();
                top->addLayout( left, 1 );
                top->addWidget( box, 2 );

                auto* main = new QVBoxLayout( this );
                main->addLayout( top, 1 );
                main->addLayout( bottom );

                connect( addButton, SIGNAL(clicked()), this, SLOT(onAdd()) );
                connect( removeButton, SIGNAL(clicked()), this, SLOT(onRemove()) );
                connect( upButton, SIGNAL(clicked()), this, SLOT(onUp()) );
                connect( downButton, SIGNAL(clicked()), this, SLOT(onDown()) );
                connect( mList, SIGNAL(currentRowChanged(int)), this, SLOT(onRowChanged(int)) );
                connect( mDescription, SIGNAL(textEdited(QString)), this, SLOT(onFieldEdited()) );
                connect( mKind, SIGNAL(currentIndexChanged(int)), this, SLOT(onFieldEdited()) );
                connect( mFind, SIGNAL(textChanged()), this, SLOT(onFieldEdited()) );
                connect( mSyntax, SIGNAL(currentIndexChanged(int)), this, SLOT(onFieldEdited()) );
                connect( mFirstOnly, SIGNAL(toggled(bool)), this, SLOT(onFieldEdited()) );
                connect( mReplace, SIGNAL(textChanged()), this, SLOT(onFieldEdited()) );
                connect( testButton, SIGNAL(clicked()), this, SLOT(onTest()) );
                connect( buttons, SIGNAL(accepted()), this, SLOT(accept()) );
                connect( buttons, SIGNAL(rejected()), this, SLOT(reject()) );

                refreshList( mActions.isEmpty() ? -1 : 0 );
        }


        void SearchReplaceDialog::refreshList( int select )
        {
                mBlocked = true;
                mList->clear();
                for ( int i = 0; i < mActions.size(); i++ )
                {
                        QString name = mActions[i].description.isEmpty() ? tr("Action%1").arg( i + 1 ) : mActions[i].description;
                        mList->addItem( name );
                }
                if ( select >= 0 && select < mList->count() )
                {
                        mList->setCurrentRow( select );
                }
                mBlocked = false;
                loadRow( mList->currentRow() );
        }


        void SearchReplaceDialog::loadRow( int row )
        {
                mBlocked = true;
                bool valid = ( row >= 0 && row < mActions.size() );
                if ( valid )
                {
                        const Action& a = mActions[row];
                        mDescription->setText( a.description );
                        mKind->setCurrentIndex( int(a.kind) );
                        mFind->setPlainText( a.find );
                        mSyntax->setCurrentIndex( int(a.syntax) );
                        mFirstOnly->setChecked( a.firstOnly );
                        mReplace->setPlainText( a.replace );
                }
                else
                {
                        mDescription->clear();
                        mKind->setCurrentIndex( 0 );
                        mFind->clear();
                        mSyntax->setCurrentIndex( 0 );
                        mFirstOnly->setChecked( false );
                        mReplace->clear();
                }
                mBlocked = false;
                updateEnabled();
        }


        void SearchReplaceDialog::updateEnabled()
        {
                bool valid = ( mList->currentRow() >= 0 );
                bool replace = valid && ( mKind->currentIndex() == int(Action::FIND_REPLACE) );
                mDescription->setEnabled( valid );
                mKind->setEnabled( valid );
                mFind->setEnabled( replace );
                mSyntax->setEnabled( replace );
                mFirstOnly->setEnabled( replace );
                mReplace->setEnabled( replace );
        }


        void SearchReplaceDialog::onAdd()
        {
                Action a;
                a.description = tr("Action%1").arg( mActions.size() + 1 );
                mActions << a;
                refreshList( mActions.size() - 1 );
        }


        void SearchReplaceDialog::onRemove()
        {
                int row = mList->currentRow();
                if ( row >= 0 && row < mActions.size() )
                {
                        mActions.removeAt( row );
                        refreshList( qMin( row, mActions.size() - 1 ) );
                }
        }


        void SearchReplaceDialog::onUp()
        {
                int row = mList->currentRow();
                if ( row > 0 )
                {
                        mActions.swapItemsAt( row, row - 1 );
                        refreshList( row - 1 );
                }
        }


        void SearchReplaceDialog::onDown()
        {
                int row = mList->currentRow();
                if ( row >= 0 && row < mActions.size() - 1 )
                {
                        mActions.swapItemsAt( row, row + 1 );
                        refreshList( row + 1 );
                }
        }


        void SearchReplaceDialog::onRowChanged( int row )
        {
                if ( !mBlocked )
                {
                        loadRow( row );
                }
        }


        void SearchReplaceDialog::onFieldEdited()
        {
                if ( mBlocked ) return;

                int row = mList->currentRow();
                if ( row < 0 || row >= mActions.size() ) return;

                Action& a = mActions[row];
                a.description = mDescription->text();
                a.kind        = Action::Kind( mKind->currentIndex() );
                a.find        = mFind->toPlainText();
                a.syntax      = Action::Syntax( mSyntax->currentIndex() );
                a.firstOnly   = mFirstOnly->isChecked();
                a.replace     = mReplace->toPlainText();

                QString name = a.description.isEmpty() ? tr("Action%1").arg( row + 1 ) : a.description;
                mBlocked = true;
                mList->item( row )->setText( name );
                mBlocked = false;

                updateEnabled();
        }


        void SearchReplaceDialog::onTest()
        {
                bool ok = false;
                QString sample = QInputDialog::getText( this, tr("Test"), tr("Sample text:"),
                                                        QLineEdit::Normal, QString(), &ok );
                if ( !ok ) return;

                model::TextFormat tf;
                tf.replaceActions = mActions;
                QString result = tf.process( sample, merge::Record(), model::Variables() );

                QMessageBox::information( this, tr("Test"), tr("Result:") + "\n\n" + result );
        }


        ///////////////////////////////////////////////////////////////////
        // ScriptDialog
        ///////////////////////////////////////////////////////////////////

        ScriptDialog::ScriptDialog( const QString& script, const QStringList& fieldNames, QWidget* parent )
                : QDialog( parent )
        {
                setWindowTitle( tr("Command script") );
                resize( 620, 460 );

                auto* help = new QLabel( tr(
                        "JavaScript. The script receives the text in <b>Value</b> and the merge fields and variables in "
                        "<b>Fields</b> (e.g. <code>Fields.lote</code>). Leave the result in <b>Value</b>.<br>"
                        "Use <b>Insert example...</b> for ready-made commands such as <code>RestarDias(Value, 1)</code>, "
                        "or write any JavaScript code (conditions, loops, functions...). Both can be mixed.<br>"
                        "The script cannot access files, the network or the system, and it is stopped if it runs for "
                        "more than half a second." ) );
                help->setWordWrap( true );
                help->setTextFormat( Qt::RichText );

                mEdit = new ScriptEdit();
                mEdit->setFieldNames( fieldNames );
                mEdit->setFont( QFontDatabase::systemFont( QFontDatabase::FixedFont ) );
                mEdit->setPlainText( script );
                mEdit->setTabStopDistance( 28 );

                // Ready-made examples: pick one and it is inserted at the cursor
                struct Example { const char* name; const char* code; };
                static const Example EXAMPLES[] = {
                        { "Restar días a una fecha",
                          "// Resta 1 día a una fecha (19/10/2026 -> 18/10/2026). Cambia el 1.\nValue = RestarDias(Value, 1);" },
                        { "Sumar días a una fecha",
                          "// Suma 30 días a una fecha. Cambia el 30.\nValue = SumarDias(Value, 30);" },
                        { "Sumar meses a una fecha",
                          "// Suma 6 meses a una fecha. Cambia el 6.\nValue = SumarMeses(Value, 6);" },
                        { "Cambiar / por -",
                          "// 40/50 -> 40-50\nValue = Reemplazar(Value, \"/\", \"-\");" },
                        { "Rellenar con ceros a la izquierda",
                          "// 123 -> 00000123 (largo 8)\nValue = RellenarIzquierda(Value, 8, \"0\");" },
                        { "Poner en MAYÚSCULAS",
                          "Value = Mayusculas(Value);" },
                        { "Poner en minúsculas",
                          "Value = Minusculas(Value);" },
                        { "Primera letra de cada palabra en mayúscula",
                          "// juan perez -> Juan Perez\nValue = PrimeraMayuscula(Value);" },
                        { "Quitar espacios sobrantes",
                          "Value = Recortar(Value);" },
                        { "Quitar los primeros 2 caracteres",
                          "Value = QuitarInicio(Value, 2);" },
                        { "Quitar los últimos 2 caracteres",
                          "Value = QuitarFinal(Value, 2);" },
                        { "Quedarse con los primeros 5 caracteres",
                          "Value = Primeros(Value, 5);" },
                        { "Quedarse con los últimos 4 caracteres",
                          "Value = Ultimos(Value, 4);" },
                        { "Agregar el valor de un campo",
                          "// Pone el campo \"lote\" delante del texto\nValue = Campo(\"lote\") + \"-\" + Value;" },
                        { "Según el valor de otro objeto (como en BarTender)",
                          "// Si el objeto TALLA muestra 40/50, este texto muestra otro valor\nif (Objeto(\"TALLA\") == \"40/50\") {\n    Value = \"44561589\";\n}" },
                        { "Según una variable del proyecto",
                          "if (Variable(\"prod_talla\") == \"40/50\") {\n    Value = \"44561589\";\n}" },
                        { "Con palabras en español (si / sino)",
                          "variable talla = Variable(\"prod_talla\");\nsi (talla == \"40/50\") {\n    Valor = \"44561589\";\n} sino si (talla == \"50/60\" o talla == \"60/70\") {\n    Valor = \"44561590\";\n} sino {\n    Valor = talla;\n}" },
                        { "Si está vacío, poner un texto",
                          "if (Value == \"\") {\n    Value = \"SIN DATO\";\n}" },
                        { "Decidir según un campo (código)",
                          "if (Campo(\"modo\") == \"X\") {\n    Value = \"\";\n} else {\n    Value = Value + \" kg\";\n}" },
                        { "Separar cada carácter con guion (código)",
                          "// ABC -> A-B-C\nvar r = [];\nfor (var i = 0; i < Value.length; i++) {\n    r.push(Value.charAt(i));\n}\nValue = r.join(\"-\");" },
                };

                auto* examples = new QComboBox();
                examples->addItem( tr("Insert example...") );
                for ( const auto& e : EXAMPLES )
                {
                        examples->addItem( QString::fromUtf8( e.name ), QString::fromUtf8( e.code ) );
                }
                examples->setMaxVisibleItems( 20 );
                connect( examples, QOverload<int>::of( &QComboBox::activated ), this, [this, examples]( int index )
                {
                        if ( index <= 0 ) return;

                        QString code = examples->itemData( index ).toString();
                        QTextCursor tc = mEdit->textCursor();
                        bool atLineStart = tc.atBlockStart();
                        if ( !atLineStart )
                        {
                                code = "\n" + code;
                        }
                        mEdit->insertPlainText( code + "\n" );
                        examples->setCurrentIndex( 0 );
                        mEdit->setFocus();
                } );

                auto* testButton = new QPushButton( tr("Test...") );
                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
                auto* bottom = new QHBoxLayout();
                bottom->addWidget( examples );
                bottom->addWidget( testButton );
                bottom->addStretch( 1 );
                bottom->addWidget( buttons );

                auto* main = new QVBoxLayout( this );
                main->addWidget( help );
                main->addWidget( mEdit, 1 );
                main->addLayout( bottom );

                connect( testButton, SIGNAL(clicked()), this, SLOT(onTest()) );
                connect( buttons, SIGNAL(accepted()), this, SLOT(accept()) );
                connect( buttons, SIGNAL(rejected()), this, SLOT(reject()) );
        }


        QString ScriptDialog::script() const
        {
                return mEdit->toPlainText();
        }


        void ScriptDialog::onTest()
        {
                bool ok = false;
                QString sample = QInputDialog::getText( this, tr("Test"), tr("Sample text (Value):"),
                                                        QLineEdit::Normal, QString(), &ok );
                if ( !ok ) return;

                QString out, error;
                bool success = model::TextScript::run( mEdit->toPlainText(), sample, {}, out, &error );

                if ( success )
                {
                        QMessageBox::information( this, tr("Test"), tr("Result:") + "\n\n" + out );
                }
                else
                {
                        QMessageBox::warning( this, tr("Test"), tr("Script error:") + "\n\n" + error );
                }
        }


        ///////////////////////////////////////////////////////////////////
        // SerializationDialog
        ///////////////////////////////////////////////////////////////////

        SerializationDialog::SerializationDialog( const model::TextFormat& f, QWidget* parent )
                : QDialog( parent )
        {
                setWindowTitle( tr("Serialization") );

                mNoneRadio      = new QRadioButton( tr("Do not serialize") );
                mIncrementRadio = new QRadioButton( tr("Increment") );
                mDecrementRadio = new QRadioButton( tr("Decrement") );
                auto* modeRow = new QHBoxLayout();
                modeRow->addWidget( mNoneRadio );
                modeRow->addWidget( mIncrementRadio );
                modeRow->addWidget( mDecrementRadio );
                modeRow->addStretch( 1 );

                mMethodCombo = new QComboBox();
                mMethodCombo->addItem( tr("Alphabetic and/or numeric") );
                mMethodCombo->addItem( tr("Numeric only") );
                mMethodCombo->addItem( tr("Alphabetic only") );

                mLettersCombo = new QComboBox();
                mLettersCombo->addItem( tr("Upper case A-Z") );
                mLettersCombo->addItem( tr("Lower case a-z") );

                mPreserveCheck = new QCheckBox( tr("Preserve the number of characters") );

                mStepSpin = new QSpinBox();
                mStepSpin->setRange( 1, 1000000 );

                auto* form = new QFormLayout();
                form->addRow( tr("Method:"), mMethodCombo );
                form->addRow( tr("Letters:"), mLettersCombo );
                form->addRow( mPreserveCheck );
                form->addRow( tr("Increment by:"), mStepSpin );

                auto* whenBox = new QGroupBox( tr("When to increment") );
                auto* whenForm = new QFormLayout( whenBox );
                mEventCombo = new QComboBox();
                mEventCombo->addItem( tr("Every label") );
                mEventCombo->addItem( tr("Every copy") );
                mEventCombo->addItem( tr("Every page") );
                mIntervalSpin = new QSpinBox();
                mIntervalSpin->setRange( 1, 1000000 );
                whenForm->addRow( tr("Event:"), mEventCombo );
                whenForm->addRow( tr("Event interval:"), mIntervalSpin );

                auto* previewButton = new QPushButton( tr("Sequence preview...") );
                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
                auto* bottom = new QHBoxLayout();
                bottom->addWidget( previewButton );
                bottom->addStretch( 1 );
                bottom->addWidget( buttons );

                auto* main = new QVBoxLayout( this );
                main->addLayout( modeRow );
                main->addLayout( form );
                main->addWidget( whenBox );
                main->addStretch( 1 );
                main->addLayout( bottom );

                // Initial state
                mNoneRadio->setChecked( f.serialMode == model::TextFormat::SERIAL_NONE );
                mIncrementRadio->setChecked( f.serialMode == model::TextFormat::SERIAL_INCREMENT );
                mDecrementRadio->setChecked( f.serialMode == model::TextFormat::SERIAL_DECREMENT );
                mMethodCombo->setCurrentIndex( int(f.serialMethod) );
                mLettersCombo->setCurrentIndex( f.serialLowerCase ? 1 : 0 );
                mPreserveCheck->setChecked( f.serialPreserve );
                mStepSpin->setValue( qMax( 1, f.serialStep ) );
                mEventCombo->setCurrentIndex( int(f.serialEvent) );
                mIntervalSpin->setValue( qMax( 1, f.serialInterval ) );
                onControlsChanged();

                connect( mNoneRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mIncrementRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mDecrementRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mMethodCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( previewButton, SIGNAL(clicked()), this, SLOT(onPreview()) );
                connect( buttons, SIGNAL(accepted()), this, SLOT(accept()) );
                connect( buttons, SIGNAL(rejected()), this, SLOT(reject()) );
        }


        void SerializationDialog::onControlsChanged()
        {
                bool on = !mNoneRadio->isChecked();
                bool numeric = ( mMethodCombo->currentIndex() == int(model::TextFormat::SERIAL_NUMERIC) );
                mMethodCombo->setEnabled( on );
                mLettersCombo->setEnabled( on && !numeric );
                mPreserveCheck->setEnabled( on );
                mStepSpin->setEnabled( on );
                mEventCombo->setEnabled( on );
                mIntervalSpin->setEnabled( on );
        }


        model::TextFormat SerializationDialog::currentFormat() const
        {
                model::TextFormat f;
                fillFormat( f );
                return f;
        }


        void SerializationDialog::fillFormat( model::TextFormat& f ) const
        {
                f.serialMode = mDecrementRadio->isChecked() ? model::TextFormat::SERIAL_DECREMENT
                             : mIncrementRadio->isChecked() ? model::TextFormat::SERIAL_INCREMENT
                                                            : model::TextFormat::SERIAL_NONE;
                f.serialMethod    = model::TextFormat::SerialMethod( mMethodCombo->currentIndex() );
                f.serialLowerCase = ( mLettersCombo->currentIndex() == 1 );
                f.serialPreserve  = mPreserveCheck->isChecked();
                f.serialStep      = mStepSpin->value();
                f.serialEvent     = model::TextFormat::SerialEvent( mEventCombo->currentIndex() );
                f.serialInterval  = mIntervalSpin->value();
        }


        void SerializationDialog::onPreview()
        {
                bool ok = false;
                QString sample = QInputDialog::getText( this, tr("Sequence preview"), tr("First value:"),
                                                        QLineEdit::Normal, "A001", &ok );
                if ( !ok ) return;

                model::TextFormat f = currentFormat();
                QStringList values;
                for ( int i = 0; i < 12; i++ )
                {
                        // one value per event interval
                        values << f.applySerial( sample, qint64(i) * f.serialInterval );
                }
                QMessageBox::information( this, tr("Sequence preview"), values.join( "\n" ) );
        }

}
