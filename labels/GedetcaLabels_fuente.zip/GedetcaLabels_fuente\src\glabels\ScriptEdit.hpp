//  ScriptEdit.hpp
//
//  Text editor for the command script with a suggestion list (auto-complete):
//  keywords, Value, Fields (with the merge fields and variables), and the
//  methods of text, numbers, dates and Math after a dot.  Ctrl+Space forces it.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef ScriptEdit_hpp
#define ScriptEdit_hpp


#include <QCompleter>
#include <QPlainTextEdit>
#include <QStandardItemModel>
#include <QStringList>


namespace glabels
{

        class ScriptEdit : public QPlainTextEdit
        {
                Q_OBJECT

        public:
                explicit ScriptEdit( QWidget* parent = nullptr );

                // Names of merge fields and variables offered after "Fields."
                void setFieldNames( const QStringList& names );

        protected:
                void keyPressEvent( QKeyEvent* event ) override;
                void focusInEvent( QFocusEvent* event ) override;

        private slots:
                void insertCompletion( const QString& completion );

        private:
                struct Suggestion
                {
                        QString insertText;    // what is typed into the script
                        QString displayText;   // what the list shows
                };

                QString wordBeforeCursor() const;
                QString objectBeforeDot() const;
                QList<Suggestion> suggestionsFor( const QString& object ) const;
                void showSuggestions( bool forced, bool afterDot );

                QCompleter*          mCompleter;
                QStandardItemModel*  mModel;
                QStringList          mFieldNames;
        };

}


#endif // ScriptEdit_hpp
