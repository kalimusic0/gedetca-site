//  ObjectListWidget.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "ObjectListWidget.hpp"

#include "model/ModelObject.hpp"

#include <QCoreApplication>


namespace glabels
{

        ObjectListWidget::ObjectListWidget( QWidget* parent )
                : QListWidget( parent )
        {
                setSelectionMode( QAbstractItemView::ExtendedSelection );
                setToolTip( QCoreApplication::translate( "glabels::ObjectListWidget", "Objects of the label. Select one to select it in the work area." ) );

                connect( this, &QListWidget::itemSelectionChanged, this, [this]() { applySelectionToModel(); } );
        }


        void ObjectListWidget::setModel( model::Model* model )
        {
                mModel = model;

                connect( mModel, &model::Model::changed, this, [this]() { refresh(); } );
                connect( mModel, &model::Model::selectionChanged, this, [this]() { syncSelectionFromModel(); } );

                refresh();
        }


        // Rebuild only when the objects or their names changed
        void ObjectListWidget::refresh()
        {
                if ( !mModel ) return;

                const QList<model::ModelObject*>& objects = mModel->objectList();

                bool same = ( objects.size() == mShown.size() ) && ( objects.size() == count() );
                for ( int i = 0; same && i < objects.size(); i++ )
                {
                        same = ( objects[i] == mShown[i] ) && ( item( i )->text() == objects[i]->name() );
                }

                if ( !same )
                {
                        mBlocked = true;
                        clear();
                        mShown.clear();
                        for ( model::ModelObject* object : objects )
                        {
                                addItem( object->name() );
                                mShown << object;
                        }
                        mBlocked = false;
                }

                syncSelectionFromModel();
        }


        void ObjectListWidget::syncSelectionFromModel()
        {
                if ( !mModel || mBlocked ) return;

                mBlocked = true;
                clearSelection();
                for ( int i = 0; i < mShown.size() && i < count(); i++ )
                {
                        if ( mShown[i]->isSelected() )
                        {
                                item( i )->setSelected( true );
                                scrollToItem( item( i ) );
                        }
                }
                mBlocked = false;
        }


        void ObjectListWidget::applySelectionToModel()
        {
                if ( mBlocked || !mModel ) return;

                QList<model::ModelObject*> wanted;
                for ( QListWidgetItem* it : selectedItems() )
                {
                        int r = this->row( it );
                        if ( r >= 0 && r < mShown.size() ) wanted << mShown[r];
                }

                mBlocked = true;
                mModel->unselectAll();
                for ( model::ModelObject* object : wanted )
                {
                        mModel->selectObject( object );
                }
                mBlocked = false;
        }

}
