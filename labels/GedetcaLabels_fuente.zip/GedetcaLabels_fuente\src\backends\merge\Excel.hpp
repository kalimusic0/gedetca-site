//  Merge/Excel.hpp
//
//  Reads an Excel workbook (.xlsx): row 1 gives the field names, the next rows are the
//  records.  The first sheet is used, or the one named after a '#' in the source
//  (e.g.  datos.xlsx#Hoja2).
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef merge_Excel_hpp
#define merge_Excel_hpp


#include "Merge.hpp"

#include <QVector>


namespace glabels::merge
{

        struct Excel : public Merge
        {

                /////////////////////////////////
                // Life Cycle
                /////////////////////////////////
        private:
                Excel();
                Excel( const Excel* merge );
                virtual ~Excel() = default;


                /////////////////////////////////
                // Object duplication
                /////////////////////////////////
        public:
                Excel* clone() const override;


                /////////////////////////////////
                // Static methods
                /////////////////////////////////
        public:
                static QString id();
                static Merge* create();


                /////////////////////////////////
                // Implementation of virtual methods
                /////////////////////////////////
        public:
                QStringList keys() const override;
                QString primaryKey() const override;
        protected:
                void open() override;
                void close() override;
                Record readNextRecord() override;


                /////////////////////////////////
                // Private data
                /////////////////////////////////
        private:
                QStringList              mKeys;
                QVector<QStringList>     mRows;      // data rows (without the header)
                int                      mNextRow{ 0 };
        };

}


#endif // merge_Excel_hpp
