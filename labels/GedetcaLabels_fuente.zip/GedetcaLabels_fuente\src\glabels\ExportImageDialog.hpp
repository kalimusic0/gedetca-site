//  ExportImageDialog.hpp
//
//  Options of "Export image": file or folder, resolution, background.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef ExportImageDialog_hpp
#define ExportImageDialog_hpp


#include "model/ImageExporter.hpp"

#include <QCheckBox>
#include <QComboBox>
#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QSpinBox>


namespace glabels
{

        class ExportImageDialog : public QDialog
        {
                Q_OBJECT

        public:
                ExportImageDialog( const QString& suggestedFile, int imageCount, QWidget* parent = nullptr );

                QString target() const;
                model::ImageExporter::Options options() const;

        private slots:
                void onBrowse();

        private:
                QLineEdit* mTargetEdit;
                QSpinBox*  mDpiSpin;
                QComboBox* mBackgroundCombo;
                QCheckBox* mClipCheck;
                QLabel*    mSizeLabel;
        };

}


#endif // ExportImageDialog_hpp
