//  Gs1Wizard.hpp
//
//  Wizard to build GS1 data (Application Identifiers) for the barcode object:
//  GS1-128, GS1 QR Code, GS1 DataBar Expanded.  Steps (like BarTender's):
//    1. choose the Application Identifier (AI)
//    2. ready to configure the data component
//    3. choose the type of the data source (embedded, merge field, variable)
//    4. enter the value (check digit is added automatically)
//    5. add more data?  (yes: back to 1)
//  A "Sample" line shows the result at every step.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef Gs1Wizard_hpp
#define Gs1Wizard_hpp


#include "model/Gs1.hpp"

#include <QLineEdit>
#include <QList>
#include <QStringList>
#include <QWizard>


namespace glabels
{

        class Gs1Wizard : public QWizard
        {
        public:
                enum Source { EMBEDDED = 0, MERGE_FIELD = 1, VARIABLE = 2 };

                struct Component
                {
                        QString ai;
                        Source  source{ EMBEDDED };
                        QString value;      // final value (embedded) or field / variable name
                };

                enum PageId { PAGE_AI = 0, PAGE_READY, PAGE_SOURCE, PAGE_VALUE, PAGE_MORE };

                Gs1Wizard( const QString&     currentData,
                           const QStringList& fieldNames,
                           const QStringList& variableNames,
                           QWidget*           parent = nullptr );

                // Result: data in the form [01]09501101530003[10]ABC123
                QString dataString() const;

                // State shared by the pages
                QList<Component>   mComponents;
                Component          mCurrent;
                const model::Gs1::Ai* mCurrentAi{ nullptr };
                bool               mAddAnother{ true };
                bool               mFinishing{ false };
                QStringList        mFieldNames;
                QStringList        mVariableNames;

                // Text of the "Sample" line; includes the component being edited
                QString sampleText( bool includeCurrent ) const;

                // Is the component being edited complete and valid?
                bool currentIsValid( QString* error = nullptr, QString* finalValue = nullptr ) const;
                void commitCurrent();

                int nextId() const override;
                void done( int result ) override;

                bool mCurrentCommitted{ false };

        private:
                void prefill( const QString& data );
        };

}


#endif // Gs1Wizard_hpp
