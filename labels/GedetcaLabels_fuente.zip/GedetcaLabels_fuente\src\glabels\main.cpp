//  main.cpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "MainWindow.hpp"

#include "AppearanceModel.hpp"
#include "GedetcaTheme.hpp"

#include "model/Db.hpp"
#include "model/FileUtil.hpp"
#include "model/Model.hpp"
#include "model/Settings.hpp"
#include "model/Version.hpp"
#include "model/XmlLabelParser.hpp"

#include "barcode/Backends.hpp"
#include "merge/Factory.hpp"

#include <QApplication>
#ifdef _WIN32
#include <windows.h>
#endif

#include "model/SystemMode.hpp"
#include <QCommandLineParser>
#include <QDir>
#include <QFile>
#include <QDebug>
#include <QIcon>
#include <QLibraryInfo>
#include <QLocale>
#include <QTextStream>
#include <QTranslator>


#ifdef _WIN32
namespace
{
        bool setRegString( const QString& subkey, const wchar_t* name, const QString& value )
        {
                const std::wstring k = subkey.toStdWString();
                const std::wstring v = value.toStdWString();
                return RegSetKeyValueW( HKEY_CURRENT_USER, k.c_str(), name, REG_SZ, v.c_str(),
                                        DWORD( ( v.size() + 1 ) * sizeof(wchar_t) ) ) == ERROR_SUCCESS;
        }

        // Value of a key (default value when name is null) as seen by Windows (user + machine merged)
        QString getRegString( HKEY root, const QString& subkey, const wchar_t* name = nullptr )
        {
                wchar_t buf[2048];
                DWORD size = sizeof(buf);
                const std::wstring k = subkey.toStdWString();
                if ( RegGetValueW( root, k.c_str(), name, RRF_RT_REG_SZ, nullptr, buf, &size ) == ERROR_SUCCESS )
                {
                        return QString::fromWCharArray( buf );
                }
                return QString();
        }

        // Program of an "open" command line:  "C:\dir\app.exe" "%1"   or   C:\dir\app.exe %1
        QString exeOfCommand( const QString& command )
        {
                const QString c = command.trimmed();
                if ( c.startsWith( '"' ) )
                {
                        return c.section( '"', 1, 1 );
                }
                return c.section( ' ', 0, 0 );
        }

        bool commandWorks( const QString& command )
        {
                return !command.isEmpty() && QFile::exists( exeOfCommand( command ) );
        }

        ///
        /// Makes the .glabels files open with this program (double click) and puts it in the "Open with" list.
        /// Only for the current user (no administrator needed) and only when there is no working association yet
        /// (the installer usually does it; this covers a copy that did not go through the installer).
        ///
        void registerFileAssociation( const QString& extension, const QString& progId )
        {
                const QString exe     = QDir::toNativeSeparators( QCoreApplication::applicationFilePath() );
                const QString command = "\"" + exe + "\" \"%1\"";
                const QString classes = "Software\\Classes\\";
                const QString openKey = progId + "\\shell\\open";
                bool changed = false;

                const QString current = getRegString( HKEY_CLASSES_ROOT, openKey + "\\command" );
                if ( !commandWorks( current ) )
                {
                        setRegString( classes + progId, nullptr, "Etiqueta de Gedetca Labels" );
                        setRegString( classes + progId + "\\DefaultIcon", nullptr, exe + ",0" );
                        setRegString( classes + openKey, L"FriendlyAppName", "Gedetca Labels" );
                        setRegString( classes + openKey + "\\command", nullptr, command );
                        changed = true;
                }

                // appears in the "Open with" list
                setRegString( classes + extension + "\\OpenWithProgids", progId.toStdWString().c_str(), "" );

                // default program: only when none is set or the set one no longer exists
                const QString assoc = getRegString( HKEY_CLASSES_ROOT, extension );
                bool assocWorks = false;
                if ( !assoc.isEmpty() )
                {
                        assocWorks = commandWorks( getRegString( HKEY_CLASSES_ROOT, assoc + "\\shell\\open\\command" ) );
                }
                if ( !assocWorks )
                {
                        setRegString( classes + extension, nullptr, progId );
                        changed = true;
                }

                if ( changed )
                {
                        // SHChangeNotify( SHCNE_ASSOCCHANGED ): Explorer refreshes icons and associations right away
                        if ( HMODULE shell32 = LoadLibraryW( L"shell32.dll" ) )
                        {
                                using NotifyFn = void ( WINAPI* )( LONG, UINT, LPCVOID, LPCVOID );
                                if ( auto fn = reinterpret_cast<NotifyFn>( GetProcAddress( shell32, "SHChangeNotify" ) ) )
                                {
                                        fn( 0x08000000L, 0, nullptr, nullptr );
                                }
                        }
                }
        }
}
#endif


int main( int argc, char **argv )
{
        QApplication app( argc, argv );

        QCoreApplication::setOrganizationName( glabels::model::Version::ORGANIZATION_NAME );
        QCoreApplication::setOrganizationDomain( glabels::model::Version::ORGANIZATION_DOMAIN );
        QCoreApplication::setApplicationName( glabels::model::Version::APPLICATION_NAME );
        QCoreApplication::setApplicationVersion( glabels::model::Version::LONG_STRING );
        QApplication::setDesktopFileName( glabels::model::Version::DESKTOP_FILE_NAME );


        //
        // Setup translators
        //
        QLocale locale = QLocale::system();
        QString qtTranslationsDir = QLibraryInfo::path( QLibraryInfo::TranslationsPath );
        QString myTranslationsDir = glabels::model::FileUtil::translationsDir().canonicalPath();

        QTranslator qtTranslator;
        if ( qtTranslator.load( locale, "qt", "_", qtTranslationsDir ) )
        {
                app.installTranslator(&qtTranslator);
        }

        QTranslator glabelsTranslator;
        if ( glabelsTranslator.load( locale, "glabels", "_", myTranslationsDir ) )
        {
                app.installTranslator(&glabelsTranslator);
        }

        QTranslator templatesTranslator;
        if ( templatesTranslator.load( locale, "templates", "_", myTranslationsDir ) )
        {
                app.installTranslator(&templatesTranslator);
        }


        //
        // Parse command line
        //
        QCommandLineParser parser;
        parser.setApplicationDescription( QCoreApplication::translate( "main", "gLabels Label Designer" ) );
        parser.addHelpOption();
        parser.addVersionOption();
        parser.addOption( { { "V", "Version" }, QCoreApplication::translate( "main", "More detailed version information." ) } );
        // Used when gedetca_web opens the editor: same place and size as its window, same taskbar button
        parser.addOption( { "geometry", "Window position and size: x,y,w,h", "x,y,w,h" } );
        parser.addOption( { "maximized", "Open the window maximized." } );
        parser.addOption( { "theme", "Color theme of gedetca_web: hue,saturation,lightness,mode (dark|light)", "h,s,l,mode" } );
        parser.addOption( { "appid", "Windows AppUserModelID (groups the taskbar button with another program).", "id" } );
        // Used when gedetca_web opens the editor: labels of the system (made in its Modelador) can be edited only this way
        parser.addOption( { "system", "Opened by gedetca_web: labels of the system can be edited." } );
        parser.addPositionalArgument( "files",
                                      QCoreApplication::translate( "main", "gLabels project files to open, optionally." ),
                                      "[files...]" );
        parser.process( app );

        glabels::model::SystemMode::active() = parser.isSet( "system" ) || qEnvironmentVariable( "GEDETCA_SISTEMA" ) == "1";

#ifdef _WIN32
        // .glabels files open with this program (double click); GEDETCA_TEST_ASSOC=1 tries it on a dummy extension
        {
                const bool test = qEnvironmentVariable( "GEDETCA_TEST_ASSOC" ) == "1";
                registerFileAssociation( test ? ".gltest" : ".glabels",
                                         test ? "GedetcaLabelsTest.Etiqueta" : "GedetcaLabels.Etiqueta" );
        }
#endif

#ifdef Q_OS_WIN
        if ( parser.isSet( "appid" ) )
        {
                // SetCurrentProcessExplicitAppUserModelID, looked up at run time to avoid depending on shell headers
                if ( HMODULE shell32 = LoadLibraryW( L"shell32.dll" ) )
                {
                        using SetAppIdFn = HRESULT ( WINAPI* )( PCWSTR );
                        if ( auto fn = reinterpret_cast<SetAppIdFn>( GetProcAddress( shell32, "SetCurrentProcessExplicitAppUserModelID" ) ) )
                        {
                                fn( reinterpret_cast<PCWSTR>( parser.value( "appid" ).utf16() ) );
                        }
                }
        }
#endif

        // Optional window placement
        QRect startGeometry;
        {
                const QStringList g = parser.value( "geometry" ).split( ',' );
                if ( g.size() == 4 )
                {
                        startGeometry = QRect( g[0].toInt(), g[1].toInt(), g[2].toInt(), g[3].toInt() );
                }
        }
        auto showPlaced = [&]( glabels::MainWindow* w )
        {
                if ( parser.isSet( "maximized" ) )
                {
                        w->showMaximized();
                }
                else
                {
                        if ( startGeometry.isValid() )
                        {
                                w->setWindowState( Qt::WindowNoState );
                                w->setGeometry( startGeometry );
                        }
                        w->show();
                }
        };

        // Handle verbose version option
        if ( parser.isSet( "Version" ) )
        {
                QTextStream(stdout) << glabels::model::Version::details() << Qt::endl;
                return 0;
        }


        //
        // Initialize subsystems
        //
        glabels::model::Settings::init();
        glabels::model::Db::init();
        glabels::merge::Factory::init();
        glabels::barcode::Backends::init();
        glabels::AppearanceModel::init();

        // Same colors as the gedetca_web module that opened the editor
        {
                const QStringList th = parser.value( "theme" ).split( ',' );
                if ( th.size() == 4 )
                {
                        glabels::GedetcaTheme::setCustom( th[0].toDouble(), th[1].toDouble(), th[2].toDouble() );
                        auto scheme = ( th[3] == "light" ) ? glabels::model::Settings::LIGHT_COLOR_SCHEME
                                                           : glabels::model::Settings::DARK_COLOR_SCHEME;
                        glabels::AppearanceModel::applyColorScheme( scheme, glabels::model::Settings::iconStyle() );
                }
        }


        //
        // Set initial working directory
        //
        auto path = glabels::model::Settings::startupPath();
        if ( !path.isEmpty() )
        {
                QDir::setCurrent( path );
        }


        //
        // Open each file in its own main window
        //
        bool openedFiles = false;
        for ( QString filename : parser.positionalArguments() )
        {
                glabels::model::Model *model = glabels::model::XmlLabelParser::readFile( filename );
                if ( model )
                {
                        auto *newWindow = new glabels::MainWindow();
                        newWindow->setModel( model );
                        showPlaced( newWindow );
                        openedFiles = true;

                        // Las etiquetas del sistema (hechas en el Modelador de Gedetca Web) no quedan en la lista de recientes
                        if ( !model->isSystem() )
                        {
                                glabels::model::Settings::addToRecentFileList( model->fileName() );
                        }
                }
        }


        //
        // Launch main window
        //
        if ( !openedFiles )
        {
                auto *mainWindow = new glabels::MainWindow();
                mainWindow->show();
        }


        return app.exec();
}
