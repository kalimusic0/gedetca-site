//  TextScript.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "TextScript.hpp"

#include <QHash>
#include <QJSEngine>
#include <QJSValue>
#include <QRegularExpression>

#include <atomic>
#include <chrono>
#include <memory>
#include <thread>


namespace glabels::model
{

        namespace
        {
                struct Entry
                {
                        QJSEngine engine;
                        QJSValue  function;
                        QString   error;
                };

                // One compiled function per script and per thread
                QHash<QString, std::shared_ptr<Entry>>& cache()
                {
                        thread_local QHash<QString, std::shared_ptr<Entry>> c;
                        return c;
                }

                const int MAX_CACHE = 64;
                const int TIMEOUT_MS = 500;

                // Ready-made commands (Spanish) available to every script
                const char* PRELUDE = R"JS(
function _pad2(n) { return (n < 10 ? "0" : "") + n; }

// Date text -> { d, mo, y, sep, order } ; accepts dd/MM/yyyy, dd-MM-yyyy, dd.MM.yyyy and yyyy-MM-dd
function _parseFecha(t) {
    t = String(t).trim();
    var m = /^(\d{1,2})([\/\-.])(\d{1,2})\2(\d{4})$/.exec(t);
    if (m) return { d: +m[1], mo: +m[3], y: +m[4], sep: m[2], order: "dmy" };
    m = /^(\d{4})([\/\-.])(\d{1,2})\2(\d{1,2})$/.exec(t);
    if (m) return { d: +m[4], mo: +m[3], y: +m[1], sep: m[2], order: "ymd" };
    return null;
}
function _fmtFecha(dt, p) {
    var d = _pad2(dt.getDate()), mo = _pad2(dt.getMonth() + 1), y = dt.getFullYear();
    return p.order === "dmy" ? d + p.sep + mo + p.sep + y : y + p.sep + mo + p.sep + d;
}

function SumarDias(texto, n) {
    var p = _parseFecha(texto); if (!p) return texto;
    var dt = new Date(p.y, p.mo - 1, p.d); dt.setDate(dt.getDate() + Number(n));
    return _fmtFecha(dt, p);
}
function RestarDias(texto, n) { return SumarDias(texto, -Number(n)); }
function SumarMeses(texto, n) {
    var p = _parseFecha(texto); if (!p) return texto;
    var dt = new Date(p.y, p.mo - 1, p.d); dt.setMonth(dt.getMonth() + Number(n));
    return _fmtFecha(dt, p);
}
function RestarMeses(texto, n) { return SumarMeses(texto, -Number(n)); }
function SumarAnios(texto, n) { return SumarMeses(texto, 12 * Number(n)); }
function RestarAnios(texto, n) { return SumarMeses(texto, -12 * Number(n)); }

function Reemplazar(texto, buscar, nuevo) {
    texto = String(texto); buscar = String(buscar);
    return buscar === "" ? texto : texto.split(buscar).join(String(nuevo));
}
function Recortar(texto) { return String(texto).trim(); }
function Mayusculas(texto) { return String(texto).toUpperCase(); }
function Minusculas(texto) { return String(texto).toLowerCase(); }
function PrimeraMayuscula(texto) {
    return String(texto).toLowerCase().replace(/\S+/g, function (w) { return w.charAt(0).toUpperCase() + w.slice(1); });
}
function RellenarIzquierda(texto, largo, caracter) { return String(texto).padStart(Number(largo), caracter === undefined ? " " : String(caracter)); }
function RellenarDerecha(texto, largo, caracter) { return String(texto).padEnd(Number(largo), caracter === undefined ? " " : String(caracter)); }
function Primeros(texto, n) { return String(texto).slice(0, Number(n)); }
function Ultimos(texto, n) { n = Number(n); return n <= 0 ? "" : String(texto).slice(-n); }
function QuitarInicio(texto, n) { return String(texto).slice(Number(n)); }
function QuitarFinal(texto, n) { n = Number(n); texto = String(texto); return n <= 0 ? texto : texto.slice(0, Math.max(0, texto.length - n)); }
function Contiene(texto, buscar) { return String(texto).indexOf(String(buscar)) !== -1; }

// ---- Functions like the ones of Excel (names in Spanish) ----

function _nums(args) {
    var r = [];
    for (var i = 0; i < args.length; i++) {
        var a = args[i];
        if (Array.isArray(a)) { r = r.concat(_nums(a)); }
        else { var n = Number(String(a).replace(",", ".")); if (!isNaN(n) && String(a).trim() !== "") r.push(n); }
    }
    return r;
}
function _num(x) { var n = Number(String(x).replace(",", ".")); return isNaN(n) ? 0 : n; }

// Logical
function SI(condicion, siVerdadero, siFalso) { return condicion ? siVerdadero : (siFalso === undefined ? false : siFalso); }
function Y() { for (var i = 0; i < arguments.length; i++) if (!arguments[i]) return false; return true; }
function O() { for (var i = 0; i < arguments.length; i++) if (arguments[i]) return true; return false; }
function NO(x) { return !x; }
function SIERROR(valor, alternativo) { return (valor === undefined || valor === null || (typeof valor === "number" && isNaN(valor)) || valor === "") ? alternativo : valor; }
function ESNUMERO(x) { return String(x).trim() !== "" && !isNaN(Number(String(x).replace(",", "."))); }
function ESTEXTO(x) { return !ESNUMERO(x) && String(x).trim() !== ""; }
function ESBLANCO(x) { return x === undefined || x === null || String(x).trim() === ""; }
function IGUAL(a, b) { return String(a) === String(b); }

// Math
function SUMA() { var n = _nums(arguments), s = 0; for (var i = 0; i < n.length; i++) s += n[i]; return s; }
function PRODUCTO() { var n = _nums(arguments), s = 1; for (var i = 0; i < n.length; i++) s *= n[i]; return s; }
function PROMEDIO() { var n = _nums(arguments); return n.length ? SUMA(n) / n.length : 0; }
function MAX() { var n = _nums(arguments); return n.length ? Math.max.apply(null, n) : 0; }
function MIN() { var n = _nums(arguments); return n.length ? Math.min.apply(null, n) : 0; }
function CONTAR() { return _nums(arguments).length; }
function ABS(x) { return Math.abs(_num(x)); }
function ENTERO(x) { return Math.floor(_num(x)); }
function TRUNCAR(x, dec) { var f = Math.pow(10, dec === undefined ? 0 : Number(dec)); return Math.trunc(_num(x) * f) / f; }
function REDONDEAR(x, dec) { var f = Math.pow(10, dec === undefined ? 0 : Number(dec)); return Math.round(_num(x) * f) / f; }
function RESIDUO(x, d) { x = _num(x); d = _num(d); return d === 0 ? 0 : x - d * Math.floor(x / d); }
function POTENCIA(x, y) { return Math.pow(_num(x), _num(y)); }
function RAIZ(x) { return Math.sqrt(_num(x)); }
function SIGNO(x) { x = _num(x); return x > 0 ? 1 : (x < 0 ? -1 : 0); }

// Text
function CONCATENAR() { var s = ""; for (var i = 0; i < arguments.length; i++) s += String(arguments[i]); return s; }
function IZQUIERDA(t, n) { return String(t).slice(0, n === undefined ? 1 : Number(n)); }
function DERECHA(t, n) { n = n === undefined ? 1 : Number(n); return n <= 0 ? "" : String(t).slice(-n); }
function EXTRAE(t, inicio, n) { inicio = Number(inicio); return String(t).substr(Math.max(0, inicio - 1), Number(n)); }
function LARGO(t) { return String(t).length; }
function MAYUSC(t) { return String(t).toUpperCase(); }
function MINUSC(t) { return String(t).toLowerCase(); }
function NOMPROPIO(t) { return PrimeraMayuscula(t); }
function ESPACIOS(t) { return String(t).trim().replace(/\s+/g, " "); }
function SUSTITUIR(t, antiguo, nuevo) { return Reemplazar(t, antiguo, nuevo); }
function ENCONTRAR(buscar, en, desde) { var i = String(en).indexOf(String(buscar), desde === undefined ? 0 : Number(desde) - 1); return i < 0 ? 0 : i + 1; }
function REPETIR(t, n) { var s = ""; n = Number(n); for (var i = 0; i < n; i++) s += String(t); return s; }
function VALOR(t) { return _num(t); }
function TEXTO(n, decimales) { return decimales === undefined ? String(n) : _num(n).toFixed(Number(decimales)); }

// Date
function HOY() { var d = new Date(); return _pad2(d.getDate()) + "/" + _pad2(d.getMonth() + 1) + "/" + d.getFullYear(); }
function AHORA() { var d = new Date(); return HOY() + " " + _pad2(d.getHours()) + ":" + _pad2(d.getMinutes()) + ":" + _pad2(d.getSeconds()); }
function DIA(f) { var p = _parseFecha(f); return p ? p.d : 0; }
function MES(f) { var p = _parseFecha(f); return p ? p.mo : 0; }
function ANIO(f) { var p = _parseFecha(f); return p ? p.y : 0; }
function FECHA(anio, mes, dia) { return _pad2(Number(dia)) + "/" + _pad2(Number(mes)) + "/" + Number(anio); }
)JS";

                // Spanish keywords -> JavaScript (outside strings, comments and regular expressions)
        QString translateSpanish( const QString& s )
        {
                static const QHash<QString,QString> keywords = {
                        { "si", "if" },             { "sino", "else" },
                        { "para", "for" },          { "mientras", "while" },
                        { "hacer", "do" },          { "romper", "break" },
                        { "continuar", "continue" }, { "devolver", "return" },
                        { "variable", "var" },      { "funcion", "function" },
                        { QString::fromUtf8( "función" ), "function" },
                        { "verdadero", "true" },    { "falso", "false" },
                        { "nulo", "null" },         { "intentar", "try" },
                        { "capturar", "catch" },
                        { "Valor", "Value" },       { "Campos", "Fields" }
                };
                static const QStringList declarations = { "var", "variable", "let", "function", "funcion", QString::fromUtf8( "función" ) };

                auto isWordChar = []( QChar c ) { return c.isLetterOrNumber() || c == '_' || c == '$'; };
                auto startsOperand = []( QChar c ) { return c.isLetterOrNumber() || c == '_' || c == '$' || c == '(' || c == '!' || c == '"' || c == '\'' || c == '-' || c == '['; };

                QString out;
                const int n = s.size();
                int i = 0;
                QChar prevSig;        // last meaningful character
                QString prevWord;     // last word, if the last meaningful thing was a word

                while ( i < n )
                {
                        QChar c = s[i];

                        if ( c == '/' && i + 1 < n && s[i+1] == '/' )                 // line comment
                        {
                                int j = s.indexOf( '\n', i );
                                if ( j < 0 ) j = n;
                                out += s.mid( i, j - i );
                                i = j;
                        }
                        else if ( c == '/' && i + 1 < n && s[i+1] == '*' )            // block comment
                        {
                                int j = s.indexOf( "*/", i + 2 );
                                j = ( j < 0 ) ? n : j + 2;
                                out += s.mid( i, j - i );
                                i = j;
                        }
                        else if ( c == '"' || c == '\'' || c == '`' )                // string
                        {
                                int j = i + 1;
                                while ( j < n && s[j] != c )
                                {
                                        if ( s[j] == '\\' ) j++;
                                        j++;
                                }
                                j = qMin( n, j + 1 );
                                out += s.mid( i, j - i );
                                i = j;
                                prevSig = c;
                                prevWord.clear();
                        }
                        else if ( c == '/' && ( prevSig.isNull() || QString( "(,=:[!&|?{};+-*%<>~^" ).contains( prevSig ) ||
                                                prevWord == "return" || prevWord == "devolver" ) )   // regular expression
                        {
                                int j = i + 1;
                                bool inClass = false;
                                while ( j < n && ( s[j] != '/' || inClass ) && s[j] != '\n' )
                                {
                                        if ( s[j] == '\\' ) j++;
                                        else if ( s[j] == '[' ) inClass = true;
                                        else if ( s[j] == ']' ) inClass = false;
                                        j++;
                                }
                                j = qMin( n, j + 1 );
                                while ( j < n && s[j].isLetter() ) j++;               // flags
                                out += s.mid( i, j - i );
                                i = j;
                                prevSig = ')';
                                prevWord.clear();
                        }
                        else if ( isWordChar( c ) && !c.isDigit() )                   // word
                        {
                                int j = i;
                                while ( j < n && isWordChar( s[j] ) ) j++;
                                QString w = s.mid( i, j - i );
                                bool afterDot = ( prevSig == '.' );

                                // next meaningful character
                                int k = j;
                                while ( k < n && s[k].isSpace() ) k++;
                                QChar next = ( k < n ) ? s[k] : QChar();

                                QString repl = w;
                                if ( !afterDot )
                                {
                                        if ( keywords.contains( w ) )
                                        {
                                                repl = keywords.value( w );
                                        }
                                        else if ( ( w == "y" || w == "o" ) && !declarations.contains( prevWord ) &&
                                                  ( isWordChar( prevSig ) || prevSig == ')' || prevSig == ']' || prevSig == '"' || prevSig == '\'' ) &&
                                                  startsOperand( next ) )
                                        {
                                                repl = ( w == "y" ) ? "&&" : "||";
                                        }
                                        else if ( w == "no" && !declarations.contains( prevWord ) &&
                                                  ( prevSig.isNull() || QString( "(!&|?:,={;" ).contains( prevSig ) ||
                                                    prevWord == "y" || prevWord == "o" || prevWord == "si" || prevWord == "mientras" ||
                                                    prevWord == "devolver" || prevWord == "return" ) &&
                                                  startsOperand( next ) )
                                        {
                                                repl = "!";
                                        }
                                }
                                out += repl;
                                if ( repl == "&&" || repl == "||" || repl == "!" )
                                {
                                        prevSig = repl.back();
                                        prevWord = w;
                                }
                                else
                                {
                                        prevSig = w.back();
                                        prevWord = w;
                                }
                                i = j;
                        }
                        else
                        {
                                out += c;
                                if ( !c.isSpace() )
                                {
                                        prevSig = c;
                                        prevWord.clear();
                                }
                                i++;
                        }
                }
                return out;
        }

        TextScript::ObjectResolver& resolverStorage()
        {
                thread_local TextScript::ObjectResolver r;
                return r;
        }

        std::shared_ptr<Entry> compile( const QString& script )
                {
                        auto& c = cache();
                        auto it = c.find( script );
                        if ( it != c.end() )
                        {
                                return it.value();
                        }

                        if ( c.size() >= MAX_CACHE )
                        {
                                c.clear();
                        }

                        auto entry = std::make_shared<Entry>();
                        // The ready-made commands are global; Campo() needs the Fields of each call
                        entry->engine.evaluate( QString::fromUtf8( PRELUDE ), "comandos" );
                        const QString source = "(function(Value, Fields, Objetos) {\n"
                                               "function Campo(nombre) { var v = Fields[nombre]; return v === undefined ? \"\" : v; }\n"
                                               "function Variable(nombre) { var v = Fields[nombre]; return v === undefined ? \"\" : v; }\n"
                                               "function Objeto(nombre) { var v = Objetos[nombre]; return v === undefined ? \"\" : v; }\n"
                                               "function Etiqueta() { var v = Fields.__etiqueta; return v === undefined ? 1 : Number(v); }\n"
                                               "function Total() { var v = Fields.__total; return v === undefined ? 1 : Number(v); }\n"
                                               + translateSpanish( script ) + "\n;return Value;\n})";
                        entry->function = entry->engine.evaluate( source, "script" );
                        if ( entry->function.isError() )
                        {
                                entry->error = entry->function.toString();
                        }
                        c.insert( script, entry );
                        return entry;
                }
        }


        TextScript::ObjectResolver TextScript::objectResolver()
        {
                return resolverStorage();
        }


        void TextScript::setObjectResolver( ObjectResolver resolver )
        {
                resolverStorage() = resolver;
        }


        bool TextScript::run( const QString&               script,
                              const QString&               value,
                              const QMap<QString,QString>& fields,
                              QString&                     out,
                              QString*                     error )
        {
                out = value;

                if ( script.trimmed().isEmpty() )
                {
                        return true;
                }

                auto entry = compile( script );
                if ( !entry->error.isEmpty() )
                {
                        if ( error ) *error = entry->error;
                        return false;
                }

                QJSValue fieldsObject = entry->engine.newObject();
                for ( auto it = fields.constBegin(); it != fields.constEnd(); ++it )
                {
                        fieldsObject.setProperty( it.key(), it.value() );
                }

                // Objeto("name"): the values are looked up beforehand, by the names written in the script
                QJSValue objectsObject = entry->engine.newObject();
                if ( auto resolver = resolverStorage() )
                {
                        static const QRegularExpression re( "Objeto\\s*\\(\\s*[\"']([^\"']+)[\"']\\s*\\)" );
                        auto it = re.globalMatch( script );
                        while ( it.hasNext() )
                        {
                                QString objectName = it.next().captured( 1 );
                                objectsObject.setProperty( objectName, resolver( objectName ) );
                        }
                }

                // Watchdog: stop scripts that run too long (e.g. endless loops)
                std::atomic<bool> finished{ false };
                QJSEngine* engine = &entry->engine;
                std::thread watchdog( [&finished, engine]()
                {
                        auto start = std::chrono::steady_clock::now();
                        while ( !finished )
                        {
                                std::this_thread::sleep_for( std::chrono::milliseconds( 10 ) );
                                if ( std::chrono::steady_clock::now() - start > std::chrono::milliseconds( TIMEOUT_MS ) )
                                {
                                        engine->setInterrupted( true );
                                        break;
                                }
                        }
                } );

                QJSValue result = entry->function.call( QJSValueList() << value << fieldsObject << objectsObject );

                finished = true;
                watchdog.join();
                bool wasInterrupted = engine->isInterrupted();
                engine->setInterrupted( false );

                if ( wasInterrupted )
                {
                        // Do not run this script again: it takes too long
                        entry->error = QString( "Script stopped: it ran for more than %1 ms" ).arg( TIMEOUT_MS );
                }

                if ( result.isError() )
                {
                        if ( error ) *error = wasInterrupted ? entry->error : result.toString();
                        return false;
                }

                out = result.toString();
                return true;
        }

}
