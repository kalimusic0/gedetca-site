//  FieldListWidget.cpp

#include "FieldListWidget.hpp"

#include "merge/Merge.hpp"

#include <QMimeData>


namespace glabels
{

        const char* FieldListWidget::MIME_TYPE = "application/x-gedetca-field";


        FieldListWidget::FieldListWidget( QWidget* parent )
                : QListWidget(parent), mModel(nullptr)
        {
                setDragEnabled( true );
                setDragDropMode( QAbstractItemView::DragOnly );
                setDefaultDropAction( Qt::CopyAction );
                setSelectionMode( QAbstractItemView::SingleSelection );
                setToolTip( tr("Arrastre un campo al área de trabajo para crear un texto o un código de barras") );
        }


        void FieldListWidget::setModel( model::Model* model )
        {
                mModel = model;

                connect( mModel, SIGNAL(mergeSourceChanged()), this, SLOT(onFieldsChanged()) );
                connect( mModel, SIGNAL(variablesChanged()), this, SLOT(onFieldsChanged()) );

                onFieldsChanged();
        }


        void FieldListWidget::onFieldsChanged()
        {
                clear();
                if ( !mModel )
                {
                        return;
                }

                for ( auto& key : mModel->merge()->keys() )
                {
                        auto* item = new QListWidgetItem( key, this );
                        item->setData( Qt::UserRole, key );
                }

                for ( auto& key : mModel->variables().keys() )
                {
                        auto* item = new QListWidgetItem( key, this );
                        item->setData( Qt::UserRole, key );
                }
        }


        QMimeData* FieldListWidget::mimeData( const QList<QListWidgetItem*>& items ) const
        {
                auto* data = new QMimeData();

                if ( !items.isEmpty() )
                {
                        QString key = items.first()->data( Qt::UserRole ).toString();
                        data->setData( MIME_TYPE, key.toUtf8() );
                        data->setText( "${" + key + "}" );
                }

                return data;
        }

}
