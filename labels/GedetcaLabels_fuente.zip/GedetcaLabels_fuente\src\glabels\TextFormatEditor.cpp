//  TextFormatEditor.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "TextFormatEditor.hpp"

#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLocale>
#include <QVBoxLayout>


namespace glabels
{

        namespace
        {
                struct LocaleEntry { const char* name; const char* label; };

                const LocaleEntry kLocales[] = {
                        { "",      "System default" },
                        { "es_MX", "Español (México)" },
                        { "es_ES", "Español (España)" },
                        { "es_EC", "Español (Ecuador)" },
                        { "es_CO", "Español (Colombia)" },
                        { "es_AR", "Español (Argentina)" },
                        { "en_US", "English (United States)" },
                        { "en_GB", "English (United Kingdom)" },
                        { "pt_BR", "Português (Brasil)" },
                        { "fr_FR", "Français (France)" },
                        { "de_DE", "Deutsch (Deutschland)" },
                        { "it_IT", "Italiano (Italia)" },
                };

                QLocale makeLocale( const QString& name )
                {
                        return name.isEmpty() ? QLocale::system() : QLocale( name );
                }
        }


        TextFormatEditor::TextFormatEditor( QWidget* parent )
                : QWidget( parent )
        {
                auto* form = new QFormLayout();
                form->setFieldGrowthPolicy( QFormLayout::AllNonFixedFieldsGrow );

                // Type
                mTypeCombo = new QComboBox();
                mTypeCombo->addItem( tr("Text") );
                mTypeCombo->addItem( tr("Date") );
                mTypeCombo->addItem( tr("Time") );
                mTypeCombo->addItem( tr("Number") );
                form->addRow( tr("Type:"), mTypeCombo );

                // Data view (case)
                mCaseCombo = new QComboBox();
                mCaseCombo->addItem( tr("As is") );
                mCaseCombo->addItem( tr("Lower case") );
                mCaseCombo->addItem( tr("Upper case") );
                mCaseCombo->addItem( tr("Capitalize each word") );
                form->addRow( tr("Data view:"), mCaseCombo );

                // Locale
                mLocaleCombo = new QComboBox();
                for ( const auto& e : kLocales )
                {
                        QString label = e.name[0] ? QString::fromUtf8( e.label ) : tr("System default");
                        mLocaleCombo->addItem( label, QString( e.name ) );
                }
                auto* localeLabel = new QLabel( tr("Locale:") );
                form->addRow( localeLabel, mLocaleCombo );
                mLocaleRow = { localeLabel, mLocaleCombo };

                // Date/Time: format list + pattern
                mFormatList = new QListWidget();
                mFormatList->setMinimumHeight( 150 );
                auto* listLabel = new QLabel( tr("Format:") );
                listLabel->setAlignment( Qt::AlignTop | Qt::AlignLeft );
                form->addRow( listLabel, mFormatList );

                mPatternEdit = new QLineEdit();
                auto* patternLabel = new QLabel( tr("Pattern:") );
                form->addRow( patternLabel, mPatternEdit );
                mDateTimeRow = { listLabel, mFormatList, patternLabel, mPatternEdit };

                // Number options
                mGroupingCheck = new QCheckBox( tr("Use thousands separator") );
                mLeadingZeroCheck = new QCheckBox( tr("Show leading zero") );
                form->addRow( mGroupingCheck );
                form->addRow( mLeadingZeroCheck );

                mPrecisionModeCombo = new QComboBox();
                mPrecisionModeCombo->addItem( tr("Fixed at") );
                mPrecisionModeCombo->addItem( tr("Maximum of") );
                mDecimalsSpin = new QSpinBox();
                mDecimalsSpin->setRange( 0, 15 );
                mDecimalsSpin->setValue( 2 );
                auto* decimalsLabel = new QLabel( tr("decimal places") );
                auto* precisionBox = new QHBoxLayout();
                precisionBox->addWidget( mPrecisionModeCombo );
                precisionBox->addWidget( mDecimalsSpin );
                precisionBox->addWidget( decimalsLabel );
                precisionBox->addStretch( 1 );
                auto* precisionLabel = new QLabel( tr("Precision:") );
                form->addRow( precisionLabel, precisionBox );

                mNegativeCombo = new QComboBox();
                mNegativeCombo->addItems( model::TextFormat::negativeStyleExamples() );
                auto* negativeLabel = new QLabel( tr("Negative numbers:") );
                form->addRow( negativeLabel, mNegativeCombo );

                mNumberRow = { mGroupingCheck, mLeadingZeroCheck, precisionLabel, mPrecisionModeCombo,
                               mDecimalsSpin, decimalsLabel, negativeLabel, mNegativeCombo };

                // Example
                auto* exampleBox = new QGroupBox( tr("Example") );
                auto* exampleLayout = new QVBoxLayout( exampleBox );
                mExampleLabel = new QLabel();
                mExampleLabel->setTextInteractionFlags( Qt::TextSelectableByMouse );
                mExampleLabel->setMinimumHeight( 24 );
                exampleLayout->addWidget( mExampleLabel );

                auto* main = new QVBoxLayout( this );
                main->setContentsMargins( 6, 6, 6, 6 );
                main->addLayout( form );
                main->addWidget( exampleBox );
                main->addStretch( 1 );

                connect( mTypeCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onTypeChanged()) );
                connect( mLocaleCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mCaseCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mFormatList, SIGNAL(currentRowChanged(int)), this, SLOT(onListSelectionChanged()) );
                connect( mPatternEdit, SIGNAL(textEdited(QString)), this, SLOT(onControlsChanged()) );
                connect( mGroupingCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mLeadingZeroCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mPrecisionModeCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mDecimalsSpin, SIGNAL(valueChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mNegativeCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );

                rebuildList();
                updateVisibility();
                updateExample();
        }


        QString TextFormatEditor::currentLocaleName() const
        {
                return mLocaleCombo->currentData().toString();
        }


        model::TextFormat TextFormatEditor::format() const
        {
                model::TextFormat f;
                f.type          = model::TextFormat::Type( mTypeCombo->currentIndex() );
                f.locale        = currentLocaleName();
                f.pattern       = mPatternEdit->text();
                f.grouping      = mGroupingCheck->isChecked();
                f.leadingZero   = mLeadingZeroCheck->isChecked();
                f.fixedDecimals = mPrecisionModeCombo->currentIndex() == 0;
                f.decimals      = mDecimalsSpin->value();
                f.negativeStyle = mNegativeCombo->currentIndex();
                f.caseMode      = model::TextFormat::CaseMode( mCaseCombo->currentIndex() );
                return f;
        }


        void TextFormatEditor::setFormat( const model::TextFormat& f )
        {
                mBlocked = true;

                mTypeCombo->setCurrentIndex( int(f.type) );

                int li = mLocaleCombo->findData( f.locale );
                mLocaleCombo->setCurrentIndex( li >= 0 ? li : 0 );

                mGroupingCheck->setChecked( f.grouping );
                mLeadingZeroCheck->setChecked( f.leadingZero );
                mPrecisionModeCombo->setCurrentIndex( f.fixedDecimals ? 0 : 1 );
                mDecimalsSpin->setValue( f.decimals );
                mNegativeCombo->setCurrentIndex( f.negativeStyle );
                mCaseCombo->setCurrentIndex( int(f.caseMode) );

                rebuildList();

                // Select the matching preset or «Custom»
                QString pat = f.pattern;
                if ( pat.isEmpty() )
                {
                        pat = (f.type == model::TextFormat::TIME)
                                ? model::TextFormat::timePatterns().first()
                                : model::TextFormat::datePatterns().first();
                }
                int row = mFormatList->count() - 1; // «Custom»
                for ( int i = 0; i < mFormatList->count() - 1; i++ )
                {
                        if ( mFormatList->item(i)->data( Qt::UserRole ).toString() == pat )
                        {
                                row = i;
                                break;
                        }
                }
                mFormatList->setCurrentRow( row );
                mPatternEdit->setText( pat );
                mPatternEdit->setReadOnly( row != mFormatList->count() - 1 );

                updateVisibility();
                updateExample();

                mBlocked = false;
        }


        void TextFormatEditor::setSampleText( const QString& text )
        {
                mSampleText = text;
                updateExample();
        }


        void TextFormatEditor::rebuildList()
        {
                bool wasBlocked = mBlocked;
                mBlocked = true;

                mFormatList->clear();

                auto type = model::TextFormat::Type( mTypeCombo->currentIndex() );
                if ( type == model::TextFormat::DATE || type == model::TextFormat::TIME )
                {
                        QLocale loc = makeLocale( currentLocaleName() );
                        QDateTime ref = model::TextFormat::referenceDateTime();
                        const QStringList patterns = (type == model::TextFormat::DATE)
                                ? model::TextFormat::datePatterns()
                                : model::TextFormat::timePatterns();
                        for ( const QString& p : patterns )
                        {
                                auto* item = new QListWidgetItem( loc.toString( ref, p ) );
                                item->setData( Qt::UserRole, p );
                                mFormatList->addItem( item );
                        }
                        auto* custom = new QListWidgetItem( QString::fromUtf8( "«" ) + tr("Custom") + QString::fromUtf8( "»" ) );
                        custom->setData( Qt::UserRole, QString() );
                        mFormatList->addItem( custom );
                }

                mBlocked = wasBlocked;
        }


        void TextFormatEditor::updateVisibility()
        {
                auto type = model::TextFormat::Type( mTypeCombo->currentIndex() );
                bool dt = (type == model::TextFormat::DATE || type == model::TextFormat::TIME);
                bool num = (type == model::TextFormat::NUMBER);

                for ( QWidget* w : mLocaleRow )   w->setVisible( dt || num );
                for ( QWidget* w : mDateTimeRow ) w->setVisible( dt );
                for ( QWidget* w : mNumberRow )   w->setVisible( num );
        }


        void TextFormatEditor::updateExample()
        {
                model::TextFormat f = format();
                if ( f.isDefault() )
                {
                        mExampleLabel->setText( mSampleText );
                        return;
                }

                QString out;
                if ( !f.tryApply( mSampleText, out ) )
                {
                        // Text is empty or contains fields: show a generic sample
                        f.tryApply( f.sampleValue(), out );
                }
                mExampleLabel->setText( out );
        }


        void TextFormatEditor::onTypeChanged()
        {
                if ( mBlocked ) return;

                mBlocked = true;
                rebuildList();
                if ( mFormatList->count() > 0 )
                {
                        mFormatList->setCurrentRow( 0 );
                        mPatternEdit->setText( mFormatList->item(0)->data( Qt::UserRole ).toString() );
                        mPatternEdit->setReadOnly( true );
                }
                else
                {
                        mPatternEdit->clear();
                }
                updateVisibility();
                updateExample();
                mBlocked = false;

                emit changed();
        }


        void TextFormatEditor::onListSelectionChanged()
        {
                if ( mBlocked ) return;

                int row = mFormatList->currentRow();
                if ( row < 0 ) return;

                bool custom = (row == mFormatList->count() - 1);
                mBlocked = true;
                if ( !custom )
                {
                        mPatternEdit->setText( mFormatList->item(row)->data( Qt::UserRole ).toString() );
                }
                mPatternEdit->setReadOnly( !custom );
                if ( custom )
                {
                        mPatternEdit->setFocus();
                }
                updateExample();
                mBlocked = false;

                emit changed();
        }


        void TextFormatEditor::onControlsChanged()
        {
                if ( mBlocked ) return;

                // Locale changes the preset captions
                mBlocked = true;
                int row = mFormatList->currentRow();
                rebuildList();
                if ( row >= 0 && row < mFormatList->count() )
                {
                        mFormatList->setCurrentRow( row );
                }
                updateExample();
                mBlocked = false;

                emit changed();
        }

}
