//  PrintFormDialog.hpp
//
//  Quick data entry form for printing: lists the variables used by the objects of
//  the label, each with an editor that matches its format (text, number, date...),
//  and writes the typed values back to the variables.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef PrintFormDialog_hpp
#define PrintFormDialog_hpp


#include "model/Model.hpp"

#include <QDialog>
#include <QList>
#include <QString>


namespace glabels
{

        class PrintFormDialog : public QDialog
        {
        public:
                PrintFormDialog( model::Model* model, QWidget* parent = nullptr );

                // Names of the variables used by the objects of the label (in order of appearance)
                static QStringList usedVariables( model::Model* model );

                bool hasVariables() const { return !mRows.isEmpty(); }

                // Writes the typed values to the variables of the model
                void applyValues();

        private:
                enum Kind { TEXT, INTEGER, DECIMAL, COLOR, DATE, TIME, DATETIME, NUMBER };

                struct Row
                {
                        QString  name;
                        Kind     kind{ TEXT };
                        QString  datePattern;   // pattern used to write dates back
                        QString  original;
                        QWidget* editor{ nullptr };
                };

                QString valueOf( const Row& row ) const;

                model::Model* mModel;
                QList<Row>    mRows;
        };

}


#endif // PrintFormDialog_hpp
