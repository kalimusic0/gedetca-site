//  FormatToolBar.hpp
//
//  Horizontal toolbar (Word-like) with font, size, style, alignment, colors,
//  line width, position and size of the selected objects.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef FormatToolBar_hpp
#define FormatToolBar_hpp


#include <QToolBar>


class QComboBox;
class QDoubleSpinBox;
class QFontComboBox;
class QToolButton;


namespace glabels
{

        namespace model
        {
                class Model;
        }

        class UndoRedoModel;


        class FormatToolBar : public QToolBar
        {
                Q_OBJECT

        public:
                explicit FormatToolBar( QWidget* parent = nullptr );

                void setModel( model::Model* model, UndoRedoModel* undoRedoModel );


        signals:
                // A change was applied: the work area should get the keyboard focus back
                void applied();

        private slots:
                void onModelChanged();

                void onFontFamily( const QString& family );
                void onFontSize();
                void onBold( bool on );
                void onItalic( bool on );
                void onUnderline( bool on );
                void onHAlign( int index );
                void onVAlign( int index );
                void onTextColor();
                void onFillColor();
                void onNoFill();
                void onLineColor();
                void onNoLine();


        private:
                void pickColor( bool text, bool fill );
                void setSwatch( QToolButton* button, const QColor& color, bool none );
                QToolButton* addToggle( const QString& text, const QString& tip );
                QToolButton* addIconButton( const QString& iconName, const QString& tip, int group, int index );


        private:
                model::Model*  mModel = nullptr;
                UndoRedoModel* mUndoRedoModel = nullptr;
                bool           mUpdating = false;

                QFontComboBox*  mFontCombo;
                QComboBox*      mSizeCombo;
                QToolButton*    mBold;
                QToolButton*    mItalic;
                QToolButton*    mUnderline;
                QToolButton*    mHAlign[3];
                QToolButton*    mVAlign[3];
                QToolButton*    mTextColor;
                QToolButton*    mFillColor;
                QToolButton*    mLineColor;
        };

}


#endif // FormatToolBar_hpp
