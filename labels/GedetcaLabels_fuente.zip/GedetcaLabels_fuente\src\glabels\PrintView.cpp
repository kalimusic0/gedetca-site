//  PrintView.cpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "PrintView.hpp"

#include "PrinterMonitor.hpp"
#include "PrintFormDialog.hpp"

#include "model/Settings.hpp"

#include <QDebug>
#include <QFileDialog>
#include <QBoxLayout>
#include <QMessageBox>
#include <cstring>
#include <QIcon>
#include <QPainter>
#include <QPixmap>
#include <QPushButton>
#include <QSvgRenderer>
#include <QToolButton>
#include <QPrinter>
#include <QPrinterInfo>
#include <QPrintDialog>
#include <QProcess>

#ifdef Q_OS_WIN
#include <windows.h>
#include <winspool.h>
#include <string>
#endif


#ifdef Q_OS_WIN
namespace
{
        // Centers the first window that opens on this thread (the driver's preferences window)
        HHOOK gCenterHook   = nullptr;
        HWND  gCenterParent = nullptr;
        HWND  gCenterDone   = nullptr;

        LRESULT CALLBACK centerDriverWindow( int code, WPARAM wParam, LPARAM lParam )
        {
                if ( code == HCBT_ACTIVATE )
                {
                        HWND h = reinterpret_cast<HWND>( wParam );
                        if ( h && h != gCenterParent && h != gCenterDone )
                        {
                                gCenterDone = h;

                                RECT r;
                                GetWindowRect( h, &r );
                                MONITORINFO mi = {};
                                mi.cbSize = sizeof( mi );
                                GetMonitorInfoW( MonitorFromWindow( gCenterParent, MONITOR_DEFAULTTONEAREST ), &mi );

                                int w = r.right - r.left;
                                int ht = r.bottom - r.top;
                                int x = mi.rcWork.left + ( ( mi.rcWork.right  - mi.rcWork.left ) - w  ) / 2;
                                int y = mi.rcWork.top  + ( ( mi.rcWork.bottom - mi.rcWork.top  ) - ht ) / 2;
                                SetWindowPos( h, nullptr, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE );
                        }
                }
                return CallNextHookEx( gCenterHook, code, wParam, lParam );
        }
}
#endif


namespace glabels
{

        ///
        /// Constructor
        ///
        PrintView::PrintView( QWidget *parent )
                : QWidget(parent), mModel(nullptr), mBlocked(false)
        {
                setupUi( this );

                titleLabel->setText( QString( "<span style='font-size:18pt;'>%1</span>" ).arg( tr("Print") ) );

                auto* printerMonitor = PrinterMonitor::instance();
                loadDestinations( printerMonitor->availablePrinters() );
                connect( printerMonitor, SIGNAL(availablePrintersChanged(QStringList)),
                         this, SLOT(onAvailablePrintersChanged(QStringList)) );

                setDestination( model::Settings::recentPrinter() );

                preview->setRenderer( &mRenderer );

                // "Use form": quick entry of the values of the variables used by the label,
                // placed right above the Print button
                auto* formButton = new QToolButton();
                formButton->setText( tr("Use form...") );
                formButton->setToolTip( tr("Type the values of the variables used by the label, then print.") );
                formButton->setSizePolicy( printButton->sizePolicy() );
                formButton->setIconSize( printButton->iconSize() );
                formButton->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
                {
                        // Form icon: a sheet with a line of text and a field per row
                        const char* svg =
                                "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'>"
                                "<rect x='5' y='3' width='22' height='26' rx='2' fill='white' stroke='#1c1c1c' stroke-width='1.6'/>"
                                "<rect x='8' y='7' width='10' height='2.4' fill='#1c1c1c'/>"
                                "<rect x='8' y='12' width='5' height='2' fill='#1c1c1c'/>"
                                "<rect x='14.5' y='11' width='10' height='4' fill='white' stroke='#1f7ae0' stroke-width='1.2'/>"
                                "<rect x='8' y='18' width='5' height='2' fill='#1c1c1c'/>"
                                "<rect x='14.5' y='17' width='10' height='4' fill='white' stroke='#1f7ae0' stroke-width='1.2'/>"
                                "<rect x='8' y='24' width='5' height='2' fill='#1c1c1c'/>"
                                "<rect x='14.5' y='23' width='10' height='4' fill='white' stroke='#1f7ae0' stroke-width='1.2'/>"
                                "</svg>";
                        QSvgRenderer renderer( QByteArray::fromRawData( svg, int( strlen( svg ) ) ) );
                        QIcon icon;
                        for ( int s : { 32, 48, 64 } )
                        {
                                QPixmap pix( s, s );
                                pix.fill( Qt::transparent );
                                QPainter painter( &pix );
                                painter.setRenderHint( QPainter::Antialiasing );
                                renderer.render( &painter );
                                painter.end();
                                icon.addPixmap( pix );
                        }
                        formButton->setIcon( icon );
                }
                if ( auto* box = findChild<QBoxLayout*>( "verticalLayout_2" ) )
                {
                        int i = box->indexOf( printButton );
                        if ( i >= 0 )
                        {
                                box->insertWidget( i, formButton );
                        }
                }
                connect( formButton, &QPushButton::clicked, this, [this]() { onUseFormClicked(); } );

                // "Printer settings": the properties window of the printer driver (speed, darkness, paper size...),
                // placed right below the Print button
                auto* settingsButton = new QToolButton();
                settingsButton->setText( tr("Printer settings...") );
                settingsButton->setToolTip( tr("Open the properties of the selected printer (speed, darkness, paper size...).") );
                settingsButton->setSizePolicy( printButton->sizePolicy() );
                settingsButton->setIconSize( printButton->iconSize() );
                settingsButton->setToolButtonStyle( Qt::ToolButtonTextBesideIcon );
                {
                        // Printer with a gear
                        const char* svg =
                                "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'>"
                                "<rect x='9' y='4' width='14' height='8' fill='white' stroke='#1c1c1c' stroke-width='1.6'/>"
                                "<rect x='3' y='11' width='26' height='11' rx='2' fill='#1c1c1c'/>"
                                "<rect x='9' y='18' width='14' height='9' fill='white' stroke='#1c1c1c' stroke-width='1.6'/>"
                                "<circle cx='25' cy='15' r='1.2' fill='white'/>"
                                "<circle cx='25' cy='25' r='4.2' fill='white' stroke='#1f7ae0' stroke-width='2.2'/>"
                                "<circle cx='25' cy='25' r='1.4' fill='#1f7ae0'/>"
                                "<g stroke='#1f7ae0' stroke-width='2.2'>"
                                "<line x1='25' y1='19.2' x2='25' y2='20.6'/><line x1='25' y1='29.4' x2='25' y2='30.8'/>"
                                "<line x1='19.2' y1='25' x2='20.6' y2='25'/><line x1='29.4' y1='25' x2='30.8' y2='25'/>"
                                "</g></svg>";
                        QSvgRenderer renderer( QByteArray::fromRawData( svg, int( strlen( svg ) ) ) );
                        QIcon icon;
                        for ( int s : { 32, 48, 64 } )
                        {
                                QPixmap pix( s, s );
                                pix.fill( Qt::transparent );
                                QPainter painter( &pix );
                                painter.setRenderHint( QPainter::Antialiasing );
                                renderer.render( &painter );
                                painter.end();
                                icon.addPixmap( pix );
                        }
                        settingsButton->setIcon( icon );
                }
                if ( auto* box = findChild<QBoxLayout*>( "verticalLayout_2" ) )
                {
                        int i = box->indexOf( printButton );
                        if ( i >= 0 )
                        {
                                box->insertWidget( i + 1, settingsButton );
                        }
                }
                connect( settingsButton, &QToolButton::clicked, this, [this]() { onPrinterSettingsClicked(); } );

                // Only a real printer has settings (not "Print to file")
                auto updateSettingsButton = [this, settingsButton]()
                {
                        settingsButton->setEnabled( !QPrinterInfo::printerInfo( destinationCombo->currentText() ).isNull() );
                };
                connect( destinationCombo, &QComboBox::currentTextChanged, this, [updateSettingsButton]( const QString& ) { updateSettingsButton(); } );
                updateSettingsButton();
        }


        ///
        /// "Printer settings" button: properties window of the printer driver
        ///
        void PrintView::onPrinterSettingsClicked()
        {
                QString printerName = destinationCombo->currentText();
                if ( QPrinterInfo::printerInfo( printerName ).isNull() )
                {
                        QMessageBox::information( this, tr("Printer settings"),
                                                  tr("Select a printer first. \"Print to file\" has no settings.") );
                        return;
                }

#ifdef Q_OS_WIN
                // Printing preferences of the driver (the window with the "Options" tab: speed,
                // darkness, paper size...). Shown with DocumentProperties; if accepted, the result
                // is saved as the user's default settings of that printer, so that printing uses it.
                std::wstring name = printerName.toStdWString();
                HANDLE hPrinter = nullptr;
                bool ok = false;
                if ( OpenPrinterW( const_cast<LPWSTR>( name.c_str() ), &hPrinter, nullptr ) )
                {
                        HWND hwnd = reinterpret_cast<HWND>( window()->winId() );
                        LONG size = DocumentPropertiesW( hwnd, hPrinter, const_cast<LPWSTR>( name.c_str() ),
                                                         nullptr, nullptr, 0 );
                        if ( size > 0 )
                        {
                                QByteArray current( size, 0 );
                                QByteArray edited( size, 0 );
                                auto* devIn  = reinterpret_cast<DEVMODEW*>( current.data() );
                                auto* devOut = reinterpret_cast<DEVMODEW*>( edited.data() );

                                // current settings of the user, then the window to change them
                                if ( DocumentPropertiesW( hwnd, hPrinter, const_cast<LPWSTR>( name.c_str() ),
                                                          devIn, nullptr, DM_OUT_BUFFER ) == IDOK )
                                {
                                        ok = true;

                                        // The driver window opens at the top left corner: center it on the screen
                                        gCenterParent = hwnd;
                                        gCenterDone   = nullptr;
                                        gCenterHook   = SetWindowsHookExW( WH_CBT, centerDriverWindow, nullptr, GetCurrentThreadId() );

                                        LONG result = DocumentPropertiesW( hwnd, hPrinter, const_cast<LPWSTR>( name.c_str() ),
                                                                           devOut, devIn,
                                                                           DM_IN_BUFFER | DM_IN_PROMPT | DM_OUT_BUFFER );

                                        if ( gCenterHook )
                                        {
                                                UnhookWindowsHookEx( gCenterHook );
                                                gCenterHook = nullptr;
                                        }
                                        if ( result == IDOK )
                                        {
                                                PRINTER_INFO_9W info9 = {};
                                                info9.pDevMode = devOut;
                                                SetPrinterW( hPrinter, 9, reinterpret_cast<LPBYTE>( &info9 ), 0 );
                                        }
                                }
                        }
                        ClosePrinter( hPrinter );
                }
                if ( !ok )
                {
                        QMessageBox::warning( this, tr("Printer settings"),
                                              tr("Could not open the properties of \"%1\".").arg( printerName ) );
                }
#else
                QMessageBox::information( this, tr("Printer settings"),
                                          tr("Use the system print dialog to change the settings of the printer.") );
#endif
        }


        ///
        /// "Use form" button: ask for the values of the variables used by the label
        ///
        void PrintView::onUseFormClicked()
        {
                if ( !mModel )
                {
                        return;
                }

                PrintFormDialog dialog( mModel, this );
                if ( !dialog.hasVariables() )
                {
                        QMessageBox::information( this, tr("Use form"),
                                                  tr("This label does not use any variable.") );
                        return;
                }

                if ( dialog.exec() == QDialog::Accepted )
                {
                        dialog.applyValues();   // the preview follows the model
                }
        }


        ///
        /// Set Model
        ///
        void PrintView::setModel( model::Model* model )
        {
                mModel = model;
                mRenderer.setModel( mModel );

                connect( mModel, SIGNAL(changed()), this, SLOT(onModelChanged()) );

                onModelChanged();
        }


        ///
        /// Available printers changed handler
        ///
        void PrintView::onAvailablePrintersChanged( QStringList printers )
        {
                auto savedSelection = destinationCombo->currentText();
                loadDestinations( printers );
                setDestination( savedSelection );
        }


        ///
        /// Model changed handler
        ///
        void PrintView::onModelChanged()
        {
                printRangeStartPositionSpin->setRange( 1, mModel->frame()->nLabels() );
                printRangeLastPositionSpin->setRange( 1, mModel->frame()->nLabels() );
                mergeStartPositionSpin->setRange( 1, mModel->frame()->nLabels() );

                printRangeBox->setVisible( mModel->merge()->keys().empty() );
                mergeBox->setVisible( !mModel->merge()->keys().empty() );
                mergeOnlyOptions->setVisible( !mModel->merge()->keys().empty() );

                onFormChanged();
        }


        ///
        /// Update view
        ///
        void PrintView::updateView()
        {
                if ( mRenderer.nPages() == 1 )
                {
                        if ( mRenderer.nItems() == 1 )
                        {
                                printDescriptionLabel->setText( tr("(Will print a total of 1 item on 1 page.)") );
                        }
                        else
                        {
                                printDescriptionLabel->setText( tr("(Will print a total of %1 items on 1 page.)")
                                                                .arg(mRenderer.nItems()) );
                        }
                }
                else
                {
                        printDescriptionLabel->setText( tr("(Will print a total of %1 items on %2 pages.)")
                                                        .arg(mRenderer.nItems()).arg(mRenderer.nPages()) );
                }

                pageSpin->setRange( 1, mRenderer.nPages() );
                nPagesLabel->setText( QString::number( mRenderer.nPages() ) );

                bool canPrint = mRenderer.nItems();
                printButton->setEnabled( canPrint );
                printDescriptionLabel->setEnabled( canPrint );
                systemDialogButton->setEnabled( canPrint );

                mRenderer.setIPage( pageSpin->value() - 1 ); // Update preview
        }


        ///
        /// Form changed handler
        ///
        void PrintView::onFormChanged()
        {
                if ( !mBlocked )
                {
                        mBlocked = true;

                        if ( mModel->merge()->keys().empty() )
                        {
                                // Simple project (no merge)
                                if ( printRangePagesRadio->isChecked() )
                                {
                                        // Print full sheets of labels
                                        int nItemsPerPage = mModel->frame()->nLabels();

                                        printRangePagesSpin->setEnabled( true );

                                        printRangeStartPositionSpin->setEnabled( false );
                                        printRangeLastPositionSpin->setEnabled( false );

                                        printRangeStartPositionSpin->setMaximum( nItemsPerPage );
                                        printRangeLastPositionSpin->setMinimum( 1 );

                                        printRangeStartPositionSpin->setValue( 1 );
                                        printRangeLastPositionSpin->setValue( nItemsPerPage );

                                        mRenderer.setNCopies( printRangePagesSpin->value()*nItemsPerPage );
                                        mRenderer.setStartItem( 0 );
                                }
                                else
                                {
                                        // Print a partial sheet of labels
                                        int iStart = printRangeStartPositionSpin->value();
                                        int iLast  = printRangeLastPositionSpin->value();

                                        printRangePagesSpin->setEnabled( false );

                                        printRangeStartPositionSpin->setEnabled( true );
                                        printRangeLastPositionSpin->setEnabled( true );

                                        printRangeStartPositionSpin->setMaximum( iLast );
                                        printRangeLastPositionSpin->setMinimum( iStart );

                                        mRenderer.setNCopies( iLast - iStart + 1 );
                                        mRenderer.setStartItem( iStart - 1 );
                                }
                        }
                        else
                        {
                                // Project with merge
                                bool isMultipleCopies = mergeCopiesSpin->value() > 1;

                                mergeCollateCombo->setEnabled ( isMultipleCopies );
                                mergeGroupCombo->setEnabled ( isMultipleCopies );

                                mRenderer.setNCopies( mergeCopiesSpin->value() );
                                mRenderer.setIsCollated( mergeCollateCombo->currentIndex() == 1 );
                                mRenderer.setAreGroupsContiguous( mergeGroupCombo->currentIndex() == 0 );
                                mRenderer.setStartItem( mergeStartPositionSpin->value() - 1 );
                        }

                        mRenderer.setPrintOutlines( printOutlinesCheck->isChecked() );
                        mRenderer.setPrintCropMarks( printCropMarksCheck->isChecked() );
                        mRenderer.setPrintReverse( printReverseCheck->isChecked() );

                        updateView();

                        mBlocked = false;
                }
        }


        ///
        /// Print Button Clicked handler
        ///
        void PrintView::onPrintButtonClicked()
        {
                auto printerName = destinationCombo->currentText();
                auto printerInfo = QPrinterInfo::printerInfo( printerName );
                bool isPrinter = !printerInfo.isNull();

                QPrinter printer( QPrinter::HighResolution );
                printer.setColorMode( QPrinter::Color );

                if ( isPrinter )
                {
                        printer.setPrinterName( printerName );
                        mRenderer.print( &printer );
                        model::Settings::setRecentPrinter( printerName );
                }
                else
                {
                        QString fileName =
                                QFileDialog::getSaveFileName( this,
                                                              tr("Print to file (PDF)"),
                                                              defaultPdf(),
                                                              tr("PDF files (*.pdf);;All files (*)"),
                                                              nullptr,
                                                              QFileDialog::DontConfirmOverwrite        );
                        if ( !fileName.isEmpty() )
                        {
                                if ( QFileInfo::exists(fileName) )
                                {
                                        QMessageBox msgBox( this );
                                        msgBox.setWindowTitle( tr("Print to file (PDF)") );
                                        msgBox.setIcon( QMessageBox::Warning );
                                        msgBox.setText( tr("%1 already exists.").arg(fileName) );
                                        msgBox.setInformativeText( tr("Do you want to overwrite it?") );
                                        msgBox.setStandardButtons( QMessageBox::Yes | QMessageBox::No );
                                        msgBox.setDefaultButton( QMessageBox::No );

                                        if ( msgBox.exec() == QMessageBox::No )
                                        {
                                                return;
                                        }
                                }

                                printer.setOutputFileName( fileName );
                                printer.setOutputFormat( QPrinter::PdfFormat );
                                mRenderer.print( &printer );
                        }
                }
        }


        ///
        /// System Dialog Button Clicked handler
        ///
        void PrintView::onSystemDialogButtonClicked()
        {
                QPrinter printer( QPrinter::HighResolution );
                printer.setColorMode( QPrinter::Color );
                printer.setPrinterName( destinationCombo->currentText() );

                QPrintDialog printDialog( &printer, this );
                printDialog.setOption( QAbstractPrintDialog::PrintToFile,        true );
                printDialog.setOption( QAbstractPrintDialog::PrintSelection,     false );
                printDialog.setOption( QAbstractPrintDialog::PrintPageRange,     false );
                printDialog.setOption( QAbstractPrintDialog::PrintShowPageSize,  true );
                printDialog.setOption( QAbstractPrintDialog::PrintCollateCopies, false );
                printDialog.setOption( QAbstractPrintDialog::PrintCurrentPage,   false );

                if ( printDialog.exec() == QDialog::Accepted )
                {
                        mRenderer.print( &printer );

                        if ( !printer.printerName().isEmpty() )
                        {
                                model::Settings::setRecentPrinter( printer.printerName() );
                        }
                }
        }


        ///
        /// Load available printers
        ///
        void PrintView::loadDestinations( const QStringList& printers )
        {
                destinationCombo->blockSignals( true );

                destinationCombo->clear();
                for ( auto& printerName : printers )
                {
                        destinationCombo->addItem( QIcon::fromTheme( "glabels-print" ), printerName  );
                }

                if ( destinationCombo->count() )
                {
                        destinationCombo->insertSeparator( destinationCombo->count() );
                }
                destinationCombo->addItem( QIcon::fromTheme( "glabels-file-new" ), tr( "Print to file (PDF)" ) );

                destinationCombo->blockSignals( false );
        }


        ///
        /// Generate default PDF filename
        ///
        QString PrintView::defaultPdf()
        {
                if ( !mModel )
                {
                        return "output.pdf";
                }
                return mModel->dirPath() + "/" + mModel->shortName() + ".pdf";
        }


        ///
        /// Set destination to printerName if valid, or to a fallback value
        ///
        void PrintView::setDestination( const QString& printerName )
        {
                destinationCombo->blockSignals( true );

                auto printerInfo = QPrinterInfo::printerInfo( printerName );

                if ( !printerInfo.isNull() )
                {
                        // printerName is a valid printer
                        destinationCombo->setCurrentText( printerName );
                }
                else
                {
                        auto defaultPrinterName = QPrinterInfo::defaultPrinterName();
                        auto defaultPrinterInfo = QPrinterInfo::printerInfo( defaultPrinterName );
                        if ( !defaultPrinterInfo.isNull() )
                        {
                                // defaultPinterName is a valid printer
                                destinationCombo->setCurrentText( defaultPrinterName );
                        }
                        else
                        {
                                // No default printer available, set to first item in combo (probably "print to file")
                                destinationCombo->setCurrentIndex( 0 );
                        }
                }

                destinationCombo->blockSignals( false );
        }


} // namespace glabels
