//  TextTransformEditor.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "TextTransformEditor.hpp"

#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QScrollArea>
#include <QToolButton>
#include "TransformDialogs.hpp"
#include <QVBoxLayout>


namespace glabels
{

        TextTransformEditor::TextTransformEditor( QWidget* parent )
                : QWidget( parent )
        {
                // ---- Skip ("Omitir")
                auto* skipBox = new QGroupBox( tr("Skip") );
                auto* skipLayout = new QVBoxLayout( skipBox );

                mNeverRadio = new QRadioButton( tr("Do not suppress") );
                mEmptyRadio = new QRadioButton( tr("Suppress when this data is empty") );
                mFieldRadio = new QRadioButton( tr("Suppress when the following field meets the condition:") );
                mNeverRadio->setChecked( true );

                mFieldCombo = new QComboBox();
                mFieldCombo->setEditable( true );
                mFieldCombo->setMinimumContentsLength( 10 );
                mCondCombo = new QComboBox();
                mCondCombo->addItem( tr("Is empty") );
                mCondCombo->addItem( tr("Is not empty") );
                mCondCombo->addItem( tr("Equals") );
                mCondCombo->addItem( tr("Is different from") );
                mCondCombo->addItem( tr("Contains") );
                mValueEdit = new QLineEdit();
                mValueEdit->setPlaceholderText( tr("Value") );

                auto* condLayout = new QHBoxLayout();
                condLayout->setContentsMargins( 20, 0, 0, 0 );
                condLayout->addWidget( mFieldCombo, 2 );
                condLayout->addWidget( mCondCombo, 2 );
                condLayout->addWidget( mValueEdit, 2 );

                skipLayout->addWidget( mNeverRadio );
                skipLayout->addWidget( mEmptyRadio );
                skipLayout->addWidget( mFieldRadio );
                skipLayout->addLayout( condLayout );

                // ---- Offset ("Desplazamiento")
                auto* offsetBox = new QGroupBox( tr("Offset") );
                auto* offsetForm = new QFormLayout( offsetBox );
                auto* originCombo = new QComboBox();
                originCombo->addItem( tr("Constant") );
                originCombo->setEnabled( false );
                offsetForm->addRow( tr("Offset source:"), originCombo );

                mOffsetSpin = new QSpinBox();
                mOffsetSpin->setRange( -999999, 999999 );
                offsetForm->addRow( tr("Offset:"), mOffsetSpin );

                mUnitCombo = new QComboBox();
                mUnitCombo->addItem( tr("Second(s)" ) );
                mUnitCombo->addItem( tr("Minute(s)" ) );
                mUnitCombo->addItem( tr("Hour(s)" ) );
                mUnitCombo->addItem( tr("Day(s)" ) );
                mUnitCombo->addItem( tr("Week(s)" ) );
                mUnitCombo->addItem( tr("Month(s)" ) );
                mUnitCombo->addItem( tr("Year(s)" ) );
                mUnitCombo->setCurrentIndex( int(model::TextFormat::DAYS) );
                offsetForm->addRow( tr("Units:"), mUnitCombo );

                auto* offsetNote = new QLabel( tr("Applies to date and time data.") );
                offsetNote->setWordWrap( true );
                offsetForm->addRow( offsetNote );

                // ---- Prefix and suffix
                auto* attachBox = new QGroupBox( tr("Attached text") );
                auto* attachForm = new QFormLayout( attachBox );
                mPrefixEdit = new QLineEdit();
                mSuffixEdit = new QLineEdit();
                attachForm->addRow( tr("Prefix:"), mPrefixEdit );
                attachForm->addRow( tr("Suffix:"), mSuffixEdit );

                // ---- Search and replace, script, serialization (each opens a dialog)
                auto makeRow = [this]( QLineEdit*& summary, const char* slot ) -> QHBoxLayout*
                {
                        summary = new QLineEdit();
                        summary->setReadOnly( true );
                        auto* button = new QToolButton();
                        button->setText( "..." );
                        auto* row = new QHBoxLayout();
                        row->addWidget( summary, 1 );
                        row->addWidget( button );
                        connect( button, SIGNAL(clicked()), this, slot );
                        return row;
                };

                auto* advancedBox = new QGroupBox( tr("Data processing") );
                auto* advancedForm = new QFormLayout( advancedBox );
                advancedForm->addRow( tr("Search and replace:"), makeRow( mReplaceSummary, SLOT(onEditReplace()) ) );
                advancedForm->addRow( tr("Command script:"),     makeRow( mScriptSummary,  SLOT(onEditScript()) ) );
                advancedForm->addRow( tr("Serialization:"),      makeRow( mSerialSummary,  SLOT(onEditSerial()) ) );

                // Everything goes in a scroll area: the tab is taller than the side panel
                auto* content = new QWidget();
                auto* main = new QVBoxLayout( content );
                main->setContentsMargins( 6, 6, 6, 6 );
                // ---- Source of the value: own text or the value of another object
                auto* sourceBox = new QGroupBox( tr("Value source") );
                auto* sourceLayout = new QVBoxLayout( sourceBox );
                mOwnRadio = new QRadioButton( tr("Own text (the Editor box of the text tab)") );
                mObjectRadio = new QRadioButton( tr("Value of another object") );
                mOwnRadio->setChecked( true );
                mObjectCombo = new QComboBox();
                mKindCombo = new QComboBox();
                mKindCombo->addItem( tr("Data (before the format)") );
                mKindCombo->addItem( tr("Text as shown (with format)") );
                auto* sourceForm = new QFormLayout();
                sourceForm->setContentsMargins( 20, 0, 0, 0 );
                sourceForm->addRow( tr("Object name:"), mObjectCombo );
                sourceForm->addRow( tr("Value:"), mKindCombo );
                sourceLayout->addWidget( mOwnRadio );
                sourceLayout->addWidget( mObjectRadio );
                sourceLayout->addLayout( sourceForm );

                main->addWidget( sourceBox );
                main->addWidget( skipBox );
                main->addWidget( offsetBox );
                main->addWidget( attachBox );
                main->addWidget( advancedBox );
                main->addStretch( 1 );

                auto* scroll = new QScrollArea();
                scroll->setWidgetResizable( true );
                scroll->setFrameShape( QFrame::NoFrame );
                scroll->setWidget( content );

                auto* outer = new QVBoxLayout( this );
                outer->setContentsMargins( 0, 0, 0, 0 );
                outer->addWidget( scroll );

                updateSummaries();

                connect( mOwnRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mObjectCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mKindCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mNeverRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mEmptyRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mFieldRadio, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mFieldCombo, SIGNAL(editTextChanged(QString)), this, SLOT(onControlsChanged()) );
                connect( mCondCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mValueEdit, SIGNAL(textEdited(QString)), this, SLOT(onControlsChanged()) );
                connect( mOffsetSpin, SIGNAL(valueChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mUnitCombo, SIGNAL(currentIndexChanged(int)), this, SLOT(onControlsChanged()) );
                connect( mPrefixEdit, SIGNAL(textEdited(QString)), this, SLOT(onControlsChanged()) );
                connect( mSuffixEdit, SIGNAL(textEdited(QString)), this, SLOT(onControlsChanged()) );

                updateEnabled();
        }


        void TextTransformEditor::setObjectNames( const QStringList& names )
        {
                bool wasBlocked = mBlocked;
                mBlocked = true;
                QString current = mObjectCombo->currentText();
                mObjectCombo->clear();
                mObjectCombo->addItems( names );
                if ( !current.isEmpty() )
                {
                        int i = mObjectCombo->findText( current );
                        if ( i >= 0 ) mObjectCombo->setCurrentIndex( i );
                }
                mBlocked = wasBlocked;
        }


        void TextTransformEditor::setSource( const QString& objectName, int kind )
        {
                mBlocked = true;
                bool byObject = !objectName.isEmpty();
                mObjectRadio->setChecked( byObject );
                mOwnRadio->setChecked( !byObject );
                if ( byObject )
                {
                        int i = mObjectCombo->findText( objectName );
                        if ( i < 0 )
                        {
                                // the object does not exist (any more): keep its name so nothing is lost
                                mObjectCombo->addItem( objectName );
                                i = mObjectCombo->findText( objectName );
                        }
                        mObjectCombo->setCurrentIndex( i );
                }
                mKindCombo->setCurrentIndex( kind == 1 ? 1 : 0 );
                updateEnabled();
                mBlocked = false;
        }


        QString TextTransformEditor::sourceName() const
        {
                return mObjectRadio->isChecked() ? mObjectCombo->currentText() : QString();
        }


        int TextTransformEditor::sourceKind() const
        {
                return mKindCombo->currentIndex();
        }


        void TextTransformEditor::setFieldNames( const QStringList& names )
        {
                mFieldNames = names;
                bool wasBlocked = mBlocked;
                mBlocked = true;
                QString current = mFieldCombo->currentText();
                mFieldCombo->clear();
                mFieldCombo->addItems( names );
                mFieldCombo->setCurrentText( current );
                mBlocked = wasBlocked;
        }


        void TextTransformEditor::fillFormat( model::TextFormat& f ) const
        {
                f.suppressMode  = mFieldRadio->isChecked() ? model::TextFormat::SUPPRESS_IF_FIELD
                                : mEmptyRadio->isChecked() ? model::TextFormat::SUPPRESS_IF_EMPTY
                                                           : model::TextFormat::SUPPRESS_NEVER;
                f.suppressField = mFieldCombo->currentText().trimmed();
                f.suppressCond  = model::TextFormat::Condition( mCondCombo->currentIndex() );
                f.suppressValue = mValueEdit->text();
                f.offsetValue   = mOffsetSpin->value();
                f.offsetUnit    = model::TextFormat::OffsetUnit( mUnitCombo->currentIndex() );
                f.prefix        = mPrefixEdit->text();
                f.suffix        = mSuffixEdit->text();
                f.replaceActions = mAdvanced.replaceActions;
                f.script         = mAdvanced.script;
                f.serialMode     = mAdvanced.serialMode;
                f.serialMethod   = mAdvanced.serialMethod;
                f.serialLowerCase = mAdvanced.serialLowerCase;
                f.serialPreserve = mAdvanced.serialPreserve;
                f.serialStep     = mAdvanced.serialStep;
                f.serialEvent    = mAdvanced.serialEvent;
                f.serialInterval = mAdvanced.serialInterval;
        }


        void TextTransformEditor::setFormat( const model::TextFormat& f )
        {
                mBlocked = true;

                mNeverRadio->setChecked( f.suppressMode == model::TextFormat::SUPPRESS_NEVER );
                mEmptyRadio->setChecked( f.suppressMode == model::TextFormat::SUPPRESS_IF_EMPTY );
                mFieldRadio->setChecked( f.suppressMode == model::TextFormat::SUPPRESS_IF_FIELD );
                mFieldCombo->setCurrentText( f.suppressField );
                mCondCombo->setCurrentIndex( int(f.suppressCond) );
                mValueEdit->setText( f.suppressValue );
                mOffsetSpin->setValue( f.offsetValue );
                mUnitCombo->setCurrentIndex( int(f.offsetUnit) );
                mPrefixEdit->setText( f.prefix );
                mSuffixEdit->setText( f.suffix );
                mAdvanced = f;
                updateSummaries();

                updateEnabled();

                mBlocked = false;
        }


        void TextTransformEditor::updateEnabled()
        {
                mObjectCombo->setEnabled( mObjectRadio->isChecked() );
                mKindCombo->setEnabled( mObjectRadio->isChecked() );

                bool byField = mFieldRadio->isChecked();
                mFieldCombo->setEnabled( byField );
                mCondCombo->setEnabled( byField );
                bool needsValue = byField &&
                        ( mCondCombo->currentIndex() >= int(model::TextFormat::COND_EQUALS) );
                mValueEdit->setEnabled( needsValue );
        }


        void TextTransformEditor::onControlsChanged()
        {
                updateEnabled();
                if ( !mBlocked )
                {
                        emit changed();
                }
        }


        void TextTransformEditor::updateSummaries()
        {
                int n = mAdvanced.replaceActions.size();
                mReplaceSummary->setText( n == 0 ? tr("<None>") : tr("%1 action(s)").arg( n ) );

                QString script = mAdvanced.script.trimmed();
                mScriptSummary->setText( script.isEmpty() ? tr("<None>")
                                                          : tr("%1 line(s)").arg( script.count( '\n' ) + 1 ) );

                QString serial = tr("<None>");
                if ( mAdvanced.serialMode != model::TextFormat::SERIAL_NONE )
                {
                        serial = ( mAdvanced.serialMode == model::TextFormat::SERIAL_INCREMENT ? tr("Increment") : tr("Decrement") )
                                 + QString( " %1" ).arg( mAdvanced.serialStep );
                }
                mSerialSummary->setText( serial );
        }


        void TextTransformEditor::onEditReplace()
        {
                SearchReplaceDialog dialog( mAdvanced.replaceActions, this );
                if ( dialog.exec() == QDialog::Accepted )
                {
                        mAdvanced.replaceActions = dialog.actions();
                        updateSummaries();
                        emit changed();
                }
        }


        void TextTransformEditor::onEditScript()
        {
                ScriptDialog dialog( mAdvanced.script, mFieldNames, this );
                if ( dialog.exec() == QDialog::Accepted )
                {
                        mAdvanced.script = dialog.script();
                        updateSummaries();
                        emit changed();
                }
        }


        void TextTransformEditor::onEditSerial()
        {
                SerializationDialog dialog( mAdvanced, this );
                if ( dialog.exec() == QDialog::Accepted )
                {
                        dialog.fillFormat( mAdvanced );
                        updateSummaries();
                        emit changed();
                }
        }
}
