<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About gLabels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Color name</name>
    <message>
        <source>Light Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very Dark Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darker Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lighter Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very Light Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditVariableDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Factory</name>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV), keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV), keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Colon Separated Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Colon Separated Values, keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values, keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Excel workbook (.xlsx), field names in row 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <source>%1 x %2 (%3 per sheet)</source>
        <extracomment>%1 = number of labels across a page, %2 = number of labels down a page, %3 = total number of labels on a page (sheet).</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 per sheet</source>
        <extracomment>%1 is the total number of labels on a page (sheet).</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameCd</name>
    <message>
        <source>diameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameContinuous</name>
    <message>
        <source>wide</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameRound</name>
    <message>
        <source>diameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GenericTemplate</name>
    <message>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 full-page labels</source>
        <extracomment>%1 = page size. (e.g. A4)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 envelope</source>
        <extracomment>%1 = envelope size. (e.g. DL)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 half-page labels</source>
        <extracomment>%1 = page size. (e.g. A4)</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 quarter-page labels</source>
        <extracomment>%1 = page size. (e.g. A4)</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MergeView</name>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unselect all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectEditor</name>
    <message>
        <source>Object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alignment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrap mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anywhere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow printing to shrink text to fit object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Family:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checksum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line/Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position/Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estirar texto para llenar el cuadro (deformar)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>gLabels - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Centimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Picas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top left corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a light appearance for user interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a dark appearance for user interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically adjust appearance based on system color scheme.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inherit current working directory from parent process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Startup in user&apos;s home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Startup in user&apos;s docments directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User defined startup directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vector</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintView</name>
    <message>
        <source>Copies:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>print outlines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>print crop marks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>print in reverse (i.e. a mirror image)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Positions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uncollated (e.g.  1,1,1   2,2,2   3,3,3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collated   (e.g.  1,2,3   1,2,3   1,2,3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge groups are contiguous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge groups start on a new page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start groups at position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use system print dialog...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesView</name>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustable Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select horizontal or vertical orientation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Similar Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select another product for this gLabels project.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBugDialog</name>
    <message>
        <source>gLabels - Report a Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Launch Issue Tracker</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectProductDialog</name>
    <message>
        <source>gLabels - Select Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter by paper size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISO sizes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>US sizes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter by category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search entire product database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select from recently used products.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StartupView</name>
    <message>
        <source>Welcome to gLabels.  Let&apos;s get started:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new blank gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a recent gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerApplyPage</name>
    <message>
        <source>You have completed the gLabels Product Template Designer.  If you wish to accept and save your product template, click &quot;Save.&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otherwise, you may click &quot;Cancel&quot; to abandon your design or &quot;Back&quot; to review or continue editing this product template.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerCdPage</name>
    <message>
        <source>6. Margin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Outer radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4. Clipping height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2. Inner radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3. Clipping width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5. Waste:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerContinuousPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerEllipsePage</name>
    <message>
        <source>2. Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3. Waste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4. Margin:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerIntroPage</name>
    <message>
        <source>Copy/Edit Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy and edit an existing product template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new product template from scratch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This dialog will help you create a custom product template. Let&apos;s get started:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNLayoutsPage</name>
    <message>
        <source>A layout is a set of labels or cards that can be arranged in a simple grid.  Most products only need one layout, as in the first example below.  The second example illustrates when two layouts are needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products needing only one layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products needing two layouts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: if more than two layouts are required, the product template must be edited manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two layouts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNamePage</name>
    <message>
        <source>(e.g. &quot;Mailing Labels,&quot; &quot;Business Cards,&quot; ...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brand:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(e.g. 8163A)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(e.g. Avery, Acme, ...)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Number across (nx):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPageSizePage</name>
    <message>
        <source>Roll width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPathPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRectPage</name>
    <message>
        <source>4. Horizontal waste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3. Corner radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5. Vertical waste:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2. Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6. Margin (X):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7. Margin (Y):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRoundPage</name>
    <message>
        <source>3. Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1. Radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2. Waste:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerShapePage</name>
    <message>
        <source>Rectangular or square (can have rounded corners)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Round</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elliptical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD/DVD (including credit card CDs)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number across (nx):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Units</name>
    <message>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>picas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Variable</name>
    <message>
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VariablesView</name>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit selected variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::AboutDialog</name>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A program to create labels and business cards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::BarcodeTextEditor</name>
    <message>
        <source>Use a custom text format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This barcode style has its own text. Check to draw the text with the format below.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text above the barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow printing to shrink the text to fit the object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stretch text to fill the box (deform)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ColorHistory</name>
    <message>
        <source>color %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ColorPaletteDialog</name>
    <message>
        <source>Standard Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Color %1</source>
        <extracomment>%1 = color specification in hex. String must not contain a colon (:).</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::CropDialog</name>
    <message>
        <source>Crop image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drag the edges or corners of the rectangle; drag inside to move it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::EditVariableDialog</name>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ExportImageDialog</name>
    <message>
        <source>Export image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut to the label shape (rounded corners, ellipse...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 images will be created (one per selected merge record); a number is added to the file name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name may contain {name}, {date}, {time}, {datetime}, {n} and {field} (any merge field or variable), e.g. C:\Labels\{lote}.png</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::FieldButton</name>
    <message>
        <source>Merge fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::FieldListWidget</name>
    <message>
        <source>Arrastre un campo al área de trabajo para crear un texto o un código de barras</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::File</name>
    <message>
        <source>gLabels - Open Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>glabels files (*.glabels);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to open &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels - Save Project As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Label As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::FormatToolBar</name>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font size (pt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align text left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align text right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align text to top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align text to middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align text to bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text alignment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::LabelEditor</name>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Texto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Código de barras</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::MainWindow</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current gLabels project to a different name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Edit mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Properties mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Merge mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Variables mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Print mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create custom templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close the current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit glabels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut the selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete the selected objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select all objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Un-select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all selections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of the grid in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Markup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of markup lines in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increase magnification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrease magnification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;1 to 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restore scale to 100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom to &amp;Fit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set scale to fit window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select, move and modify objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create text object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create box object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create line object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create ellipse/circle object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create image object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create barcode object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Raise selection to top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower selection to bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees counter-clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip object(s) horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip object(s) vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to left edges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to horizontal centers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to right edges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to top edges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to vertical centers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to bottom edges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontally center objects in label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertically center objects in label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open gLabels manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About gLabels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rotate/Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(modified)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to project &quot;%1&quot; before closing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your changes will be lost if you don&apos;t save them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save project?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Report Bug...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Report a bug to the developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Quick Access&quot; toolbar in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Editor&quot; toolbar in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;User Manual...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick Access Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to undo.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to redo.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Both</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center objects in label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Campos (arrastre al área de trabajo)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 180</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate object(s) 180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 1 degree left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate object(s) 1 degree counter-clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 1 degree right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate object(s) 1 degree clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make selected objects as wide as the first selected one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Same height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make selected objects as tall as the first selected one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export the label to a PNG image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick image export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export the label to a PNG image in the quick export folder, without asking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick export folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the folder used by the quick image export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing was exported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 image(s) exported. Last: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick export folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick export folder: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the properties window of the selected object (or double click on it)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Objects (select to edit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space Evenly, Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space the selected objects evenly in horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space Evenly, Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space the selected objects evenly in vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quick template...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a custom template in one window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Template &amp;Designer (advanced)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit label to content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resize the label to the box that contains all the objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no objects to fit the label to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This only works with templates that have one label per sheet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit design to label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale all the objects so the design fits the label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no objects to fit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop the selected image dragging a rectangle over it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Etiqueta del sistema: solo lectura. Se edita desde Gedetca Web.  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Etiqueta del sistema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esta etiqueta pertenece al sistema (se hizo en el Modelador de Gedetca Web).

Se abre en solo lectura: se puede ver e imprimir, pero solo se edita desde Gedetca Web.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::MergeView</name>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select merge file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data files (*.xlsx *.csv *.txt *.tsv);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ObjectEditor</name>
    <message>
        <source>No line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Box object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>line/fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>position/size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ellipse object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image files (*.png *.jpg *.jpeg *.gif *.bmp *.pbm *.pgm *.ppm *.xbm *.xpm *.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG - Portable Network Graphics (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BMP - Windows Bitmap (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GIF - Graphics Interchange Format (*.gif)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JPEG - Joint Photographic Experts Group (*.jpg *.jpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PBM - Portable Bitmap (*.pbm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PGM - Portable Graymap (*.pgm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PPM - Portable Pixmap (*.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SVG - Scalable Vector Graphics (*.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XBM - X11 Bitmap (*.xbm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XPM - X11 Pixmap (*.xpm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels - Select image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert substitution field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>transform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 wizard...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name of the object. Other texts can take its value by this name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The name cannot be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Another object already has the name &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font of the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size of the selected text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold (selected text)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic (selected text)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline (selected text)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove the formats of the selected text (it takes the format of the object)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bottom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crop the image dragging a rectangle over it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove crop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ObjectListWidget</name>
    <message>
        <source>Objects of the label. Select one to select it in the work area.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PositionToolBar</name>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PreferencesDialog</name>
    <message>
        <source>Select startup directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PrintView</name>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on %2 pages.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Will print a total of 1 item on 1 page.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on 1 page.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print to file (PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF files (*.pdf);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use form...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type the values of the variables used by the label, then print.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This label does not use any variable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printer settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the properties of the selected printer (speed, darkness, paper size...).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Printer settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a printer first. &quot;Print to file&quot; has no settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open the properties of &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the system print dialog to change the settings of the printer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PropertiesView</name>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Product</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ReportBugDialog</name>
    <message>
        <source>How to Report a Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To submit a bug report, click on the button below.  This will open a web browser to the gLabels github issue tracking page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be sure to include a detailed description of the problem and how to recreate it.  Attach any screenshots and/or example glabels project files that may illustrate the problem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before submitting a report, look through the existing issues for similar or related bugs.  If the issue has already been reported, please consider contributing to its report instead.  Otherwise, create a new issue report. Please paste the following information into the issue description.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ScriptDialog</name>
    <message>
        <source>Command script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample text (Value):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script error:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JavaScript. The script receives the text in &lt;b&gt;Value&lt;/b&gt; and the merge fields and variables in &lt;b&gt;Fields&lt;/b&gt; (e.g. &lt;code&gt;Fields.lote&lt;/code&gt;). Leave the result in &lt;b&gt;Value&lt;/b&gt;.&lt;br&gt;Use &lt;b&gt;Insert example...&lt;/b&gt; for ready-made commands such as &lt;code&gt;RestarDias(Value, 1)&lt;/code&gt;, or write any JavaScript code (conditions, loops, functions...). Both can be mixed.&lt;br&gt;The script cannot access files, the network or the system, and it is stopped if it runs for more than half a second.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert example...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SearchReplaceDialog</name>
    <message>
        <source>Search and replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trim spaces (start and end)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use wildcards (* and ?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exact text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regular expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First instance only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Result:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SelectProductDialog</name>
    <message>
        <source>List View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only custom templates can be renamed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor and part number cannot be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not rename the template. A template with that vendor and part number may already exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick template...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a custom template: name, shape, size and labels per sheet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make an editable copy of the selected template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit the selected custom template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete the selected custom template.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 (copy)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 (copy %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This template has an advanced design (several layouts or a special shape). Use File &gt; Product Template Designer (advanced).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete the template &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This cannot be undone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SerializationDialog</name>
    <message>
        <source>Serialization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not serialize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alphabetic and/or numeric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Numeric only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alphabetic only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upper case A-Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower case a-z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preserve the number of characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Letters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When to increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Every label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Every copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Every page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence preview...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First value:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SimplePreview</name>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesigner</name>
    <message>
        <source>Product Template Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerApplyPage</name>
    <message>
        <source>Save Product Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click &quot;Save&quot; to save your custom product template!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User product template (%1 %2) already exists.</source>
        <extracomment>%1 = brand name of product (e.g. Avery), %2 = part number of product (e.g. 5026).</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerCdPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerContinuousPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continuous tape product templates are not currently supported by the Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerEllipsePage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerIntroPage</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome to the gLabels Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNLayoutsPage</name>
    <message>
        <source>Number of Layouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select the number of layouts required.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNamePage</name>
    <message>
        <source>Name and Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter the following identifying information about the product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brand and part number match an existing built-in product template!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter parameters for your single layout.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPageSizePage</name>
    <message>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select the product page size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roll</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPathPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path based product templates are not currently supported by the Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRectPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRoundPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerShapePage</name>
    <message>
        <source>Product Shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select the basic product shape.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Layouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter parameters for your two layouts.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TextFormatEditor</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pattern:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use thousands separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show leading zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>decimal places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precision:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negative numbers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>As is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upper case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capitalize each word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data view:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TextTransformEditor</name>
    <message>
        <source>Skip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do not suppress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suppress when this data is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suppress when the following field meets the condition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Is not empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Is different from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Constant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Second(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minute(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hour(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Month(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Year(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Applies to date and time data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attached text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Suffix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search and replace:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Command script:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serialization:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;None&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 action(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 line(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Own text (the Editor box of the text tab)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value of another object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data (before the format)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text as shown (with format)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::VariablesView</name>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::barcode::Backends</name>
    <message>
        <source>Code 39</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 39 Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET (any)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET-5 (ZIP only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET-9 (ZIP+4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET-11 (DPBC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CEPNET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USPS Intelligent Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IEC16022 (DataMatrix)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN (any)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-8+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-8+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-13+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-13+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC (UPC-A or UPC-E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-A +2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-A +5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-E +2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-E +5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISBN +5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 128C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 128B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interleaved 2 of 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codabar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MSI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plessey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 93</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IEC18004 (QRCode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Reply Paid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Route Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Redirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aztec Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 16K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 IATA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Data Logic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 32 (Italian Pharmacode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 49</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 128 (Mode C suppression)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DAFT Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deutsche Post Leitcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deutsche Post Identcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch Post KIX Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1-128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Code 128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Code 39</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Data Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Aztec Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ITF-14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Japanese Postal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean Postal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOGMARS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maxicode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Micro QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MSI Plessey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PLANET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pharmacode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pharmacode 2-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telepen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telepen Numeric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UK Plessey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aztec Runes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CEPNet (Brazilian Post)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codablock-F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked Omni.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Expanded Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC MicroPDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MicroPDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NVE-18 (SSCC-18)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF417 Compact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pharmazentralnummer (PZN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Industrial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DotCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Omnidirectional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Han Xin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flattermarken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DPD Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 4-State Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPU S10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FIM (Facing ID Mark)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rMQR (Rectangular Micro QR)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 4-State Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIN (Vehicle ID Number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Codablock-F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 2-D Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BC412 (SEMI TI-95)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 QR Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::Gs1</name>
    <message>
        <source>alfanuméricos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>numéricos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 caracteres %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hasta %1 caracteres %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escriba un valor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo se permiten caracteres ASCII imprimibles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No se permiten los caracteres [ ] ( ) ^ en este dato.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Máximo %1 caracteres.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo se permiten dígitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El dígito verificador no es correcto (debería ser %1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Escriba %1 dígitos; el dígito verificador se calcula solo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debe tener exactamente %1 dígitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Máximo %1 dígitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La fecha debe ser AAMMDD con mes 01-12 y día 00-31.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::Model</name>
    <message>
        <source>Untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelBarcodeObject</name>
    <message>
        <source>No barcode data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid barcode data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelBoxObject</name>
    <message>
        <source>Box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelEllipseObject</name>
    <message>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelImageObject</name>
    <message>
        <source>No image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelLineObject</name>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelObject</name>
    <message>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelTextObject</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>gLabels Label Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels project files to open, optionally.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>More detailed version information.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
