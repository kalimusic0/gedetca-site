//  TransformDialogs.hpp
//
//  Dialogs of the "transform" tab of text objects: search and replace,
//  command script (JavaScript) and serialization.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef TransformDialogs_hpp
#define TransformDialogs_hpp


#include "ScriptEdit.hpp"
#include "model/TextFormat.hpp"

#include <QCheckBox>
#include <QComboBox>
#include <QDialog>
#include <QLineEdit>
#include <QListWidget>
#include <QPlainTextEdit>
#include <QRadioButton>
#include <QSpinBox>


namespace glabels
{

        ///
        /// Search and replace actions
        ///
        class SearchReplaceDialog : public QDialog
        {
                Q_OBJECT

        public:
                explicit SearchReplaceDialog( const QList<model::TextFormat::ReplaceAction>& actions,
                                              QWidget* parent = nullptr );

                QList<model::TextFormat::ReplaceAction> actions() const { return mActions; }

        private slots:
                void onAdd();
                void onRemove();
                void onUp();
                void onDown();
                void onRowChanged( int row );
                void onFieldEdited();
                void onTest();

        private:
                void loadRow( int row );
                void refreshList( int select );
                void updateEnabled();

                QList<model::TextFormat::ReplaceAction> mActions;

                QListWidget*    mList;
                QLineEdit*      mDescription;
                QComboBox*      mKind;
                QPlainTextEdit* mFind;
                QComboBox*      mSyntax;
                QCheckBox*      mFirstOnly;
                QPlainTextEdit* mReplace;

                bool            mBlocked{ false };
        };


        ///
        /// Command script (JavaScript)
        ///
        class ScriptDialog : public QDialog
        {
                Q_OBJECT

        public:
                explicit ScriptDialog( const QString& script, const QStringList& fieldNames, QWidget* parent = nullptr );

                QString script() const;

        private slots:
                void onTest();

        private:
                ScriptEdit*     mEdit;
        };


        ///
        /// Serialization
        ///
        class SerializationDialog : public QDialog
        {
                Q_OBJECT

        public:
                explicit SerializationDialog( const model::TextFormat& format, QWidget* parent = nullptr );

                void fillFormat( model::TextFormat& format ) const;

        private slots:
                void onControlsChanged();
                void onPreview();

        private:
                model::TextFormat currentFormat() const;

                QRadioButton* mNoneRadio;
                QRadioButton* mIncrementRadio;
                QRadioButton* mDecrementRadio;
                QComboBox*    mMethodCombo;
                QComboBox*    mLettersCombo;
                QCheckBox*    mPreserveCheck;
                QSpinBox*     mStepSpin;
                QComboBox*    mEventCombo;
                QSpinBox*     mIntervalSpin;
        };

}


#endif // TransformDialogs_hpp
