<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About gLabels</source>
        <translation>Quant al gLabels</translation>
    </message>
    <message>
        <source>&amp;License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Color name</name>
    <message>
        <source>Light Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orange</source>
        <translation>Taronja</translation>
    </message>
    <message>
        <source>Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Scarlet Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Orange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Butter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Chameleon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Sky Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Plum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Chocolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Aluminum 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Aluminum 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Negre</translation>
    </message>
    <message>
        <source>Very Dark Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darker Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lighter Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Very Light Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White</source>
        <translation>Blanc</translation>
    </message>
</context>
<context>
    <name>EditVariableDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Factory</name>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV), keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV), keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Colon Separated Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Colon Separated Values, keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values, keys on line 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <source>%1 x %2 (%3 per sheet)</source>
        <extracomment>%1 = number of labels across a page, %2 = number of labels down a page, %3 = total number of labels on a page (sheet).</extracomment>
        <translation>%1 x %2 (%3 per full)</translation>
    </message>
    <message>
        <source>%1 per sheet</source>
        <extracomment>%1 is the total number of labels on a page (sheet).</extracomment>
        <translation>%1 per full</translation>
    </message>
</context>
<context>
    <name>FrameCd</name>
    <message>
        <source>diameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameContinuous</name>
    <message>
        <source>wide</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameRound</name>
    <message>
        <source>diameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MergeView</name>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicació:</translation>
    </message>
    <message>
        <source>Records</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <source>Unselect all</source>
        <translation>No seleccionis res</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectEditor</name>
    <message>
        <source>Object properties</source>
        <translation>Propietats de l&apos;objecte</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alignment:</source>
        <translation>Alineació:</translation>
    </message>
    <message>
        <source>Line spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrap mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Word</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anywhere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation>Cap</translation>
    </message>
    <message>
        <source>Allow printing to shrink text to fit object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Tipus de lletra</translation>
    </message>
    <message>
        <source>Family:</source>
        <translation>Família:</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Mida:</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estil:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Color:</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Codi de barres</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Estil</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checksum</source>
        <translation>Suma de verificació</translation>
    </message>
    <message>
        <source>Barcode data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imatge</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line/Fill</source>
        <translation>Línia/Emplenat</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Amplada:</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Emplenat</translation>
    </message>
    <message>
        <source>Position/Size</source>
        <translation>Posició/Mida</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posició</translation>
    </message>
    <message>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Llargada:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Angle:</translation>
    </message>
    <message>
        <source>Original size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Alçada:</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation>Ombra</translation>
    </message>
    <message>
        <source>X offset:</source>
        <translation>Desplaçament X:</translation>
    </message>
    <message>
        <source>Y offset:</source>
        <translation>Desplaçament Y:</translation>
    </message>
    <message>
        <source>Opacity:</source>
        <translation>Opacitat:</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>gLabels - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Localització</translation>
    </message>
    <message>
        <source>Select locale specific behavior.</source>
        <translation>Seleccioneu el comportament específic de la localització.</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Punts</translation>
    </message>
    <message>
        <source>Centimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Mil·límetres</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Polzades</translation>
    </message>
    <message>
        <source>Picas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Graella</translation>
    </message>
    <message>
        <source>Configure grid behavior.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top left corner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintView</name>
    <message>
        <source>Copies:</source>
        <translation>Còpies:</translation>
    </message>
    <message>
        <source>print outlines</source>
        <translation>imprimeix els contorns</translation>
    </message>
    <message>
        <source>print crop marks</source>
        <translation>imprimeix les marques de tall</translation>
    </message>
    <message>
        <source>print in reverse (i.e. a mirror image)</source>
        <translation>imprimeix invertit (és a dir, com una imatge reflectida en un mirall)</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Positions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uncollated (e.g.  1,1,1   2,2,2   3,3,3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Collated   (e.g.  1,2,3   1,2,3   1,2,3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge groups are contiguous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge groups start on a new page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start groups at position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>Use system print dialog...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesView</name>
    <message>
        <source>Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>Núm. de model:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripció:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Mida de la pàgina:</translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation>Mida de &apos;etiqueta:</translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation>Disposició:</translation>
    </message>
    <message>
        <source>Change product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustable Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select horizontal or vertical orientation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Similar Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select another product for this gLabels project.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBugDialog</name>
    <message>
        <source>gLabels - Report a Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Launch Issue Tracker</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectProductDialog</name>
    <message>
        <source>gLabels - Select Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter by paper size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ISO sizes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>US sizes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter by category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search entire product database.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select from recently used products.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>Núm. de model:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripció:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Mida de la pàgina:</translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation>Mida de &apos;etiqueta:</translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation>Disposició:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionat</translation>
    </message>
</context>
<context>
    <name>StartupView</name>
    <message>
        <source>Welcome to gLabels.  Let&apos;s get started:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new blank gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a recent gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New...</source>
        <translation>Nou …</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerApplyPage</name>
    <message>
        <source>You have completed the gLabels Product Template Designer.  If you wish to accept and save your product template, click &quot;Save.&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otherwise, you may click &quot;Cancel&quot; to abandon your design or &quot;Back&quot; to review or continue editing this product template.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerCdPage</name>
    <message>
        <source>6. Margin:</source>
        <translation>6. Marge:</translation>
    </message>
    <message>
        <source>1. Outer radius:</source>
        <translation>1. Radi exterior:</translation>
    </message>
    <message>
        <source>4. Clipping height:</source>
        <translation>4. Alçada de retallada:</translation>
    </message>
    <message>
        <source>2. Inner radius:</source>
        <translation>2. Radi interior:</translation>
    </message>
    <message>
        <source>3. Clipping width:</source>
        <translation>3. Amplada de retallada:</translation>
    </message>
    <message>
        <source>5. Waste:</source>
        <translation>5. Residu :</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerContinuousPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerEllipsePage</name>
    <message>
        <source>2. Height:</source>
        <translation>2. Alçada:</translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation>1. Amplada:</translation>
    </message>
    <message>
        <source>3. Waste:</source>
        <translation>3. Residu :</translation>
    </message>
    <message>
        <source>4. Margin:</source>
        <translation>4. Marge:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerIntroPage</name>
    <message>
        <source>Copy/Edit Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy and edit an existing product template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Product</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new product template from scratch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This dialog will help you create a custom product template. Let&apos;s get started:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNLayoutsPage</name>
    <message>
        <source>A layout is a set of labels or cards that can be arranged in a simple grid.  Most products only need one layout, as in the first example below.  The second example illustrates when two layouts are needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products needing only one layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products needing two layouts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: if more than two layouts are required, the product template must be edited manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two layouts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNamePage</name>
    <message>
        <source>(e.g. &quot;Mailing Labels,&quot; &quot;Business Cards,&quot; ...)</source>
        <translation>(p. ex. «Etiquetes de correu», «Targetes de visita», etc.)</translation>
    </message>
    <message>
        <source>Brand:</source>
        <translation>Marca:</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>Núm. de model:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripció:</translation>
    </message>
    <message>
        <source>(e.g. 8163A)</source>
        <translation>(p. ex. 8163A)</translation>
    </message>
    <message>
        <source>(e.g. Avery, Acme, ...)</source>
        <translation>(p. ex. Avery, Acme, …)</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Number across (nx):</source>
        <translation>Nombre per amplada (nx):</translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation>Nombre per alçada (ny):</translation>
    </message>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation>Distància des de la vora esquerra (x0):</translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation>Distància des de la vora superior (y0):</translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation>Separació horitzontal (dx):</translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation>Separació vertical (dy):</translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation>Imprimeix un full de mostra</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPageSizePage</name>
    <message>
        <source>Roll width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Alçada:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Amplada:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Mida de la pàgina:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPathPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRectPage</name>
    <message>
        <source>4. Horizontal waste:</source>
        <translation>2. Residu horitz.:</translation>
    </message>
    <message>
        <source>3. Corner radius</source>
        <translation>3. Radi de la cantonada</translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation>1. Amplada:</translation>
    </message>
    <message>
        <source>5. Vertical waste:</source>
        <translation>5. Residu vert.:</translation>
    </message>
    <message>
        <source>2. Height:</source>
        <translation>2. Alçada:</translation>
    </message>
    <message>
        <source>6. Margin (X):</source>
        <translation>6. Marge (X):</translation>
    </message>
    <message>
        <source>7. Margin (Y):</source>
        <translation>7. Marge (Y):</translation>
    </message>
    <message>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRoundPage</name>
    <message>
        <source>3. Margin</source>
        <translation>3. Marge</translation>
    </message>
    <message>
        <source>1. Radius:</source>
        <translation>1. Radi:</translation>
    </message>
    <message>
        <source>2. Waste:</source>
        <translation>2. Residu :</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerShapePage</name>
    <message>
        <source>Rectangular or square (can have rounded corners)</source>
        <translation>Rectangular o quadrada (pot tenir cantonades arrodonides)</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Circular</translation>
    </message>
    <message>
        <source>Elliptical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CD/DVD (including credit card CDs)</source>
        <translation>CD/DVD (també s&apos;hi inclouen els CD de mida de targeta de crèdit)</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation>Distància des de la vora esquerra (x0):</translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation>Nombre per alçada (ny):</translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation>Distància des de la vora superior (y0):</translation>
    </message>
    <message>
        <source>Number across (nx):</source>
        <translation>Nombre per amplada (nx):</translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation>Separació horitzontal (dx):</translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation>Separació vertical (dy):</translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation>Imprimeix un full de mostra</translation>
    </message>
</context>
<context>
    <name>Units</name>
    <message>
        <source>points</source>
        <translation>punts</translation>
    </message>
    <message>
        <source>inches</source>
        <translation>polzades</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>cm</source>
        <translation>cm</translation>
    </message>
    <message>
        <source>picas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Variable</name>
    <message>
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Floating Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Per page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
</context>
<context>
    <name>VariablesView</name>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>Add variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit selected variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::AboutDialog</name>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A program to create labels and business cards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ColorHistory</name>
    <message>
        <source>color %1</source>
        <translation>color %1</translation>
    </message>
</context>
<context>
    <name>glabels::ColorPaletteDialog</name>
    <message>
        <source>Standard Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom color...</source>
        <translation>Color personalitzat …</translation>
    </message>
    <message>
        <source>Custom Color</source>
        <translation>Color personalitzat</translation>
    </message>
    <message>
        <source>Custom Color %1</source>
        <extracomment>%1 = color specification in hex. String must not contain a colon (:).</extracomment>
        <translation>Color personalitzat %1</translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::EditVariableDialog</name>
    <message>
        <source>Default</source>
        <translation>Predeterminat</translation>
    </message>
</context>
<context>
    <name>glabels::FieldButton</name>
    <message>
        <source>Merge fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::File</name>
    <message>
        <source>gLabels - Open Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>glabels files (*.glabels);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to open &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels - Save Project As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Label As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::LabelEditor</name>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::MainWindow</name>
    <message>
        <source>Welcome</source>
        <translation>Us donem la benvinguda</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Propietats</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation>&amp;Nou …</translation>
    </message>
    <message>
        <source>Create a new gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation>&amp;Obre …</translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Desa</translation>
    </message>
    <message>
        <source>Save current gLabels project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation>&amp;Anomena i desa …</translation>
    </message>
    <message>
        <source>Save current gLabels project to a different name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <source>Select project Edit mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>P&amp;ropietats</translation>
    </message>
    <message>
        <source>Select project Properties mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Merge mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select project Variables mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>Im&amp;primeix</translation>
    </message>
    <message>
        <source>Select project Print mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Template &amp;Designer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create custom templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close the current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit glabels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <source>Cut the selection</source>
        <translation>Retalla la selecció</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>Copy the selection</source>
        <translation>Copia la selecció</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Enganxa</translation>
    </message>
    <message>
        <source>Paste the clipboard</source>
        <translation>Enganxa el contingut del porta-retalls</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Suprimeix</translation>
    </message>
    <message>
        <source>Delete the selected objects</source>
        <translation>Suprimeix els objectes seleccionats</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation>Selecciona-ho &amp;tot</translation>
    </message>
    <message>
        <source>Select all objects</source>
        <translation>Selecciona tots els objectes</translation>
    </message>
    <message>
        <source>Un-select All</source>
        <translation>No seleccionis res</translation>
    </message>
    <message>
        <source>Remove all selections</source>
        <translation>Desfés totes les seleccions</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation>Preferències</translation>
    </message>
    <message>
        <source>Configure the application</source>
        <translation>Configura l&apos;aplicació</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Graella</translation>
    </message>
    <message>
        <source>Change visibility of the grid in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Markup</source>
        <translation>Marques</translation>
    </message>
    <message>
        <source>Change visibility of markup lines in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>&amp;Amplia</translation>
    </message>
    <message>
        <source>Increase magnification</source>
        <translation>Incrementa l&apos;ampliació</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation>&amp;Redueix</translation>
    </message>
    <message>
        <source>Decrease magnification</source>
        <translation>Redueix l&apos;ampliació</translation>
    </message>
    <message>
        <source>Zoom &amp;1 to 1</source>
        <translation>Amplia a &amp;1:1</translation>
    </message>
    <message>
        <source>Restore scale to 100%</source>
        <translation>Refés l&apos;escala a 100%</translation>
    </message>
    <message>
        <source>Zoom to &amp;Fit</source>
        <translation>&amp;Millor ajust</translation>
    </message>
    <message>
        <source>Set scale to fit window</source>
        <translation>Estableix l&apos;escala per a encabir-ho a la finestra</translation>
    </message>
    <message>
        <source>Select Mode</source>
        <translation>Mode de selecció</translation>
    </message>
    <message>
        <source>Select, move and modify objects</source>
        <translation>Seleccioneu, moveu i modifiqueu objectes</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Create text object</source>
        <translation>Crea un objecte de text</translation>
    </message>
    <message>
        <source>Box</source>
        <translation>Quadre</translation>
    </message>
    <message>
        <source>Create box object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <source>Create line object</source>
        <translation>Crea un objecte línia</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>El·lipse</translation>
    </message>
    <message>
        <source>Create ellipse/circle object</source>
        <translation>Crea un objecte el·lipse/cercle</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imatge</translation>
    </message>
    <message>
        <source>Create image object</source>
        <translation>Crea un objecte d&apos;imatge</translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Codi de barres</translation>
    </message>
    <message>
        <source>Create barcode object</source>
        <translation>Crea un objecte de codi de barres</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation>Porta al primer pla</translation>
    </message>
    <message>
        <source>Raise selection to top</source>
        <translation>Alça l&apos;objecte fins al primer pla</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation>Porta al fons</translation>
    </message>
    <message>
        <source>Lower selection to bottom</source>
        <translation>Baixa l&apos;objecte fins al fons</translation>
    </message>
    <message>
        <source>Rotate Left</source>
        <translation>Gira a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees counter-clockwise</source>
        <translation>Gira l&apos;objecte 90 graus en el sentit contrari a les agulles del rellotge</translation>
    </message>
    <message>
        <source>Rotate Right</source>
        <translation>Gira a la dreta</translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees clockwise</source>
        <translation>Gira l&apos;objecte 90 graus en el sentit de les agulles del rellotge</translation>
    </message>
    <message>
        <source>Flip Horizontally</source>
        <translation>Capgira horitzontalment</translation>
    </message>
    <message>
        <source>Flip object(s) horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip Vertically</source>
        <translation>Capgira verticalment</translation>
    </message>
    <message>
        <source>Flip object(s) vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Alinea a l&apos;esquerra</translation>
    </message>
    <message>
        <source>Align objects to left edges</source>
        <translation>Alinea els objectes a les vores esquerres</translation>
    </message>
    <message>
        <source>Align Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to horizontal centers</source>
        <translation>Alinea els objectes als centres horitzontals</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Alinea a la dreta</translation>
    </message>
    <message>
        <source>Align objects to right edges</source>
        <translation>Alinea els objectes a les vores dretes</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to top edges</source>
        <translation>Alinea els objectes a les vores superiors</translation>
    </message>
    <message>
        <source>Align Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to vertical centers</source>
        <translation>Alinea els objectes als centres verticals</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align objects to bottom edges</source>
        <translation>Alinea els objectes a les vores inferiors</translation>
    </message>
    <message>
        <source>Center Horizontally</source>
        <translation>Centra horitzontalment</translation>
    </message>
    <message>
        <source>Horizontally center objects in label</source>
        <translation>Centra els objectes al centre horitzontal de l&apos;etiqueta</translation>
    </message>
    <message>
        <source>Center Vertically</source>
        <translation>Centra verticalment</translation>
    </message>
    <message>
        <source>Vertically center objects in label</source>
        <translation>Centra els objectes al centre vertical de l&apos;etiqueta</translation>
    </message>
    <message>
        <source>Open gLabels manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation>&amp;Quant a …</translation>
    </message>
    <message>
        <source>About gLabels</source>
        <translation>Quant al gLabels</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fitxer</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Visualitza</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Objects</source>
        <translation>&amp;Objectes</translation>
    </message>
    <message>
        <source>&amp;Create</source>
        <translation>&amp;Crea</translation>
    </message>
    <message>
        <source>&amp;Order</source>
        <translation>&amp;Ordena</translation>
    </message>
    <message>
        <source>&amp;Rotate/Flip</source>
        <translation>&amp;Gira/Capgira</translation>
    </message>
    <message>
        <source>&amp;Alignment</source>
        <translation>&amp;Alineació</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>A&amp;juda</translation>
    </message>
    <message>
        <source>&amp;Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(modified)</source>
        <translation>(modificat)</translation>
    </message>
    <message>
        <source>Save changes to project &quot;%1&quot; before closing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your changes will be lost if you don&apos;t save them.</source>
        <translation>Es perdran els vostres canvis si no els deseu.</translation>
    </message>
    <message>
        <source>Save project?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <source>Create Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Report Bug...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Report a bug to the developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Quick Access&quot; toolbar in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Editor&quot; toolbar in current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;User Manual...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick Access Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to undo.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to redo.</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Both</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center objects in label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::MergeView</name>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select merge file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ObjectEditor</name>
    <message>
        <source>No line</source>
        <translation>Sense línia</translation>
    </message>
    <message>
        <source>No fill</source>
        <translation>Sense emplenament</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Box object properties</source>
        <translation>Propietats de l&apos;objecte quadre</translation>
    </message>
    <message>
        <source>line/fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>position/size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ellipse object properties</source>
        <translation>Propietats de l&apos;objecte el·lipse</translation>
    </message>
    <message>
        <source>Image object properties</source>
        <translation>Propietats de l&apos;objecte imatge</translation>
    </message>
    <message>
        <source>image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line object properties</source>
        <translation>Propietats de l&apos;objecte línia</translation>
    </message>
    <message>
        <source>Text object properties</source>
        <translation>Propietats de l&apos;objecte text</translation>
    </message>
    <message>
        <source>text</source>
        <translation>text</translation>
    </message>
    <message>
        <source>Barcode object properties</source>
        <translation>Propietats de l&apos;objecte codi de barres</translation>
    </message>
    <message>
        <source>barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Object properties</source>
        <translation>Propietats de l&apos;objecte</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Emplenat</translation>
    </message>
    <message>
        <source>Image files (*.png *.jpg *.jpeg *.gif *.bmp *.pbm *.pgm *.ppm *.xbm *.xpm *.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNG - Portable Network Graphics (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BMP - Windows Bitmap (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GIF - Graphics Interchange Format (*.gif)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JPEG - Joint Photographic Experts Group (*.jpg *.jpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PBM - Portable Bitmap (*.pbm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PGM - Portable Graymap (*.pgm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PPM - Portable Pixmap (*.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SVG - Scalable Vector Graphics (*.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XBM - X11 Bitmap (*.xbm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XPM - X11 Pixmap (*.xpm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels - Select image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Mida</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation>Ombra</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posició</translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Codi de barres</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert substitution field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PrintView</name>
    <message>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on %2 pages.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Will print a total of 1 item on 1 page.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on 1 page.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print to file (PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF files (*.pdf);;All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::PropertiesView</name>
    <message>
        <source>Properties</source>
        <translation>Propietats</translation>
    </message>
    <message>
        <source>Product Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Product</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::ReportBugDialog</name>
    <message>
        <source>How to Report a Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To submit a bug report, click on the button below.  This will open a web browser to the gLabels github issue tracking page.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Be sure to include a detailed description of the problem and how to recreate it.  Attach any screenshots and/or example glabels project files that may illustrate the problem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Before submitting a report, look through the existing issues for similar or related bugs.  If the issue has already been reported, please consider contributing to its report instead.  Otherwise, create a new issue report. Please paste the following information into the issue description.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SelectProductDialog</name>
    <message>
        <source>List View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::SimplePreview</name>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesigner</name>
    <message>
        <source>Product Template Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerApplyPage</name>
    <message>
        <source>Save Product Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click &quot;Save&quot; to save your custom product template!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User product template (%1 %2) already exists.</source>
        <extracomment>%1 = brand name of product (e.g. Avery), %2 = part number of product (e.g. 5026).</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerCdPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerContinuousPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continuous tape product templates are not currently supported by the Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerEllipsePage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerIntroPage</name>
    <message>
        <source>Welcome</source>
        <translation>Us donem la benvinguda</translation>
    </message>
    <message>
        <source>Welcome to the gLabels Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNLayoutsPage</name>
    <message>
        <source>Number of Layouts</source>
        <translation>Nombre de disposicions</translation>
    </message>
    <message>
        <source>Please select the number of layouts required.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNamePage</name>
    <message>
        <source>Name and Description</source>
        <translation>Nom i descripció</translation>
    </message>
    <message>
        <source>Please enter the following identifying information about the product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brand and part number match an existing built-in product template!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Layout</source>
        <translation>Disposició</translation>
    </message>
    <message>
        <source>Please enter parameters for your single layout.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPageSizePage</name>
    <message>
        <source>Page Size</source>
        <translation>Mida de la pàgina</translation>
    </message>
    <message>
        <source>Please select the product page size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Una altra</translation>
    </message>
    <message>
        <source>Roll</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPathPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path based product templates are not currently supported by the Product Template Designer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRectPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRoundPage</name>
    <message>
        <source>Product Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerShapePage</name>
    <message>
        <source>Product Shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select the basic product shape.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Layouts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter parameters for your two layouts.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::VariablesView</name>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::barcode::Backends</name>
    <message>
        <source>Code 39</source>
        <translation>Codi 39</translation>
    </message>
    <message>
        <source>Code 39 Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPC-A</source>
        <translation>UPC-A</translation>
    </message>
    <message>
        <source>EAN-13</source>
        <translation>EAN-13</translation>
    </message>
    <message>
        <source>POSTNET (any)</source>
        <translation>POSTNET (qualsevol)</translation>
    </message>
    <message>
        <source>POSTNET-5 (ZIP only)</source>
        <translation>POSTNET-5 (només codi postal ZIP)</translation>
    </message>
    <message>
        <source>POSTNET-9 (ZIP+4)</source>
        <translation>POSTNET-9 (codi postal ZIP+4)</translation>
    </message>
    <message>
        <source>POSTNET-11 (DPBC)</source>
        <translation>POSTNET-11 (DPBC)</translation>
    </message>
    <message>
        <source>CEPNET</source>
        <translation>CEPNET</translation>
    </message>
    <message>
        <source>USPS Intelligent Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IEC16022 (DataMatrix)</source>
        <translation>IEC16022 (DataMatrix)</translation>
    </message>
    <message>
        <source>EAN (any)</source>
        <translation>EAN (qualsevol)</translation>
    </message>
    <message>
        <source>EAN-8</source>
        <translation>EAN-8</translation>
    </message>
    <message>
        <source>EAN-8+2</source>
        <translation>EAN-8+2</translation>
    </message>
    <message>
        <source>EAN-8+5</source>
        <translation>EAN-8+5</translation>
    </message>
    <message>
        <source>EAN-13+2</source>
        <translation>EAN-13+2</translation>
    </message>
    <message>
        <source>EAN-13+5</source>
        <translation>EAN-13+5</translation>
    </message>
    <message>
        <source>UPC (UPC-A or UPC-E)</source>
        <translation>UPC (UPC-A o UPC-E)</translation>
    </message>
    <message>
        <source>UPC-A +2</source>
        <translation>UPC-A +2</translation>
    </message>
    <message>
        <source>UPC-A +5</source>
        <translation>UPC-A +5</translation>
    </message>
    <message>
        <source>UPC-E</source>
        <translation>UPC-E</translation>
    </message>
    <message>
        <source>UPC-E +2</source>
        <translation>UPC-E +2</translation>
    </message>
    <message>
        <source>UPC-E +5</source>
        <translation>UPC-E +5</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>ISBN +5</source>
        <translation>ISBN +5</translation>
    </message>
    <message>
        <source>Code 128</source>
        <translation>Codi 128</translation>
    </message>
    <message>
        <source>Code 128C</source>
        <translation>Codi 128C</translation>
    </message>
    <message>
        <source>Code 128B</source>
        <translation>Codi 128B</translation>
    </message>
    <message>
        <source>Interleaved 2 of 5</source>
        <translation>Interfoliat 2 de 5</translation>
    </message>
    <message>
        <source>Codabar</source>
        <translation>Codabar</translation>
    </message>
    <message>
        <source>MSI</source>
        <translation>MSI</translation>
    </message>
    <message>
        <source>Plessey</source>
        <translation>Plessey</translation>
    </message>
    <message>
        <source>Code 93</source>
        <translation>Code 93</translation>
    </message>
    <message>
        <source>IEC18004 (QRCode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Reply Paid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Route Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Australia Post Redirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aztec Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 11</source>
        <translation>Code 11</translation>
    </message>
    <message>
        <source>Code 16K</source>
        <translation>Code 16K</translation>
    </message>
    <message>
        <source>Code 2 of 5 IATA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Data Logic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 32 (Italian Pharmacode)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 49</source>
        <translation>Code 49</translation>
    </message>
    <message>
        <source>Code 128 (Mode C suppression)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DAFT Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data Matrix</source>
        <translation>Data Matrix</translation>
    </message>
    <message>
        <source>Deutsche Post Leitcode</source>
        <translation>Deutsche Post Leitcode</translation>
    </message>
    <message>
        <source>Deutsche Post Identcode</source>
        <translation>Deutsche Post Identcode</translation>
    </message>
    <message>
        <source>Dutch Post KIX Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN</source>
        <translation>EAN</translation>
    </message>
    <message>
        <source>Grid Matrix</source>
        <translation>Grid Matrix</translation>
    </message>
    <message>
        <source>GS1-128</source>
        <translation>GS1-128</translation>
    </message>
    <message>
        <source>HIBC Code 128</source>
        <translation>HIBC Code 128</translation>
    </message>
    <message>
        <source>HIBC Code 39</source>
        <translation>HIBC Code 39</translation>
    </message>
    <message>
        <source>HIBC Data Matrix</source>
        <translation>HIBC Data Matrix</translation>
    </message>
    <message>
        <source>HIBC QR Code</source>
        <translation>HIBC QR Code</translation>
    </message>
    <message>
        <source>HIBC PDF417</source>
        <translation>HIBC PDF417</translation>
    </message>
    <message>
        <source>HIBC Aztec Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ITF-14</source>
        <translation>ITF-14</translation>
    </message>
    <message>
        <source>Japanese Postal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Korean Postal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOGMARS</source>
        <translation>LOGMARS</translation>
    </message>
    <message>
        <source>Maxicode</source>
        <translation>Maxicode</translation>
    </message>
    <message>
        <source>Micro QR Code</source>
        <translation>Micro QR Code</translation>
    </message>
    <message>
        <source>MSI Plessey</source>
        <translation>MSI Plessey</translation>
    </message>
    <message>
        <source>PDF417</source>
        <translation>PDF417</translation>
    </message>
    <message>
        <source>PLANET</source>
        <translation>PLANET</translation>
    </message>
    <message>
        <source>Pharmacode</source>
        <translation>Pharmacode</translation>
    </message>
    <message>
        <source>Pharmacode 2-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telepen</source>
        <translation>Telepen</translation>
    </message>
    <message>
        <source>Telepen Numeric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UK Plessey</source>
        <translation>UK Plessey</translation>
    </message>
    <message>
        <source>Aztec Runes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CEPNet (Brazilian Post)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codablock-F</source>
        <translation>Codablock-F</translation>
    </message>
    <message>
        <source>Code 2 of 5 Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked Omni.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Expanded Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC MicroPDF417</source>
        <translation>HIBC MicroPDF417</translation>
    </message>
    <message>
        <source>MicroPDF417</source>
        <translation>MicroPDF417</translation>
    </message>
    <message>
        <source>NVE-18 (SSCC-18)</source>
        <translation>NVE-18 (SSCC-18)</translation>
    </message>
    <message>
        <source>PDF417 Compact</source>
        <translation>PDF417 Compact</translation>
    </message>
    <message>
        <source>Pharmazentralnummer (PZN)</source>
        <translation>Pharmazentralnummer (PZN)</translation>
    </message>
    <message>
        <source>Channel Code</source>
        <translation>Channel Code</translation>
    </message>
    <message>
        <source>Code 2 of 5 Industrial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DotCode</source>
        <translation>DotCode</translation>
    </message>
    <message>
        <source>EAN-14</source>
        <translation>EAN-14</translation>
    </message>
    <message>
        <source>GS1 DataBar Omnidirectional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Han Xin</source>
        <translation>Han Xin</translation>
    </message>
    <message>
        <source>Flattermarken</source>
        <translation>Flattermarken</translation>
    </message>
    <message>
        <source>DPD Code</source>
        <translation>DPD Code</translation>
    </message>
    <message>
        <source>POSTNET</source>
        <translation>POSTNET</translation>
    </message>
    <message>
        <source>Royal Mail 4-State Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPU S10</source>
        <translation>UPU S10</translation>
    </message>
    <message>
        <source>FIM (Facing ID Mark)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rMQR (Rectangular Micro QR)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 4-State Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIN (Vehicle ID Number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Codablock-F</source>
        <translation>HIBC Codablock-F</translation>
    </message>
    <message>
        <source>Royal Mail 2-D Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BC412 (SEMI TI-95)</source>
        <translation>BC412 (SEMI TI-95)</translation>
    </message>
</context>
<context>
    <name>glabels::model::Model</name>
    <message>
        <source>Untitled</source>
        <translation>Sense títol</translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelBarcodeObject</name>
    <message>
        <source>No barcode data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid barcode data</source>
        <translation>Les dades del codi de barres no són vàlides</translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelImageObject</name>
    <message>
        <source>No image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelTextObject</name>
    <message>
        <source>Text</source>
        <translation>Text</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <source>gLabels Label Designer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gLabels project files to open, optionally.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
