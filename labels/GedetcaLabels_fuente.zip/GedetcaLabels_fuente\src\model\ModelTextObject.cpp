//  ModelTextObject.cpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "ModelTextObject.hpp"
#include "Model.hpp"

#include "Size.hpp"
#include "TextScript.hpp"
#include "PrintOptions.hpp"

#include <QBrush>
#include <QDebug>
#include <QPen>
#include <QTextDocument>
#include <QTextBlock>
#include <QRegularExpression>


//
// Private
//
namespace
{
        const double marginPts = 3;
        const double stretchMarginPts = 0.5;


        ///
        /// Calculate pixel size
        ///
        /// Assume a virtual DPI of 72 pixels/inch for all QPainter contexts.
        /// Ideally, we should use pointSizes for device independence, but as
        /// of Qt-6.4, the  xcb (X11) and Wayland backends will render the same
        /// font differently. Currently this function is basically the unity
        /// function (i.e. 1 pt = 1 pixel) with rounding, but is a placeholder
        /// that may need to be tweaked for different backends.
        ///
        int pixelSize( double pointSize )
        {
                const double virtual_dpi = 72;
                return qMax( 1, qRound( pointSize * virtual_dpi/72.0 ) );
        }
}


namespace glabels::model
{

        ///
        /// While a text processes its data, the script can read other objects by name: Objeto("TALLA")
        ///
        class ScriptObjectScope
        {
        public:
                ScriptObjectScope( const ModelTextObject*    self,
                                   const merge::Record&      record,
                                   const Variables&          variables )
                        : mPrevious( TextScript::objectResolver() )
                {
                        TextScript::setObjectResolver( [self, &record, &variables]( const QString& name ) -> QString
                        {
                                static thread_local int depth = 0;      // circular references (A reads B, B reads A)
                                if ( depth >= 8 )
                                {
                                        return QString();
                                }
                                Model* model = qobject_cast<Model*>( self->parent() );
                                ModelObject* object = model ? model->objectByName( name ) : nullptr;
                                if ( !object || object == self )
                                {
                                        return QString();
                                }
                                depth++;
                                QString value = object->referenceValue( record, variables, true );
                                depth--;
                                return value;
                        } );
                }

                ~ScriptObjectScope()
                {
                        TextScript::setObjectResolver( mPrevious );
                }

        private:
                TextScript::ObjectResolver mPrevious;
        };

        ///
        /// Constructor
        ///
        ModelTextObject::ModelTextObject()
        {
                mOutline.setOwner( this );

                mHandles.push_back( Handle( this, Handle::NW ) );
                mHandles.push_back( Handle( this, Handle::N ) );
                mHandles.push_back( Handle( this, Handle::NE ) );
                mHandles.push_back( Handle( this, Handle::E ) );
                mHandles.push_back( Handle( this, Handle::SE ) );
                mHandles.push_back( Handle( this, Handle::S ) );
                mHandles.push_back( Handle( this, Handle::SW ) );
                mHandles.push_back( Handle( this, Handle::W ) );

                mText              = "";
                mFontFamily        = "Sans";
                mFontSize          = 10;
                mFontWeight        = QFont::Normal;
                mFontItalicFlag    = false;
                mFontUnderlineFlag = false;
                mTextColorNode     = ColorNode( QColor( 0, 0, 0 ) );
                mTextHAlign        = Qt::AlignLeft;
                mTextVAlign        = Qt::AlignTop;
                mTextWrapMode      = QTextOption::WordWrap;
                mTextLineSpacing   = 1;
                mTextAutoShrink    = false;
        }


        ///
        /// Constructor
        ///
        ModelTextObject::ModelTextObject( Distance              x0,
                                          Distance              y0,
                                          Distance              w,
                                          Distance              h,
                                          bool                  lockAspectRatio,
                                          const QString&        text,
                                          const QString&        fontFamily,
                                          double                fontSize,
                                          QFont::Weight         fontWeight,
                                          bool                  fontItalicFlag,
                                          bool                  fontUnderlineFlag,
                                          ColorNode             textColorNode,
                                          Qt::Alignment         textHAlign,
                                          Qt::Alignment         textVAlign,
                                          QTextOption::WrapMode textWrapMode,
                                          double                textLineSpacing,
                                          bool                  textAutoShrink,
                                          const QTransform&     matrix,
                                          bool                  shadowState,
                                          Distance              shadowX,
                                          Distance              shadowY,
                                          double                shadowOpacity,
                                          const ColorNode&      shadowColorNode )
        : ModelObject( x0,
                       y0,
                       w,
                       h,
                       lockAspectRatio,
                       matrix,
                       shadowState,
                       shadowX,
                       shadowY,
                       shadowOpacity,
                       shadowColorNode )
        {
                mOutline.setOwner( this );

                mHandles.push_back( Handle( this, Handle::NW ) );
                mHandles.push_back( Handle( this, Handle::N ) );
                mHandles.push_back( Handle( this, Handle::NE ) );
                mHandles.push_back( Handle( this, Handle::E ) );
                mHandles.push_back( Handle( this, Handle::SE ) );
                mHandles.push_back( Handle( this, Handle::S ) );
                mHandles.push_back( Handle( this, Handle::SW ) );
                mHandles.push_back( Handle( this, Handle::W ) );

                mText              = text;
                mFontFamily        = fontFamily;
                mFontSize          = fontSize;
                mFontWeight        = fontWeight;
                mFontItalicFlag    = fontItalicFlag;
                mFontUnderlineFlag = fontUnderlineFlag;
                mTextColorNode     = textColorNode;
                mTextHAlign        = textHAlign;
                mTextVAlign        = textVAlign;
                mTextWrapMode      = textWrapMode;
                mTextLineSpacing   = textLineSpacing;
                mTextAutoShrink    = textAutoShrink;

                update(); // Initialize cached editor layouts
        }


        ///
        /// Copy constructor
        ///
        ModelTextObject::ModelTextObject( const ModelTextObject* object )
                : ModelObject(object)
        {
                mText              = object->mText;
                mFontFamily        = object->mFontFamily;
                mFontSize          = object->mFontSize;
                mFontWeight        = object->mFontWeight;
                mFontItalicFlag    = object->mFontItalicFlag;
                mFontUnderlineFlag = object->mFontUnderlineFlag;
                mTextColorNode     = object->mTextColorNode;
                mTextHAlign        = object->mTextHAlign;
                mTextVAlign        = object->mTextVAlign;
                mTextWrapMode      = object->mTextWrapMode;
                mTextLineSpacing   = object->mTextLineSpacing;
                mTextAutoShrink    = object->mTextAutoShrink;
                mTextStretch       = object->mTextStretch;
                mTextFormat        = object->mTextFormat;
                mSourceName        = object->mSourceName;
                mSourceKind        = object->mSourceKind;
                mTextRuns          = object->mTextRuns;

                update(); // Initialize cached editor layouts
        }


        ///
        /// Destructor
        ///
        ModelTextObject::~ModelTextObject()
        {
                qDeleteAll( mEditorLayouts );
                mEditorLayouts.clear();
        }


        ///
        /// Clone
        ///
        ModelTextObject* ModelTextObject::clone() const
        {
                return new ModelTextObject( this );
        }


        ///
        /// Text Property Getter
        ///
        QString ModelTextObject::text() const
        {
                return mText.toString();
        }


        ///
        /// Text Property Setter
        ///
        void ModelTextObject::setText( const QString& value )
        {
                if ( mText.toString() != value )
                {
                        mText = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// FontFamily Property Getter
        ///
        QString ModelTextObject::fontFamily() const
        {
                return mFontFamily;
        }


        ///
        /// FontFamily Property Setter
        ///
        void ModelTextObject::setFontFamily( const QString& value )
        {
                if ( mFontFamily != value )
                {
                        mFontFamily = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// FontSize Property Getter
        ///
        double ModelTextObject::fontSize() const
        {
                return mFontSize;
        }


        ///
        /// FontSize Property Setter
        ///
        void ModelTextObject::setFontSize( double value )
        {
                if ( mFontSize != value )
                {
                        mFontSize = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// FontWeight Property Getter
        ///
        QFont::Weight ModelTextObject::fontWeight() const
        {
                return mFontWeight;
        }


        ///
        /// FontWeight Property Setter
        ///
        void ModelTextObject::setFontWeight( QFont::Weight value )
        {
                if ( mFontWeight != value )
                {
                        mFontWeight = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// FontItalicFlag Property Getter
        ///
        bool ModelTextObject::fontItalicFlag() const
        {
                return mFontItalicFlag;
        }


        ///
        /// FontItalicFlag Property Setter
        ///
        void ModelTextObject::setFontItalicFlag( bool value )
        {
                if ( mFontItalicFlag != value )
                {
                        mFontItalicFlag = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// FontUnderlineFlag Property Getter
        ///
        bool ModelTextObject::fontUnderlineFlag() const
        {
                return mFontUnderlineFlag;
        }


        ///
        /// FontUnderlineFlag Property Setter
        ///
        void ModelTextObject::setFontUnderlineFlag( bool value )
        {
                if ( mFontUnderlineFlag != value )
                {
                        mFontUnderlineFlag = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Text Color Node Property Getter
        ///
        ColorNode ModelTextObject::textColorNode() const
        {
                return mTextColorNode;
        }


        ///
        /// Text Color Node Property Setter
        ///
        void ModelTextObject::setTextColorNode( const ColorNode& value )
        {
                if ( mTextColorNode != value )
                {
                        mTextColorNode = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// TextHAlign Property Getter
        ///
        Qt::Alignment ModelTextObject::textHAlign() const
        {
                return mTextHAlign;
        }


        ///
        /// TextHAlign Property Setter
        ///
        void ModelTextObject::setTextHAlign( Qt::Alignment value )
        {
                if ( mTextHAlign != value )
                {
                        mTextHAlign = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// TextVAlign Property Getter
        ///
        Qt::Alignment ModelTextObject::textVAlign() const
        {
                return mTextVAlign;
        }


        ///
        /// TextVAlign Property Setter
        ///
        void ModelTextObject::setTextVAlign( Qt::Alignment value )
        {
                if ( mTextVAlign != value )
                {
                        mTextVAlign = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Text Wrap Mode Property Getter
        ///
        QTextOption::WrapMode ModelTextObject::textWrapMode() const
        {
                return mTextWrapMode;
        }


        ///
        /// Text Wrap Mode Property Setter
        ///
        void ModelTextObject::setTextWrapMode( QTextOption::WrapMode value )
        {
                if ( mTextWrapMode != value )
                {
                        mTextWrapMode = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// TextLineSpacing Property Getter
        ///
        double ModelTextObject::textLineSpacing() const
        {
                return mTextLineSpacing;
        }


        ///
        /// TextLineSpacing Property Setter
        ///
        void ModelTextObject::setTextLineSpacing( double value )
        {
                if ( mTextLineSpacing != value )
                {
                        mTextLineSpacing = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// TextAutoShrink Property Getter
        ///
        bool ModelTextObject::textAutoShrink() const
        {
                return mTextAutoShrink;
        }


        ///
        /// TextAutoShrink Property Setter
        ///
        void ModelTextObject::setTextAutoShrink( bool value )
        {
                if ( mTextAutoShrink != value )
                {
                        mTextAutoShrink = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// TextFormat Property Getter
        ///
        TextFormat ModelTextObject::textFormat() const
        {
                return mTextFormat;
        }


        ///
        /// TextFormat Property Setter
        ///
        void ModelTextObject::setTextFormat( const TextFormat& value )
        {
                if ( mTextFormat != value )
                {
                        mTextFormat = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// Value of the text before the format: its own text, or the value of another object
        ///
        QString ModelTextObject::baseValue( const merge::Record& record, const Variables& variables ) const
        {
                if ( !mSourceName.isEmpty() )
                {
                        static thread_local int depth = 0;      // stops circular references (A reads B, B reads A)
                        if ( depth >= 8 )
                        {
                                return QString();
                        }

                        Model* model = qobject_cast<Model*>( parent() );
                        ModelObject* source = model ? model->objectByName( mSourceName ) : nullptr;
                        if ( !source || source == this )
                        {
                                return QString();
                        }

                        depth++;
                        QString value = source->referenceValue( record, variables, mSourceKind == 1 );
                        depth--;
                        return value;
                }

                return mEditorPreview ? mText.expandForEditor( record, variables ) : mText.expand( record, variables );
        }


        QString ModelTextObject::textSourceName() const
        {
                return mSourceName;
        }


        int ModelTextObject::textSourceKind() const
        {
                return mSourceKind;
        }


        void ModelTextObject::setTextSource( const QString& name, int kind )
        {
                if ( mSourceName != name || mSourceKind != kind )
                {
                        mSourceName = name;
                        mSourceKind = kind;
                        update();
                        emit changed();
                }
        }


        ///
        /// What other objects read from this text: the data (before the format) or the shown text
        ///
        QString ModelTextObject::referenceValue( const merge::Record& record,
                                                 const Variables&     variables,
                                                 bool                 formatted ) const
        {
                QString v = baseValue( record, variables );
                ScriptObjectScope scope( this, record, variables );
                return formatted ? mTextFormat.process( v, record, variables )
                                 : mTextFormat.preProcess( v, record, variables );
        }


        QString ModelTextObject::defaultNameBase() const
        {
                return tr("Text");
        }


        ///
        /// Expand fields and apply data format
        ///
        QString ModelTextObject::expandText( const merge::Record& record, const Variables& variables ) const
        {
                QString base = baseValue( record, variables );
                ScriptObjectScope scope( this, record, variables );
                return mTextFormat.process( base, record, variables );
        }


        ///
        /// Text shown in the editor (formatted when the text is a literal value)
        ///
        QString ModelTextObject::editorText() const
        {
                QString raw = mText.toString();
                if ( mTextFormat.isDefault() )
                {
                        return raw.isEmpty() ? tr("Text") : raw;
                }

                QString out = mTextFormat.process( raw, merge::Record(), Variables() );
                if ( raw.isEmpty() && out.isEmpty() )
                {
                        return tr("Text");
                }
                return out;
        }


        ///
        /// Text Runs (mixed character formats) Property Getter
        ///
        QString ModelTextObject::textRuns() const
        {
                return TextRun::toString( mTextRuns );
        }


        ///
        /// Text Runs (mixed character formats) Property Setter
        ///
        void ModelTextObject::setTextRuns( const QString& value )
        {
                QList<TextRun> runs = TextRun::fromString( value );
                if ( TextRun::toString( runs ) != TextRun::toString( mTextRuns ) )
                {
                        mTextRuns = runs;
                        update();
                        emit changed();
                }
        }


        ///
        /// Text shown in the editor and, for every character, the index of the raw text it comes from
        /// (empty list when the mapping is unknown: then the object-wide format is used)
        ///
        QString ModelTextObject::editorTextMapped( QList<int>& rawIndex ) const
        {
                rawIndex.clear();
                QString shown = editorText();
                if ( !mTextRuns.isEmpty() && !mText.isEmpty() && shown.length() == mText.toString().length() )
                {
                        for ( int i = 0; i < shown.length(); i++ ) rawIndex << i;
                }
                return shown;
        }


        ///
        /// Expanded text and, for every character, the index of the raw text it comes from
        ///
        QString ModelTextObject::expandTextMapped( const merge::Record& record,
                                                   const Variables&     variables,
                                                   QList<int>&          rawIndex ) const
        {
                rawIndex.clear();
                if ( mTextRuns.isEmpty() || !mSourceName.isEmpty() )
                {
                        return expandText( record, variables );
                }

                QString base = mText.expandMapped( record, variables, mEditorPreview, rawIndex );
                ScriptObjectScope scope( this, record, variables );
                QString out = mTextFormat.process( base, record, variables );
                if ( out.length() != base.length() )
                {
                        rawIndex.clear();   // the format changed the length: the mapping is lost
                }
                return out;
        }


        ///
        /// Give the characters of one block (line of text) their own formats
        ///
        void ModelTextObject::applyRunFormats( QTextLayout*       layout,
                                               const QTextBlock&  block,
                                               const QList<int>&  rawIndex,
                                               double             sizeScale ) const
        {
                if ( mTextRuns.isEmpty() || rawIndex.isEmpty() )
                {
                        return;
                }

                QList<QTextLayout::FormatRange> ranges;

                const int n = block.text().length();
                const int base = block.position();
                int i = 0;
                while ( i < n )
                {
                        int raw = ( base + i < rawIndex.size() ) ? rawIndex[base + i] : -1;
                        TextRun style = TextRun::styleAt( mTextRuns, raw );

                        int j = i + 1;
                        while ( j < n )
                        {
                                int rawJ = ( base + j < rawIndex.size() ) ? rawIndex[base + j] : -1;
                                if ( !TextRun::styleAt( mTextRuns, rawJ ).sameStyle( style ) ) break;
                                j++;
                        }

                        if ( !style.isDefault() )
                        {
                                QTextCharFormat f;
                                if ( style.bold >= 0 )      f.setFontWeight( style.bold ? QFont::Bold : QFont::Normal );
                                if ( style.italic >= 0 )    f.setFontItalic( style.italic );
                                if ( style.underline >= 0 ) f.setFontUnderline( style.underline );
                                if ( !style.family.isEmpty() ) f.setFontFamilies( QStringList( style.family ) );
                                if ( style.size > 0 )       f.setProperty( QTextFormat::FontPixelSize, pixelSize( style.size * sizeScale ) );

                                QTextLayout::FormatRange r;
                                r.start  = i;
                                r.length = j - i;
                                r.format = f;
                                ranges << r;
                        }
                        i = j;
                }

                layout->setFormats( ranges );
        }


        ///
        /// Vertical advance of a line: the font's own, or the real height when the formats are mixed
        ///
        double ModelTextObject::lineAdvance( const QTextLine& line, double dy ) const
        {
                for ( const TextRun& r : mTextRuns )
                {
                        if ( r.size > 0 || !r.family.isEmpty() )
                        {
                                return qMax( line.height() * mTextLineSpacing, 1.0 );
                        }
                }
                return dy;
        }


        ///
        /// Is this object skipped for the given record (format "Omitir")?
        ///
        bool ModelTextObject::isSuppressed( bool inEditor, const merge::Record& record, const Variables& variables ) const
        {
                return !inEditor &&
                       mTextFormat.suppressMode != TextFormat::SUPPRESS_NEVER &&
                       mTextFormat.suppressed( baseValue( record, variables ), record, variables );
        }

        bool ModelTextObject::isPlaceholder() const
        {
                if ( !mText.isEmpty() ) return false;
                if ( mTextFormat.isDefault() ) return true;
                return mTextFormat.process( "", merge::Record(), Variables() ).isEmpty();
        }


        ///
        /// TextStretch Property Getter
        ///
        bool ModelTextObject::textStretch() const
        {
                return mTextStretch;
        }


        ///
        /// TextStretch Property Setter
        ///
        void ModelTextObject::setTextStretch( bool value )
        {
                if ( mTextStretch != value )
                {
                        mTextStretch = value;
                        update();
                        emit changed();
                }
        }


        ///
        /// NaturalSize Property Getter
        ///
        Size ModelTextObject::naturalSize() const
        {
                QFont font;
                font.setFamily( mFontFamily );
                font.setPixelSize( pixelSize( mFontSize ) );
                font.setWeight( mFontWeight );
                font.setItalic( mFontItalicFlag );
                font.setUnderline( mFontUnderlineFlag );

                QTextOption textOption;
                textOption.setAlignment( mTextHAlign );
                textOption.setWrapMode( mTextWrapMode );

                QFontMetricsF fontMetrics( font );
                double dy = fontMetrics.lineSpacing() * mTextLineSpacing;

                QString displayText = editorText();
                QTextDocument document( displayText );

                // Do layouts
                double x = 0;
                double y = 0;
                QRectF boundingRect;
                for ( int i = 0; i < document.blockCount(); i++ )
                {
                        QTextLayout layout( document.findBlockByNumber(i).text() );

                        layout.setFont( font );
                        layout.setTextOption( textOption );
                        layout.setCacheEnabled(true);

                        layout.beginLayout();
                        for ( QTextLine l = layout.createLine(); l.isValid(); l = layout.createLine() )
                        {
                                l.setPosition( QPointF( x, y ) );
                                y += dy;
                        }
                        layout.endLayout();

                        boundingRect = layout.boundingRect().united( boundingRect );
                }

                return Size( boundingRect.width() + 2*marginPts, boundingRect.height() + 2*marginPts );
        }


        ///
        /// Can Text Capability Implementation
        ///
        bool ModelTextObject::canText() const
        {
                return true;
        }


        ///
        /// Draw shadow of object
        ///
        void ModelTextObject::drawShadow( QPainter*            painter,
                                          bool                 inEditor,
                                          const merge::Record& record,
                                          const Variables&     variables ) const
        {
                if ( isSuppressed( inEditor, record, variables ) )
                {
                        return;
                }

                QColor textColor = mTextColorNode.color( record, variables );

                if ( textColor.alpha() )
                {
                        QColor shadowColor = mShadowColorNode.color( record, variables );
                        shadowColor.setAlphaF( mShadowOpacity );

                        if ( inEditor )
                        {
                                drawTextInEditor( painter, shadowColor );
                        }
                        else
                        {
                                drawText( painter, shadowColor, record, variables );
                        }
                }
        }


        ///
        /// Draw object itself
        ///
        void ModelTextObject::drawObject( QPainter*            painter,
                                          bool                 inEditor,
                                          const merge::Record& record,
                                          const Variables&     variables ) const
        {
                if ( isSuppressed( inEditor, record, variables ) )
                {
                        return;
                }

                QColor textColor = mTextColorNode.color( record, variables );

                bool haveData = !record.isEmpty() || !variables.isEmpty();

                if ( inEditor && ( ( mText.hasPlaceHolders() && haveData ) || ( !mTextFormat.isDefault() && !isPlaceholder() ) || !mSourceName.isEmpty() ) )
                {
                        // Show values (merge first record / variable values) instead of ${names}
                        mEditorPreview = true;
                        drawText( painter, textColor, record, variables );
                        mEditorPreview = false;
                }
                else if ( inEditor )
                {
                        drawTextInEditor( painter, textColor );
                }
                else
                {
                        drawText( painter, textColor, record, variables );
                }
        }


        ///
        /// Path to test for hover condition
        ///
        QPainterPath ModelTextObject::hoverPath( double scale ) const
        {
                // The whole box of the text object is its selection area (and nothing outside it)
                QPainterPath path;
                path.addRect( 0, 0, mW.pt(), mH.pt() );
                return path;
        }


        ///
        /// Size updated
        ///
        void ModelTextObject::sizeUpdated()
        {
                update();
        }


        ///
        /// Update cached information for editor view
        ///
        void ModelTextObject::update()
        {
                QFont font;
                font.setFamily( mFontFamily );
                font.setPixelSize( pixelSize( mFontSize ) );
                font.setWeight( mFontWeight );
                font.setItalic( mFontItalicFlag );
                font.setUnderline( mFontUnderlineFlag );

                QTextOption textOption;
                textOption.setAlignment( mTextHAlign );
                textOption.setWrapMode( mTextWrapMode );

                QFontMetricsF fontMetrics( font );
                double dy = fontMetrics.lineSpacing() * mTextLineSpacing;

                QList<int> runMap;
                QString displayText = editorTextMapped( runMap );
                QTextDocument document( displayText );

                qDeleteAll( mEditorLayouts );
                mEditorLayouts.clear();

                // Pass #1 -- do initial layouts
                double x = 0;
                double y = 0;
                QRectF boundingRect;
                for ( int i = 0; i < document.blockCount(); i++ )
                {
                        QTextLayout* layout = new QTextLayout( document.findBlockByNumber(i).text() );

                        layout->setFont( font );
                        layout->setTextOption( textOption );
                        layout->setCacheEnabled(true);
                        applyRunFormats( layout, document.findBlockByNumber(i), runMap, 1.0 );

                        layout->beginLayout();
                        for ( QTextLine l = layout->createLine(); l.isValid(); l = layout->createLine() )
                        {
                                l.setLineWidth( mW.pt() - 2*marginPts );
                                l.setPosition( QPointF( x, y ) );
                                y += lineAdvance( l, dy );
                        }
                        layout->endLayout();

                        mEditorLayouts.append( layout );

                        boundingRect = layout->boundingRect().united( boundingRect );
                }
                double h = boundingRect.height();


                // Pass #2 -- adjust layout positions for vertical alignment and create hover path
                x = marginPts;
                switch ( mTextVAlign )
                {
                case Qt::AlignVCenter:
                        y = mH.pt()/2 - h/2;
                        break;
                case Qt::AlignBottom:
                        y = mH.pt() - h - marginPts;
                        break;
                default:
                        y = marginPts;
                        break;
                }
                QPainterPath hoverPath; // new empty hover path
                for ( QTextLayout* layout : mEditorLayouts )
                {
                        for ( int j = 0; j < layout->lineCount(); j++ )
                        {
                                QTextLine l = layout->lineAt(j);
                                l.setPosition( QPointF( x, y ) );
                                y += lineAdvance( l, dy );

                                hoverPath.addRect( l.naturalTextRect() ); // add to new hover path
                        }
                }

                mHoverPath = hoverPath; // save new hover path
        }


        ///
        /// Draw text in editor from cached information
        ///
        void ModelTextObject::drawTextInEditor( QPainter* painter, const QColor& color ) const
        {
                if ( mTextStretch )
                {
                        painter->save();
                        QColor c = color;
                        if ( isPlaceholder() )
                        {
                                c.setAlphaF( 0.5 * color.alphaF() );
                        }
                        QList<int> runMap;
                        QString shown = editorTextMapped( runMap );
                        drawStretched( painter, c, shown, runMap );
                        painter->restore();
                        return;
                }

                painter->save();

                painter->setClipRect( QRectF( 0, 0, mW.pt(), mH.pt() ) );

                if ( isPlaceholder() )
                {
                        QColor mutedColor = color;
                        mutedColor.setAlphaF( 0.5 * color.alphaF() );
                        painter->setPen( QPen( mutedColor ) );
                }
                else
                {
                        painter->setPen( QPen( color ) );
                }

                for ( QTextLayout* layout : mEditorLayouts )
                {
                        layout->draw( painter, QPointF( 0, 0 ) );
                }

                painter->restore();
        }


        ///
        /// Draw text in final printout or preview
        ///
        void
        ModelTextObject::drawText( QPainter*            painter,
                                   const QColor&        color,
                                   const merge::Record& record,
                                   const Variables&     variables ) const
        {
                if ( mTextStretch )
                {
                        painter->save();
                        QList<int> runMap;
                        QString shown = expandTextMapped( record, variables, runMap );
                        drawStretched( painter, color, shown, runMap );
                        painter->restore();
                        return;
                }

                painter->save();

                painter->setClipRect( QRectF( 0, 0, mW.pt(), mH.pt() ) );

                QFont font;
                font.setFamily( mFontFamily );
                double shownSize = mTextAutoShrink ? autoShrinkFontSize( record, variables ) : mFontSize;
                font.setPixelSize( pixelSize( shownSize ) );
                if ( PrintOptions::noAntialias() )
                {
                        font.setStyleStrategy( QFont::NoAntialias );
                }
                font.setWeight( mFontWeight );
                font.setItalic( mFontItalicFlag );
                font.setUnderline( mFontUnderlineFlag );

                QTextOption textOption;
                textOption.setAlignment( mTextHAlign );
                textOption.setWrapMode( mTextWrapMode );

                QFontMetricsF fontMetrics( font );
                double dy = fontMetrics.lineSpacing() * mTextLineSpacing;

                QList<int> runMap;
                QTextDocument document( expandTextMapped( record, variables, runMap ) );

                QList<QTextLayout*> layouts;

                // Pass #1 -- do initial layouts
                double x = 0;
                double y = 0;
                QRectF boundingRect;
                for ( int i = 0; i < document.blockCount(); i++ )
                {
                        QTextLayout* layout = new QTextLayout( document.findBlockByNumber(i).text() );

                        layout->setFont( font );
                        layout->setTextOption( textOption );
                        layout->setCacheEnabled(true);
                        applyRunFormats( layout, document.findBlockByNumber(i), runMap, mFontSize > 0 ? shownSize / mFontSize : 1.0 );

                        layout->beginLayout();
                        for ( QTextLine l = layout->createLine(); l.isValid(); l = layout->createLine() )
                        {
                                l.setLineWidth( mW.pt() - 2*marginPts );
                                l.setPosition( QPointF( x, y ) );
                                y += lineAdvance( l, dy );
                        }
                        layout->endLayout();

                        layouts.append( layout );

                        boundingRect = layout->boundingRect().united( boundingRect );
                }
                double h = boundingRect.height();


                // Pass #2 -- adjust layout positions for vertical alignment
                x = marginPts;
                switch ( mTextVAlign )
                {
                case Qt::AlignVCenter:
                        y = mH.pt()/2 - h/2;
                        break;
                case Qt::AlignBottom:
                        y = mH.pt() - h - marginPts;
                        break;
                default:
                        y = marginPts;
                        break;
                }
                for ( QTextLayout* layout : layouts )
                {
                        for ( int j = 0; j < layout->lineCount(); j++ )
                        {
                                QTextLine l = layout->lineAt(j);
                                l.setPosition( QPointF( x, y ) );
                                y += lineAdvance( l, dy );
                        }
                }

                // Draw layouts
                painter->setPen( QPen( color ) );
                for ( QTextLayout* layout : layouts )
                {
                        layout->draw( painter, QPointF( 0, 0 ) );
                }

                // Cleanup
                qDeleteAll( layouts );

                painter->restore();
        }


        ///
        /// Draw text stretched (non-uniformly scaled) to fill the box of the object
        ///
        void
        ModelTextObject::drawStretched( QPainter*         painter,
                                        const QColor&     color,
                                        const QString&    text,
                                        const QList<int>& rawIndex ) const
        {
                // The glyphs are measured at a fixed large size (the nominal size does not matter) and
                // scaled so their visible outline fills the box, like a stretched picture of the text.
                QFont font;
                font.setFamily( mFontFamily );
                font.setPixelSize( 100 );
                font.setWeight( mFontWeight );
                font.setItalic( mFontItalicFlag );

                QFontMetricsF fontMetrics( font );
                double dy = fontMetrics.lineSpacing() * mTextLineSpacing;

                QTextDocument document( text );

                QPainterPath path;
                for ( int i = 0; i < document.blockCount(); i++ )
                {
                        QTextBlock block = document.findBlockByNumber(i);
                        const QString line = block.text();
                        double baseline = fontMetrics.ascent() + i*dy;

                        if ( mTextRuns.isEmpty() || rawIndex.isEmpty() )
                        {
                                path.addText( 0, baseline, font, line );
                                continue;
                        }

                        // Mixed formats: draw each stretch of the line with its own font, one after the other
                        double x = 0;
                        int k = 0;
                        while ( k < line.length() )
                        {
                                auto styleOf = [&]( int idx )
                                {
                                        int pos = block.position() + idx;
                                        return TextRun::styleAt( mTextRuns, pos < rawIndex.size() ? rawIndex[pos] : -1 );
                                };
                                TextRun style = styleOf( k );
                                int m = k + 1;
                                while ( m < line.length() && styleOf( m ).sameStyle( style ) ) m++;

                                QFont f = font;
                                if ( style.bold >= 0 )      f.setWeight( style.bold ? QFont::Bold : QFont::Normal );
                                if ( style.italic >= 0 )    f.setItalic( style.italic );
                                if ( !style.family.isEmpty() ) f.setFamily( style.family );
                                if ( style.size > 0 && mFontSize > 0 ) f.setPixelSize( qMax( 1, int( 100 * style.size / mFontSize ) ) );

                                QString piece = line.mid( k, m - k );
                                path.addText( x, baseline, f, piece );
                                x += QFontMetricsF( f ).horizontalAdvance( piece );
                                k = m;
                        }
                }

                QRectF rect = path.boundingRect();

                double availW = mW.pt() - 2*stretchMarginPts;
                double availH = mH.pt() - 2*stretchMarginPts;

                if ( rect.width() > 0 && rect.height() > 0 && availW > 0 && availH > 0 )
                {
                        painter->translate( stretchMarginPts, stretchMarginPts );
                        painter->scale( availW / rect.width(), availH / rect.height() );
                        painter->translate( -rect.topLeft() );
                        painter->fillPath( path, QBrush( color ) );
                }
        }


        ///
        /// Determine auto shrink font size
        ///
        double
        ModelTextObject::autoShrinkFontSize( const merge::Record& record,
                                             const Variables&     variables ) const
        {
                QFont font;
                font.setFamily( mFontFamily );
                font.setWeight( mFontWeight );
                font.setItalic( mFontItalicFlag );
                font.setUnderline( mFontUnderlineFlag );

                QTextOption textOption;
                textOption.setAlignment( mTextHAlign );
                textOption.setWrapMode( mTextWrapMode );

                QList<int> runMap;
                QTextDocument document( expandTextMapped( record, variables, runMap ) );

                double candidateSize = mFontSize;
                while ( candidateSize > 1.0 )
                {
                        font.setPixelSize( pixelSize( candidateSize ) );

                        // Line spacing is affected by font size
                        QFontMetricsF fontMetrics( font );
                        double dy = fontMetrics.lineSpacing() * mTextLineSpacing;

                        // Do candidate layouts, letting text flow according to wrap mode
                        double x = 0;
                        double y = 0;
                        QRectF layoutsRect;
                        for ( int i = 0; i < document.blockCount(); i++ )
                        {
                                QTextLayout layout( document.findBlockByNumber(i).text() );

                                layout.setFont( font );
                                layout.setTextOption( textOption );
                                layout.setCacheEnabled(true);
                                applyRunFormats( &layout, document.findBlockByNumber(i), runMap, mFontSize > 0 ? candidateSize / mFontSize : 1.0 );

                                layout.beginLayout();
                                for ( QTextLine l = layout.createLine(); l.isValid(); l = layout.createLine() )
                                {
                                        l.setLineWidth( mW.pt() - 2*marginPts );
                                        l.setPosition( QPointF( x, y ) );
                                        y += lineAdvance( l, dy );
                                }
                                layout.endLayout();

                                layoutsRect = layout.boundingRect().united( layoutsRect );
                        }

                        // Did this candidate fit in our object's bounding box?
                        if ( ( (layoutsRect.width() + 2*marginPts) <= mW.pt() ) &&
                             ( (layoutsRect.height() + 2*marginPts) <= mH.pt() ) )
                        {
                                break;
                        }

                        // If not, let's try a slightly smaller font size
                        candidateSize -= 0.5;
                }

                return candidateSize;
        }

}
