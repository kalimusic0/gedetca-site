<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About gLabels</source>
        <translation>Acerca gLabels</translation>
    </message>
    <message>
        <source>&amp;License</source>
        <translation>&amp;Licencia</translation>
    </message>
    <message>
        <source>&amp;Website</source>
        <translation>Sitio &amp;web</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
</context>
<context>
    <name>Color name</name>
    <message>
        <source>Light Scarlet Red</source>
        <translation>Rojo brillante claro</translation>
    </message>
    <message>
        <source>Light Orange</source>
        <translation>Naranja claro</translation>
    </message>
    <message>
        <source>Light Butter</source>
        <translation>Mantequilla claro</translation>
    </message>
    <message>
        <source>Light Chameleon</source>
        <translation>Camaleón claro</translation>
    </message>
    <message>
        <source>Light Sky Blue</source>
        <translation>Azul cielo claro</translation>
    </message>
    <message>
        <source>Light Plum</source>
        <translation>Ciruela claro</translation>
    </message>
    <message>
        <source>Light Chocolate</source>
        <translation>Chocolate claro</translation>
    </message>
    <message>
        <source>Light Aluminum 1</source>
        <translation type="unfinished">Aluminio claro 1</translation>
    </message>
    <message>
        <source>Light Aluminum 2</source>
        <translation>Aluminio claro 2</translation>
    </message>
    <message>
        <source>Scarlet Red</source>
        <translation>Rojo brillante</translation>
    </message>
    <message>
        <source>Orange</source>
        <translation>Naranja</translation>
    </message>
    <message>
        <source>Butter</source>
        <translation>Mantequilla</translation>
    </message>
    <message>
        <source>Chameleon</source>
        <translation>Camaleón</translation>
    </message>
    <message>
        <source>Sky Blue</source>
        <translation>Azul cielo</translation>
    </message>
    <message>
        <source>Plum</source>
        <translation>Ciruela</translation>
    </message>
    <message>
        <source>Chocolate</source>
        <translation>Chocolate</translation>
    </message>
    <message>
        <source>Aluminum 1</source>
        <translation>Aluminio 1</translation>
    </message>
    <message>
        <source>Aluminum 2</source>
        <translation>Aluminio 2</translation>
    </message>
    <message>
        <source>Dark Scarlet Red</source>
        <translation>Rojo brillante oscuro</translation>
    </message>
    <message>
        <source>Dark Orange</source>
        <translation>Naranja oscuro</translation>
    </message>
    <message>
        <source>Dark Butter</source>
        <translation>Mantequilla oscuro</translation>
    </message>
    <message>
        <source>Dark Chameleon</source>
        <translation>Camaleón claro</translation>
    </message>
    <message>
        <source>Dark Sky Blue</source>
        <translation>Azul cielo oscuro</translation>
    </message>
    <message>
        <source>Dark Plum</source>
        <translation>Ciruela oscuro</translation>
    </message>
    <message>
        <source>Dark Chocolate</source>
        <translation>Chocolate oscuro</translation>
    </message>
    <message>
        <source>Dark Aluminum 1</source>
        <translation>Aluminio oscuro 1</translation>
    </message>
    <message>
        <source>Dark Aluminum 2</source>
        <translation>Aluminio oscuro 2</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Negro</translation>
    </message>
    <message>
        <source>Very Dark Gray</source>
        <translation>Gris muy oscuro</translation>
    </message>
    <message>
        <source>Darker Gray</source>
        <translation>Gris mas oscuro</translation>
    </message>
    <message>
        <source>Dark Gray</source>
        <translation>Gris oscuro</translation>
    </message>
    <message>
        <source>Medium Gray</source>
        <translation>Gris medio</translation>
    </message>
    <message>
        <source>Light Gray</source>
        <translation>Gris claro</translation>
    </message>
    <message>
        <source>Lighter Gray</source>
        <translation>Gris mas claro</translation>
    </message>
    <message>
        <source>Very Light Gray</source>
        <translation>Gris muy claro</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Blanco</translation>
    </message>
</context>
<context>
    <name>EditVariableDialog</name>
    <message>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <source>Step size:</source>
        <translation>Tamaño paso:</translation>
    </message>
    <message>
        <source>Increment</source>
        <translation>Incremento</translation>
    </message>
    <message>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>Value:</source>
        <translation>Valor:</translation>
    </message>
</context>
<context>
    <name>Factory</name>
    <message>
        <source>Excel workbook (.xlsx), field names in row 1</source>
        <translation>Excel (.xlsx), nombres de campo en la fila 1</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV)</source>
        <translation>Texto: Valores separados por comas (CSV)</translation>
    </message>
    <message>
        <source>Text: Comma Separated Values (CSV), keys on line 1</source>
        <translation>Texto: Valores separados por comas (CSV), claves en 1 linea</translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV)</source>
        <translation>Texto: Valores separados por tabulador (TSV)</translation>
    </message>
    <message>
        <source>Text: Tab Separated Values (TSV), keys on line 1</source>
        <translation>Texto: Valores separados por tabulador (TSV), claves en 1 linea</translation>
    </message>
    <message>
        <source>Text: Colon Separated Values</source>
        <translation>Texto: Valores separados por 2 puntos</translation>
    </message>
    <message>
        <source>Text: Colon Separated Values, keys on line 1</source>
        <translation>Texto: Valores separados por 2 puntos, claves en 1 linea</translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values</source>
        <translation>Texto: Valores separados por punto y coma</translation>
    </message>
    <message>
        <source>Text: Semicolon Separated Values, keys on line 1</source>
        <translation>Texto: Valores separados por punto y coma, claves en 1 linea</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <source>%1 x %2 (%3 per sheet)</source>
        <extracomment>%1 = number of labels across a page, %2 = number of labels down a page, %3 = total number of labels on a page (sheet).</extracomment>
        <translation>%1 x %2 (%3 por hoja)</translation>
    </message>
    <message>
        <source>%1 per sheet</source>
        <extracomment>%1 is the total number of labels on a page (sheet).</extracomment>
        <translation>%1 por hoja</translation>
    </message>
</context>
<context>
    <name>FrameCd</name>
    <message>
        <source>diameter</source>
        <translation>diametro</translation>
    </message>
</context>
<context>
    <name>FrameContinuous</name>
    <message>
        <source>wide</source>
        <translation>ancho</translation>
    </message>
</context>
<context>
    <name>FrameRound</name>
    <message>
        <source>diameter</source>
        <translation>diámetro</translation>
    </message>
</context>
<context>
    <name>MergeView</name>
    <message>
        <source>Source</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <source>Records</source>
        <translation type="unfinished">Registros</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Unselect all</source>
        <translation>Deseleccionar todo</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>Examinar…</translation>
    </message>
</context>
<context>
    <name>ObjectEditor</name>
    <message>
        <source>Object properties</source>
        <translation>Propiedades del objeto</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>distribución</translation>
    </message>
    <message>
        <source>Alignment:</source>
        <translation>Alineación:</translation>
    </message>
    <message>
        <source>Line spacing:</source>
        <translation>Espacio de linea:</translation>
    </message>
    <message>
        <source>Wrap mode:</source>
        <translation>Ajuste de texto:</translation>
    </message>
    <message>
        <source>Word</source>
        <translation>Palabra</translation>
    </message>
    <message>
        <source>Anywhere</source>
        <translation>Cualquier sitio</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Allow printing to shrink text to fit object</source>
        <translation>Permitir impresión que encoja texto para entrar en objeto</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>Family:</source>
        <translation>Familia:</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <source>Style:</source>
        <translation>Estilo:</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Color:</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Código de barras</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>Show text</source>
        <translation>Mostrar texto</translation>
    </message>
    <message>
        <source>Checksum</source>
        <translation>Verificación</translation>
    </message>
    <message>
        <source>Barcode data</source>
        <translation>Datos del código de barras</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>Examinar…</translation>
    </message>
    <message>
        <source>Line/Fill</source>
        <translation>Linea/Relleno</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linea</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Relleno</translation>
    </message>
    <message>
        <source>Position/Size</source>
        <translation>Posición/Tamaño</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Longitud:</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Ángulo:</translation>
    </message>
    <message>
        <source>Original size:</source>
        <translation>Tamaño original:</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <source>Lock aspect ratio</source>
        <translation>Bloquear proporción</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation>Sombra</translation>
    </message>
    <message>
        <source>X offset:</source>
        <translation>Desplazamiento X:</translation>
    </message>
    <message>
        <source>Y offset:</source>
        <translation>Desplazamiento Y:</translation>
    </message>
    <message>
        <source>Opacity:</source>
        <translation>Opacidad:</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>gLabels - Preferences</source>
        <translation>gLabels - Preferencias</translation>
    </message>
    <message>
        <source>Locale</source>
        <translation>Configuración regional</translation>
    </message>
    <message>
        <source>Select locale specific behavior.</source>
        <translation>Seleccione las propiedades del documento.</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Puntos</translation>
    </message>
    <message>
        <source>Centimeters</source>
        <translation>Centimetros</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Milimetros</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Pulgadas</translation>
    </message>
    <message>
        <source>Picas</source>
        <translation>Picas</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <source>Configure grid behavior.</source>
        <translation>Configurar el comportamiento de la cuadrícula.</translation>
    </message>
    <message>
        <source>Origin</source>
        <translation>Origen</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <source>Spacing</source>
        <translation>Espaciado</translation>
    </message>
    <message>
        <source>Top left corner</source>
        <translation>Esquina superior izquierda</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
</context>
<context>
    <name>PrintView</name>
    <message>
        <source>Copies:</source>
        <translation>Copias:</translation>
    </message>
    <message>
        <source>print outlines</source>
        <translation>Imprimir bordes</translation>
    </message>
    <message>
        <source>print crop marks</source>
        <translation>imprimir marcas de corte</translation>
    </message>
    <message>
        <source>print in reverse (i.e. a mirror image)</source>
        <translation>impresión invertida (imagen espejo)</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>of</source>
        <translation>de</translation>
    </message>
    <message>
        <source>nn</source>
        <translation>nn</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Imprimir rango</translation>
    </message>
    <message>
        <source>Positions</source>
        <translation>Posiciones</translation>
    </message>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Merge control</source>
        <translation>Control de combinación</translation>
    </message>
    <message>
        <source>Uncollated (e.g.  1,1,1   2,2,2   3,3,3)</source>
        <translation>Sin intercalar (p. ej.  1,1,1   2,2,2   3,3,3)</translation>
    </message>
    <message>
        <source>Collated   (e.g.  1,2,3   1,2,3   1,2,3)</source>
        <translation>Intercalado (p. ej.  1,2,3   1,2,3   1,2,3)</translation>
    </message>
    <message>
        <source>Merge groups are contiguous</source>
        <translation>Los grupos de combinación son contiguos</translation>
    </message>
    <message>
        <source>Merge groups start on a new page</source>
        <translation>Los grupos de combinación empiezan en una página nueva</translation>
    </message>
    <message>
        <source>Start groups at position:</source>
        <translation>Iniciar grupos en la posición:</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation>Destino</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Use system print dialog...</source>
        <translation>Usar el diálogo de impresión del sistema…</translation>
    </message>
</context>
<context>
    <name>PropertiesView</name>
    <message>
        <source>Product</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation>Fabricante:</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>Número de parte:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripción:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Tamaño de la página:</translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation>Tamaño de etiqueta:</translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation>Disposición:</translation>
    </message>
    <message>
        <source>Change product</source>
        <translation>Cambiar producto</translation>
    </message>
    <message>
        <source>Adjustable Parameters</source>
        <translation>Parámetros ajustables</translation>
    </message>
    <message>
        <source>Label length:</source>
        <translation>Longitud de etiqueta:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <source>Select horizontal or vertical orientation.</source>
        <translation>Seleccione orientación horizontal o vertical.</translation>
    </message>
    <message>
        <source>Horizontal orientation</source>
        <translation>Orientación horizontal</translation>
    </message>
    <message>
        <source>Vertical orientation</source>
        <translation>Orientación vertical</translation>
    </message>
    <message>
        <source>Similar Products</source>
        <translation>Productos similares</translation>
    </message>
    <message>
        <source>Select another product for this gLabels project.</source>
        <translation>Seleccionar otro producto para este proyecto de Gedetca Labels.</translation>
    </message>
</context>
<context>
    <name>ReportBugDialog</name>
    <message>
        <source>gLabels - Report a Bug</source>
        <translation>gLabels - Informar error</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>&amp;Launch Issue Tracker</source>
        <translation>&amp;Ir a seguimiento de fallos</translation>
    </message>
</context>
<context>
    <name>SelectProductDialog</name>
    <message>
        <source>gLabels - Select Product</source>
        <translation>gLabels - Seleccionar producto</translation>
    </message>
    <message>
        <source>Search all</source>
        <translation>Buscar todo</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Filter by paper size</source>
        <translation>Filtrar por tamaño de papel</translation>
    </message>
    <message>
        <source>ISO sizes</source>
        <translation>Tamaños ISO</translation>
    </message>
    <message>
        <source>US sizes</source>
        <translation>Tamaños US</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Otros</translation>
    </message>
    <message>
        <source>Filter by category</source>
        <translation>Filtrar por categoría</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Seleccionado</translation>
    </message>
    <message>
        <source>Search entire product database.</source>
        <translation>Buscar base de datos de producto completa</translation>
    </message>
    <message>
        <source>Recent</source>
        <translation>Reciente</translation>
    </message>
    <message>
        <source>Select from recently used products.</source>
        <translation>Seleccionar por productos usados recientemente</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Product information</source>
        <translation>Información del producto</translation>
    </message>
    <message>
        <source>Vendor:</source>
        <translation>Fabricante:</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>Etiqueta de texto</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>N.º de parte:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripción:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Tamaño de página:</translation>
    </message>
    <message>
        <source>Label size:</source>
        <translation>Tamaño de etiqueta:</translation>
    </message>
    <message>
        <source>Layout:</source>
        <translation>Disposición:</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
</context>
<context>
    <name>StartupView</name>
    <message>
        <source>Welcome to gLabels.  Let&apos;s get started:</source>
        <translation>Bienvenido a gLabels. Empezemos</translation>
    </message>
    <message>
        <source>Create a new blank gLabels project</source>
        <translation>Crear un nuevo proyecto gLabels</translation>
    </message>
    <message>
        <source>Open a recent gLabels project</source>
        <translation>Abrir un proyecto gLabels reciente</translation>
    </message>
    <message>
        <source>Recent</source>
        <translation>Reciente</translation>
    </message>
    <message>
        <source>New...</source>
        <translation>Nuevo...</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>Examinar…</translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation>Abrir un proyecto existente de Gedetca Labels</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerApplyPage</name>
    <message>
        <source>You have completed the gLabels Product Template Designer.  If you wish to accept and save your product template, click &quot;Save.&quot;</source>
        <translation>Ha completado el Diseñador de plantillas de producto de Gedetca Labels.  Si desea aceptar y guardar su plantilla de producto, pulse «Guardar».</translation>
    </message>
    <message>
        <source>Otherwise, you may click &quot;Cancel&quot; to abandon your design or &quot;Back&quot; to review or continue editing this product template.</source>
        <translation>En caso contrario, pulse «Cancelar» para abandonar su diseño o «Atrás» para revisar o seguir editando esta plantilla de producto.</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerCdPage</name>
    <message>
        <source>6. Margin:</source>
        <translation>6. Margen:</translation>
    </message>
    <message>
        <source>1. Outer radius:</source>
        <translation>1. Radio externo:</translation>
    </message>
    <message>
        <source>4. Clipping height:</source>
        <translation>4. Alto de recorte:</translation>
    </message>
    <message>
        <source>2. Inner radius:</source>
        <translation>2. Radio interno:</translation>
    </message>
    <message>
        <source>3. Clipping width:</source>
        <translation>3. Ancho de recorte:</translation>
    </message>
    <message>
        <source>5. Waste:</source>
        <translation>5. Margen sobrante:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerContinuousPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation>Pulse «Cancelar» para salir, o «Atrás» para empezar con un producto distinto.</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerEllipsePage</name>
    <message>
        <source>2. Height:</source>
        <translation>2. Alto:</translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation>1. Ancho:</translation>
    </message>
    <message>
        <source>3. Waste:</source>
        <translation>3. Margen sobrante:</translation>
    </message>
    <message>
        <source>4. Margin:</source>
        <translation>4. Margen:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerIntroPage</name>
    <message>
        <source>Copy/Edit Product</source>
        <translation>Copia/editar producto</translation>
    </message>
    <message>
        <source>Copy and edit an existing product template</source>
        <translation>Copia y edita una plantilla existente de producto</translation>
    </message>
    <message>
        <source>New Product</source>
        <translation>Nuevo producto</translation>
    </message>
    <message>
        <source>Create a new product template from scratch</source>
        <translation>Crear un nuevo producto desde cero</translation>
    </message>
    <message>
        <source>This dialog will help you create a custom product template. Let&apos;s get started:</source>
        <translation>Este diálogo le ayudará a crear una plantilla de producto personalizada. Comencemos:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNLayoutsPage</name>
    <message>
        <source>A layout is a set of labels or cards that can be arranged in a simple grid.  Most products only need one layout, as in the first example below.  The second example illustrates when two layouts are needed.</source>
        <translation>Una disposición es un conjunto de etiquetas o tarjetas que pueden organizarse en una cuadrícula simple.  La mayoría de los productos solo necesita una disposición, como en el primer ejemplo.  El segundo ejemplo ilustra cuándo se necesitan dos.</translation>
    </message>
    <message>
        <source>Products needing only one layout.</source>
        <translation>Productos que necesitan solo una disposición.</translation>
    </message>
    <message>
        <source>Products needing two layouts.</source>
        <translation>Productos que necesitan dos disposiciones.</translation>
    </message>
    <message>
        <source>Note: if more than two layouts are required, the product template must be edited manually.</source>
        <translation>Nota: si se requieren más de dos disposiciones, la plantilla de producto debe editarse manualmente.</translation>
    </message>
    <message>
        <source>One layout</source>
        <translation>Una disposición</translation>
    </message>
    <message>
        <source>Two layouts</source>
        <translation>Dos disposiciones</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerNamePage</name>
    <message>
        <source>(e.g. &quot;Mailing Labels,&quot; &quot;Business Cards,&quot; ...)</source>
        <translation>(&quot;Etiquetas correos&quot;,&quot;Tarjetas de visita&quot;,...)</translation>
    </message>
    <message>
        <source>Brand:</source>
        <translation>Marca:</translation>
    </message>
    <message>
        <source>Part #:</source>
        <translation>Número de parte:</translation>
    </message>
    <message>
        <source>Description:</source>
        <translation>Descripción:</translation>
    </message>
    <message>
        <source>(e.g. 8163A)</source>
        <translation>(ej. 8163A)</translation>
    </message>
    <message>
        <source>(e.g. Avery, Acme, ...)</source>
        <translation>(ej. Avery,Acme, ...)</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Number across (nx):</source>
        <translation>Cantidad horizontal (nx)</translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation>Cantidad vertical (ny):</translation>
    </message>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation>Distancia desde el borde izquierdo (x0):</translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation>Distancia desde el borde superior (y0):</translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation>Desplazamiento horizontal (dx):</translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation>Desplazamiento vertical (dy):</translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation>Imprimir página de prueba</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPageSizePage</name>
    <message>
        <source>Roll width:</source>
        <translation>Ancho del rollo:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Tamaño de pagina:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerPathPage</name>
    <message>
        <source>Click &quot;Cancel&quot; to quit, or click &quot;Back&quot; to begin with a different product.</source>
        <translation>Pulse «Cancelar» para salir, o «Atrás» para empezar con un producto distinto.</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRectPage</name>
    <message>
        <source>4. Horizontal waste:</source>
        <translation>4. Margen sobrante horizontal:</translation>
    </message>
    <message>
        <source>3. Corner radius</source>
        <translation>3. Radio de esquina</translation>
    </message>
    <message>
        <source>1. Width:</source>
        <translation>1. Ancho:</translation>
    </message>
    <message>
        <source>5. Vertical waste:</source>
        <translation>5. Margen sobrante vertical:</translation>
    </message>
    <message>
        <source>2. Height:</source>
        <translation>2. Alto:</translation>
    </message>
    <message>
        <source>6. Margin (X):</source>
        <translation>6. Margen (X):</translation>
    </message>
    <message>
        <source>7. Margin (Y):</source>
        <translation>7. Margen (Y):</translation>
    </message>
    <message>
        <source>in</source>
        <translation>pulg</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerRoundPage</name>
    <message>
        <source>3. Margin</source>
        <translation>3. Margen</translation>
    </message>
    <message>
        <source>1. Radius:</source>
        <translation>1. Radio:</translation>
    </message>
    <message>
        <source>2. Waste:</source>
        <translation>2. Margen sobrante:</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerShapePage</name>
    <message>
        <source>Rectangular or square (can have rounded corners)</source>
        <translation>Rectangular o cuadrada (puede tener bordes redondeados)</translation>
    </message>
    <message>
        <source>Round</source>
        <translation>Redonda</translation>
    </message>
    <message>
        <source>Elliptical</source>
        <translation>Elíptica</translation>
    </message>
    <message>
        <source>CD/DVD (including credit card CDs)</source>
        <translation>CD/DVD (incluyendo CD-tarjeta)</translation>
    </message>
</context>
<context>
    <name>TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Distance from left edge (x0):</source>
        <translation>Distancia desde el borde izquierdo (x0)</translation>
    </message>
    <message>
        <source>Number down (ny):</source>
        <translation>Cantidad vertical (ny):</translation>
    </message>
    <message>
        <source>Distance from top edge (y0):</source>
        <translation>Distancia desde el borde superior (y0):</translation>
    </message>
    <message>
        <source>Number across (nx):</source>
        <translation>Cantidad horizontal (nx):</translation>
    </message>
    <message>
        <source>Horizontal pitch (dx):</source>
        <translation>Desplazamiento horizontal (dx):</translation>
    </message>
    <message>
        <source>Vertical pitch (dy):</source>
        <translation>Desplazamiento vertical (dy):</translation>
    </message>
    <message>
        <source>Print test sheet</source>
        <translation>Imprimir página de prueba</translation>
    </message>
</context>
<context>
    <name>Units</name>
    <message>
        <source>points</source>
        <translation>puntos</translation>
    </message>
    <message>
        <source>inches</source>
        <translation>pulgadas</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>cm</source>
        <translation>cm</translation>
    </message>
    <message>
        <source>picas</source>
        <translation>picas</translation>
    </message>
</context>
<context>
    <name>Variable</name>
    <message>
        <source>String</source>
        <translation>Cadena de texto</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Entero</translation>
    </message>
    <message>
        <source>Floating Point</source>
        <translation>Decimal</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <source>Per item</source>
        <translation>Por elemento</translation>
    </message>
    <message>
        <source>Per copy</source>
        <translation>Por copia</translation>
    </message>
    <message>
        <source>Per page</source>
        <translation>Por página</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
</context>
<context>
    <name>VariablesView</name>
    <message>
        <source>Add</source>
        <translation>Añadir</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Add variable</source>
        <translation>Agregar variable</translation>
    </message>
    <message>
        <source>Edit selected variable</source>
        <translation>Editar la variable seleccionada</translation>
    </message>
    <message>
        <source>Delete selected variable</source>
        <translation>Eliminar la variable seleccionada</translation>
    </message>
</context>
<context>
    <name>glabels::AboutDialog</name>
    <message>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <source>A program to create labels and business cards.</source>
        <translation>Programa para crear etiquetas y tarjetas de visita</translation>
    </message>
    <message>
        <source>gLabels is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished">gLabels es software libre. Puede redistribuirlo y/o modificarlo bajo los términos de la Licencia Pública General de GNU según es publicada por la Free Software Foundation, bien de la versión 3 de dicha Licencia o bien (según su elección) de cualquier versión posterior.</translation>
    </message>
    <message>
        <source>gLabels is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.</source>
        <translation type="unfinished">gLabels se distribuye con la esperanza de que sea útil, pero SIN NINGUNA GARANTÍA, incluso sin la garantía MERCANTIL implícita o sin garantizar la CONVENIENCIA PARA UN PROPÓSITO PARTICULAR. Véase la Licencia Pública General de GNU para más detalles.</translation>
    </message>
</context>
<context>
    <name>glabels::ColorHistory</name>
    <message>
        <source>color %1</source>
        <translation>color %1</translation>
    </message>
</context>
<context>
    <name>glabels::ColorPaletteDialog</name>
    <message>
        <source>Standard Colors</source>
        <translation>Colores estándar</translation>
    </message>
    <message>
        <source>Recent Colors</source>
        <translation>Colores recientes</translation>
    </message>
    <message>
        <source>Custom color...</source>
        <translation>Color personalizado...</translation>
    </message>
    <message>
        <source>Custom Color</source>
        <translation>Color personalizado</translation>
    </message>
    <message>
        <source>Custom Color %1</source>
        <extracomment>%1 = color specification in hex. String must not contain a colon (:).</extracomment>
        <translation>Color personalizado %1</translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation>Usar campo de sustitución</translation>
    </message>
</context>
<context>
    <name>glabels::EditVariableDialog</name>
    <message>
        <source>Default</source>
        <translation>Defecto</translation>
    </message>
</context>
<context>
    <name>glabels::FieldButton</name>
    <message>
        <source>Merge fields</source>
        <translation>Campos de combinación</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
</context>
<context>
    <name>glabels::File</name>
    <message>
        <source>gLabels - Open Project</source>
        <translation>gLabels - Abrir projecto</translation>
    </message>
    <message>
        <source>glabels files (*.glabels);;All files (*)</source>
        <translation>Ficheros glabels (*.glabels);;Todos archivos (*)</translation>
    </message>
    <message>
        <source>Unable to open &quot;</source>
        <translation>No es posible abrir &quot;</translation>
    </message>
    <message>
        <source>&quot;.</source>
        <translation>&quot;.</translation>
    </message>
    <message>
        <source>gLabels - Save Project As</source>
        <translation>gLabels - Guardar proyecto como</translation>
    </message>
    <message>
        <source>Save Label As</source>
        <translation>Guardar etiqueta como</translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation>%1 ya existe.</translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation>¿Deseas reemplazarlo?</translation>
    </message>
</context>
<context>
    <name>glabels::LabelEditor</name>
    <message>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Resize</source>
        <translation>Cambiar tamaño</translation>
    </message>
    <message>
        <source>Drop</source>
        <translation>Soltar</translation>
    </message>
</context>
<context>
    <name>glabels::MainWindow</name>
        <message>
            <source>Crop image...</source>
            <translation>Recortar imagen...</translation>
        </message>
        <message>
            <source>Crop the selected image dragging a rectangle over it</source>
            <translation>Recorta la imagen seleccionada arrastrando un rectángulo sobre ella</translation>
        </message>
    <message>
        <source>&amp;Quick template...</source>
        <translation>Plantilla &amp;rápida...</translation>
    </message>
    <message>
        <source>Create a custom template in one window</source>
        <translation>Crea una plantilla propia en una sola ventana</translation>
    </message>
    <message>
        <source>Product Template &amp;Designer (advanced)...</source>
        <translation>&amp;Diseñador de plantillas (avanzado)...</translation>
    </message>
    <message>
        <source>Space Evenly, Horizontal</source>
        <translation>Espaciar uniformemente, Horizontal</translation>
    </message>
    <message>
        <source>Space Evenly, Vertical</source>
        <translation>Espaciar uniformemente, Vertical</translation>
    </message>
    <message>
        <source>Space the selected objects evenly in horizontal</source>
        <translation>Espacia uniformemente los objetos seleccionados en horizontal</translation>
    </message>
    <message>
        <source>Space the selected objects evenly in vertical</source>
        <translation>Espacia uniformemente los objetos seleccionados en vertical</translation>
    </message>
    <message>
        <source>Objects (select to edit)</source>
        <translation>Objetos (seleccione para editar)</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Bienvenido</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Combinar</translation>
    </message>
    <message>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>&amp;New...</source>
        <translation>&amp;Nuevo...</translation>
    </message>
    <message>
        <source>Create a new gLabels project</source>
        <translation>Crear nuevo proyecto gLabels</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation>&amp;Abrir...</translation>
    </message>
    <message>
        <source>Open an existing gLabels project</source>
        <translation>Abre un proyecto gLabels existente</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Save current gLabels project</source>
        <translation>Guardar el proyecto actual de Gedetca Labels</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation>Gu&amp;ardar como...</translation>
    </message>
    <message>
        <source>Save current gLabels project to a different name</source>
        <translation>Guardar el proyecto actual de Gedetca Labels con otro nombre</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>Select project Edit mode</source>
        <translation>Seleccionar el modo Edición del proyecto</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>P&amp;ropiedades</translation>
    </message>
    <message>
        <source>Select project Properties mode</source>
        <translation>Seleccionar el modo Propiedades del proyecto</translation>
    </message>
    <message>
        <source>&amp;Merge</source>
        <translation>Co&amp;mbinar</translation>
    </message>
    <message>
        <source>Select project Merge mode</source>
        <translation>Seleccionar el modo Combinación del proyecto</translation>
    </message>
    <message>
        <source>&amp;Variables</source>
        <translation>&amp;Variables</translation>
    </message>
    <message>
        <source>Select project Variables mode</source>
        <translation>Seleccionar el modo Variables del proyecto</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>Im&amp;primir</translation>
    </message>
    <message>
        <source>Select project Print mode</source>
        <translation>Seleccionar el modo Impresión del proyecto</translation>
    </message>
    <message>
        <source>Product Template &amp;Designer...</source>
        <translation>&amp;Diseñador de plantillas de producto…</translation>
    </message>
    <message>
        <source>Create custom templates</source>
        <translation>Crear plantillas personalizadas</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>Close the current window</source>
        <translation>Cerrar la ventana actual</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <source>Exit glabels</source>
        <translation>Salir glabels</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Cut the selection</source>
        <translation>Cortar la selección</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>Copy the selection</source>
        <translation>Copiar la selección</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Paste the clipboard</source>
        <translation>Pegar desde portapapeles</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <source>Delete the selected objects</source>
        <translation>Borrar los objetos seleccionados</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation>&amp;Seleccionar todo</translation>
    </message>
    <message>
        <source>Select all objects</source>
        <translation>Seleccionar todos los objetos</translation>
    </message>
    <message>
        <source>Un-select All</source>
        <translation>Deseleccionar todo</translation>
    </message>
    <message>
        <source>Remove all selections</source>
        <translation>Eliminar todas las selecciones</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <source>Configure the application</source>
        <translation>Configurar la aplicación</translation>
    </message>
    <message>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Cuadrícula</translation>
    </message>
    <message>
        <source>Change visibility of the grid in current window</source>
        <translation>Cambiar la visibilidad de la cuadrícula en la ventana actual</translation>
    </message>
    <message>
        <source>Markup</source>
        <translation>Guías</translation>
    </message>
    <message>
        <source>Change visibility of markup lines in current window</source>
        <translation>Cambiar la visibilidad de las líneas guía en la ventana actual</translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation>Ampliar</translation>
    </message>
    <message>
        <source>Increase magnification</source>
        <translation>Aumentar escala</translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Decrease magnification</source>
        <translation>Reducir escala</translation>
    </message>
    <message>
        <source>Zoom &amp;1 to 1</source>
        <translation>Ampliar tamaño 1 a 1</translation>
    </message>
    <message>
        <source>Restore scale to 100%</source>
        <translation>Restablecer escala al 100%</translation>
    </message>
    <message>
        <source>Zoom to &amp;Fit</source>
        <translation>Ampliar a encajar</translation>
    </message>
    <message>
        <source>Set scale to fit window</source>
        <translation>Establecer la escala para ajustar a la ventana</translation>
    </message>
    <message>
        <source>Select Mode</source>
        <translation>Seleccionar modo</translation>
    </message>
    <message>
        <source>Select, move and modify objects</source>
        <translation>Seleccionar, mover y modificar objetos</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Create text object</source>
        <translation>Crear un cuadro de texto</translation>
    </message>
    <message>
        <source>Box</source>
        <translation>Caja</translation>
    </message>
    <message>
        <source>Create box object</source>
        <translation>Crear objeto de caja</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linea</translation>
    </message>
    <message>
        <source>Create line object</source>
        <translation>Crear una línea</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Create ellipse/circle object</source>
        <translation>Crear un círculo o elipse</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Create image object</source>
        <translation>Crear una imagen</translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Código de barras</translation>
    </message>
    <message>
        <source>Create barcode object</source>
        <translation>Crear objeto código barras</translation>
    </message>
    <message>
        <source>Bring To Front</source>
        <translation>Traer al frente</translation>
    </message>
    <message>
        <source>Raise selection to top</source>
        <translation>Traer la selección al frente</translation>
    </message>
    <message>
        <source>Send To Back</source>
        <translation>Enviar al fondo</translation>
    </message>
    <message>
        <source>Lower selection to bottom</source>
        <translation>Enviar la selección al fondo</translation>
    </message>
    <message>
        <source>Rotate Left</source>
        <translation>Girar a la izquierda</translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees counter-clockwise</source>
        <translation>Girar los objetos 90 grados en sentido antihorario</translation>
    </message>
    <message>
        <source>Rotate Right</source>
        <translation>Girar a la derecha</translation>
    </message>
    <message>
        <source>Rotate object(s) 90 degrees clockwise</source>
        <translation>Girar los objetos 90 grados en sentido horario</translation>
    </message>
    <message>
        <source>Flip Horizontally</source>
        <translation>Voltear horizontalmente</translation>
    </message>
    <message>
        <source>Flip object(s) horizontally</source>
        <translation>Voltear los objetos horizontalmente</translation>
    </message>
    <message>
        <source>Flip Vertically</source>
        <translation>Voltear verticalmente</translation>
    </message>
    <message>
        <source>Flip object(s) vertically</source>
        <translation>Voltear los objetos verticalmente</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Alinear a la izquierda</translation>
    </message>
    <message>
        <source>Align objects to left edges</source>
        <translation>Alinear objetos por su lado izquierdo</translation>
    </message>
    <message>
        <source>Align Center</source>
        <translation>Alinear al centro</translation>
    </message>
    <message>
        <source>Align objects to horizontal centers</source>
        <translation>Alinear objetos por su centro horizontal</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Alinear a la derecha</translation>
    </message>
    <message>
        <source>Align objects to right edges</source>
        <translation>Alinear objetos por su lado derecho</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>Alinear arriba</translation>
    </message>
    <message>
        <source>Align objects to top edges</source>
        <translation>Alinear objetos por su parte superior</translation>
    </message>
    <message>
        <source>Align Middle</source>
        <translation>Alinear al medio</translation>
    </message>
    <message>
        <source>Align objects to vertical centers</source>
        <translation>Alinear objetos por su centro vertical</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>Alinear abajo</translation>
    </message>
    <message>
        <source>Align objects to bottom edges</source>
        <translation>Alinear objetos por su parte inferior</translation>
    </message>
    <message>
        <source>Center Horizontally</source>
        <translation>Centrar horizontalmente</translation>
    </message>
    <message>
        <source>Horizontally center objects in label</source>
        <translation>Centrar los objetos horizontalmente en la etiqueta</translation>
    </message>
    <message>
        <source>Center Vertically</source>
        <translation>Centrar verticalmente</translation>
    </message>
    <message>
        <source>Vertically center objects in label</source>
        <translation>Centrar los objetos verticalmente en la etiqueta</translation>
    </message>
    <message>
        <source>Open gLabels manual</source>
        <translation>Abrir el manual de Gedetca Labels</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation>&amp;Acerca de...</translation>
    </message>
    <message>
        <source>About gLabels</source>
        <translation>Acerca gLabels</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;ver</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>Barras de herramientas</translation>
    </message>
    <message>
        <source>&amp;Objects</source>
        <translation>&amp;Objetos</translation>
    </message>
    <message>
        <source>&amp;Create</source>
        <translation>&amp;Crear</translation>
    </message>
    <message>
        <source>&amp;Order</source>
        <translation>&amp;Orden</translation>
    </message>
    <message>
        <source>&amp;Rotate/Flip</source>
        <translation>&amp;Rotar/Voltear</translation>
    </message>
    <message>
        <source>&amp;Alignment</source>
        <translation>&amp;Alinear</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>&amp;Editor</source>
        <translation>&amp;Editor</translation>
    </message>
    <message>
        <source>(modified)</source>
        <translation>(modificado)</translation>
    </message>
    <message>
        <source>Save changes to project &quot;%1&quot; before closing?</source>
        <translation>¿Guardar los cambios del proyecto «%1» antes de cerrar?</translation>
    </message>
    <message>
        <source>Your changes will be lost if you don&apos;t save them.</source>
        <translation>Sus cambios se perderán si no los guarda.</translation>
    </message>
    <message>
        <source>Save project?</source>
        <translation>¿Guardar proyecto?</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Create Text</source>
        <translation>Crear texto</translation>
    </message>
    <message>
        <source>Create Box</source>
        <translation>Crear rectángulo</translation>
    </message>
    <message>
        <source>Create Line</source>
        <translation>Crear línea</translation>
    </message>
    <message>
        <source>Create Ellipse</source>
        <translation>Crear elipse</translation>
    </message>
    <message>
        <source>Create Image</source>
        <translation>Crear imagen</translation>
    </message>
    <message>
        <source>Create Barcode</source>
        <translation>Crear código de barras</translation>
    </message>
    <message>
        <source>Quick Access</source>
        <translation>Acceso rápido</translation>
    </message>
    <message>
        <source>&amp;Report Bug...</source>
        <translation>&amp;Informe de error...</translation>
    </message>
    <message>
        <source>Report a bug to the developers</source>
        <translation>Informar un error a los desarrolladores</translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Quick Access&quot; toolbar in current window</source>
        <translation>Cambiar la visibilidad de la barra «Acceso rápido» en la ventana actual</translation>
    </message>
    <message>
        <source>Change visibility of the &quot;Editor&quot; toolbar in current window</source>
        <translation>Cambiar la visibilidad de la barra «Editor» en la ventana actual</translation>
    </message>
    <message>
        <source>&amp;User Manual...</source>
        <translation>&amp;Manual de usuario...</translation>
    </message>
    <message>
        <source>Open Recent</source>
        <translation>Abrir reciente</translation>
    </message>
    <message>
        <source>Quick Access Toolbar</source>
        <translation>Barra de acceso rápido</translation>
    </message>
    <message>
        <source>Undo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to undo.</extracomment>
        <translation>Deshacer %1</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <extracomment>%1 is the action name/description (e.g. move, delete, ...) to redo.</extracomment>
        <translation>Rehacer %1</translation>
    </message>
    <message>
        <source>Center Both</source>
        <translation>Centrar ambos</translation>
    </message>
    <message>
        <source>Center objects in label</source>
        <translation>Centrar los objetos en la etiqueta</translation>
    </message>
        <message>
            <source>Rotate 180</source>
            <translation>Girar 180°</translation>
        </message>
        <message>
            <source>Rotate 1 degree left</source>
            <translation>Girar 1° a la izquierda</translation>
        </message>
        <message>
            <source>Rotate 1 degree right</source>
            <translation>Girar 1° a la derecha</translation>
        </message>
        <message>
            <source>Rotate object(s) 180 degrees</source>
            <translation>Girar los objetos 180 grados</translation>
        </message>
        <message>
            <source>Rotate object(s) 1 degree counter-clockwise</source>
            <translation>Girar los objetos 1 grado en sentido antihorario</translation>
        </message>
        <message>
            <source>Rotate object(s) 1 degree clockwise</source>
            <translation>Girar los objetos 1 grado en sentido horario</translation>
        </message>
        <message>
            <source>Same width</source>
            <translation>Igualar ancho</translation>
        </message>
        <message>
            <source>Same height</source>
            <translation>Igualar alto</translation>
        </message>
        <message>
            <source>Make selected objects as wide as the first selected one</source>
            <translation>Igualar el ancho de los objetos seleccionados al primero seleccionado</translation>
        </message>
        <message>
            <source>Make selected objects as tall as the first selected one</source>
            <translation>Igualar el alto de los objetos seleccionados al primero seleccionado</translation>
        </message>
            <message>
            <source>Export image...</source>
            <translation>Exportar imagen…</translation>
        </message>
        <message>
            <source>Quick image export</source>
            <translation>Exportación rápida de imagen</translation>
        </message>
        <message>
            <source>Quick export folder...</source>
            <translation>Carpeta de exportación rápida…</translation>
        </message>
        <message>
            <source>Export the label to a PNG image</source>
            <translation>Exportar la etiqueta a una imagen PNG</translation>
        </message>
        <message>
            <source>Export the label to a PNG image in the quick export folder, without asking</source>
            <translation>Exportar la etiqueta a una imagen PNG en la carpeta de exportación rápida, sin preguntar</translation>
        </message>
        <message>
            <source>Choose the folder used by the quick image export</source>
            <translation>Elegir la carpeta que usa la exportación rápida de imagen</translation>
        </message>
        <message>
            <source>Export image</source>
            <translation>Exportar imagen</translation>
        </message>
        <message>
            <source>Nothing was exported.</source>
            <translation>No se exportó nada.</translation>
        </message>
        <message>
            <source>%1 image(s) exported. Last: %2</source>
            <translation>%1 imagen(es) exportada(s). Última: %2</translation>
        </message>
        <message>
            <source>Quick export folder</source>
            <translation>Carpeta de exportación rápida</translation>
        </message>
        <message>
            <source>Quick export folder: %1</source>
            <translation>Carpeta de exportación rápida: %1</translation>
        </message>
            <message>
            <source>Object properties</source>
            <translation>Propiedades del objeto</translation>
        </message>
        <message>
            <source>Properties...</source>
            <translation>Propiedades…</translation>
        </message>
        <message>
            <source>Open the properties window of the selected object (or double click on it)</source>
            <translation>Abrir la ventana de propiedades del objeto seleccionado (o doble clic sobre él)</translation>
        </message>
        <message>
            <source>Close</source>
            <translation>Cerrar</translation>
        </message>
        <message>
        <source>Fit label to content</source>
        <translation>Ajustar etiqueta al contenido</translation>
    </message>
    <message>
        <source>Resize the label to the box that contains all the objects</source>
        <translation>Redimensiona la etiqueta a la caja que contiene todos los objetos</translation>
    </message>
    <message>
        <source>There are no objects to fit the label to.</source>
        <translation>No hay objetos a los que ajustar la etiqueta.</translation>
    </message>
    <message>
        <source>This only works with templates that have one label per sheet.</source>
        <translation>Solo funciona con plantillas de una etiqueta por hoja.</translation>
    </message>
    <message>
        <source>Fit design to label</source>
        <translation>Ajustar diseño a la etiqueta</translation>
    </message>
    <message>
        <source>Scale all the objects so the design fits the label</source>
        <translation>Escala todos los objetos para que el diseño quepa en la etiqueta</translation>
    </message>
    <message>
        <source>There are no objects to fit.</source>
        <translation>No hay objetos que ajustar.</translation>
    </message>
</context>
<context>
    <name>glabels::MergeView</name>
    <message>
        <source>Data files (*.xlsx *.csv *.txt *.tsv);;All files (*)</source>
        <translation>Archivos de datos (*.xlsx *.csv *.txt *.tsv);;Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Combinar</translation>
    </message>
    <message>
        <source>Select merge file</source>
        <translation>Seleccionar archivo de combinación</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
</context>
<context>
    <name>glabels::ObjectEditor</name>
        <message>
            <source>Crop</source>
            <translation>Recorte</translation>
        </message>
        <message>
            <source>Left:</source>
            <translation>Izquierda:</translation>
        </message>
        <message>
            <source>Top:</source>
            <translation>Arriba:</translation>
        </message>
        <message>
            <source>Right:</source>
            <translation>Derecha:</translation>
        </message>
        <message>
            <source>Bottom:</source>
            <translation>Abajo:</translation>
        </message>
        <message>
            <source>Crop...</source>
            <translation>Recortar...</translation>
        </message>
        <message>
            <source>Crop the image dragging a rectangle over it</source>
            <translation>Recorta la imagen arrastrando un rectángulo sobre ella</translation>
        </message>
        <message>
            <source>Remove crop</source>
            <translation>Quitar recorte</translation>
        </message>
    <message>
        <source>No line</source>
        <translation>Sin línea</translation>
    </message>
    <message>
        <source>No fill</source>
        <translation>Sin relleno</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <source>Original size</source>
        <translation>Tamaño original</translation>
    </message>
    <message>
        <source>Box object properties</source>
        <translation>Propiedades del rectángulo</translation>
    </message>
    <message>
        <source>line/fill</source>
        <translation>línea/relleno</translation>
    </message>
    <message>
        <source>position/size</source>
        <translation>posición/tamaño</translation>
    </message>
    <message>
        <source>shadow</source>
        <translation>Sombra</translation>
    </message>
    <message>
        <source>Ellipse object properties</source>
        <translation>Propiedades del elipse</translation>
    </message>
    <message>
        <source>Image object properties</source>
        <translation>Propiedades de la imagen</translation>
    </message>
    <message>
        <source>image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <source>Line object properties</source>
        <translation>Propiedades de la línea</translation>
    </message>
    <message>
        <source>Text object properties</source>
        <translation>Propiedades del texto</translation>
    </message>
    <message>
        <source>text</source>
        <translation>texto</translation>
    </message>
    <message>
        <source>Barcode object properties</source>
        <translation>Propiedades del código de barras</translation>
    </message>
    <message>
        <source>barcode</source>
        <translation>Código de barras</translation>
    </message>
    <message>
        <source>Object properties</source>
        <translation>Propiedades del objeto</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Línea</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Relleno</translation>
    </message>
    <message>
        <source>Image files (*.png *.jpg *.jpeg *.gif *.bmp *.pbm *.pgm *.ppm *.xbm *.xpm *.svg)</source>
        <translation>Archivos de imagen (*.png *.jpg *.jpeg *.gif *.bmp *.pbm *.pgm *.ppm *.xbm *.xpm *.svg)</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
    <message>
        <source>PNG - Portable Network Graphics (*.png)</source>
        <translation>PNG - Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <source>BMP - Windows Bitmap (*.bmp)</source>
        <translation>BMP - Windows Bitmap (*.bmp)</translation>
    </message>
    <message>
        <source>GIF - Graphics Interchange Format (*.gif)</source>
        <translation>GIF - Graphics Interchange Format (*.gif)</translation>
    </message>
    <message>
        <source>JPEG - Joint Photographic Experts Group (*.jpg *.jpeg)</source>
        <translation>JPEG - Joint Photographic Experts Group (*.jpg *.jpeg)</translation>
    </message>
    <message>
        <source>PBM - Portable Bitmap (*.pbm)</source>
        <translation>PBM - Portable Bitmap (*.pbm)</translation>
    </message>
    <message>
        <source>PGM - Portable Graymap (*.pgm)</source>
        <translation>PGM - Portable Graymap (*.pgm)</translation>
    </message>
    <message>
        <source>PPM - Portable Pixmap (*.ppm)</source>
        <translation>PPM - Portable Pixmap (*.ppm)</translation>
    </message>
    <message>
        <source>SVG - Scalable Vector Graphics (*.svg)</source>
        <translation>SVG - Scalable Vector Graphics (*.svg)</translation>
    </message>
    <message>
        <source>XBM - X11 Bitmap (*.xbm)</source>
        <translation>XBM - X11 Bitmap (*.xbm)</translation>
    </message>
    <message>
        <source>XPM - X11 Pixmap (*.xpm)</source>
        <translation>XPM - X11 Pixmap (*.xpm)</translation>
    </message>
    <message>
        <source>gLabels - Select image file</source>
        <translation>gLabels - Seleccionar archivo de imagen</translation>
    </message>
    <message>
        <source>Set image</source>
        <translation>Establecer imagen</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation>Sombra</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Barcode</source>
        <translation>Código de barras</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <source>Insert substitution field</source>
        <translation>Insertar campo de sustitución</translation>
    </message>
    <message>
        <source>Use substitution field</source>
        <translation>Usar campo de sustitución</translation>
    </message>
        <message>
            <source>format</source>
            <translation>formato</translation>
        </message>
        <message>
            <source>Format</source>
            <translation>Formato</translation>
        </message>
            <message>
            <source>transform</source>
            <translation>transformar</translation>
        </message>
            <message>
            <source>GS1 wizard...</source>
            <translation>Asistente GS1…</translation>
        </message>
            <message>
            <source>Barcode text</source>
            <translation>Texto del código de barras</translation>
        </message>
            <message>
            <source>Object name</source>
            <translation>Nombre del objeto</translation>
        </message>
        <message>
            <source>Selection:</source>
            <translation>Selección:</translation>
        </message>
        <message>
            <source>Font of the selected text</source>
            <translation>Fuente del texto seleccionado</translation>
        </message>
        <message>
            <source>Size of the selected text</source>
            <translation>Tamaño del texto seleccionado</translation>
        </message>
        <message>
            <source>Bold (selected text)</source>
            <translation>Negrita (texto seleccionado)</translation>
        </message>
        <message>
            <source>Italic (selected text)</source>
            <translation>Cursiva (texto seleccionado)</translation>
        </message>
        <message>
            <source>Underline (selected text)</source>
            <translation>Subrayado (texto seleccionado)</translation>
        </message>
        <message>
            <source>Clear</source>
            <translation>Quitar formato</translation>
        </message>
        <message>
            <source>Remove the formats of the selected text (it takes the format of the object)</source>
            <translation>Quita los formatos del texto seleccionado (toma el formato del objeto)</translation>
        </message>
        <message>
            <source>Name of the object. Other texts can take its value by this name.</source>
            <translation>Nombre del objeto. Otros textos pueden tomar su valor por este nombre.</translation>
        </message>
        <message>
            <source>Name:</source>
            <translation>Nombre:</translation>
        </message>
        <message>
            <source>The name cannot be empty.</source>
            <translation>El nombre no puede estar vacío.</translation>
        </message>
        <message>
            <source>Another object already has the name "%1".</source>
            <translation>Otro objeto ya tiene el nombre «%1».</translation>
        </message>
        <message>
            <source>Rename object</source>
            <translation>Renombrar objeto</translation>
        </message>
    </context>
<context>
    <name>glabels::PrintView</name>
    <message>
        <source>Printer settings...</source>
        <translation>Configuración de la impresora...</translation>
    </message>
    <message>
        <source>Printer settings</source>
        <translation>Configuración de la impresora</translation>
    </message>
    <message>
        <source>Open the properties of the selected printer (speed, darkness, paper size...).</source>
        <translation>Abre las propiedades de la impresora seleccionada (velocidad, oscuridad, tamaño del papel...).</translation>
    </message>
    <message>
        <source>Select a printer first. &quot;Print to file&quot; has no settings.</source>
        <translation>Seleccione primero una impresora. &quot;Imprimir a archivo&quot; no tiene configuración.</translation>
    </message>
    <message>
        <source>Could not open the properties of &quot;%1&quot;.</source>
        <translation>No se pudieron abrir las propiedades de &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>Use the system print dialog to change the settings of the printer.</source>
        <translation>Use el diálogo de impresión del sistema para cambiar la configuración de la impresora.</translation>
    </message>
    <message>
        <source>Use form...</source>
        <translation>Usar formulario...</translation>
    </message>
    <message>
        <source>Use form</source>
        <translation>Usar formulario</translation>
    </message>
    <message>
        <source>Type the values of the variables used by the label, then print.</source>
        <translation>Escriba los valores de las variables que usa la etiqueta y luego imprima.</translation>
    </message>
    <message>
        <source>This label does not use any variable.</source>
        <translation>Esta etiqueta no usa ninguna variable.</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on %2 pages.)</source>
        <translation>(Se imprimirán un total de %1 items en %2 pagínas.)</translation>
    </message>
    <message>
        <source>(Will print a total of 1 item on 1 page.)</source>
        <translation>(Se imprimen un total de 1 item en 1 pagina.)</translation>
    </message>
    <message>
        <source>(Will print a total of %1 items on 1 page.)</source>
        <translation>(Se imprimen un total de %1 items en 1 pagina.)</translation>
    </message>
    <message>
        <source>Print to file (PDF)</source>
        <translation>Imprimir en archivo (PDF)</translation>
    </message>
    <message>
        <source>PDF files (*.pdf);;All files (*)</source>
        <translation>Archivos PDF (*.pdf);;Todos los archivos (*)</translation>
    </message>
    <message>
        <source>%1 already exists.</source>
        <translation>%1 ya existe.</translation>
    </message>
    <message>
        <source>Do you want to overwrite it?</source>
        <translation>¿Desea sobrescribirlo?</translation>
    </message>
</context>
<context>
    <name>glabels::PropertiesView</name>
    <message>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <source>Product Rotate</source>
        <translation>Girar producto</translation>
    </message>
    <message>
        <source>Change Product</source>
        <translation>Cambiar producto</translation>
    </message>
</context>
<context>
    <name>glabels::ReportBugDialog</name>
    <message>
        <source>How to Report a Bug</source>
        <translation>Como informar un error</translation>
    </message>
    <message>
        <source>To submit a bug report, click on the button below.  This will open a web browser to the gLabels github issue tracking page.</source>
        <translation type="unfinished">Para enviar un informe de error, pulse en el botón inferior. Abrirá un navegador web a la pagina github de seguimiento de errores de gLabels.</translation>
    </message>
    <message>
        <source>Be sure to include a detailed description of the problem and how to recreate it.  Attach any screenshots and/or example glabels project files that may illustrate the problem.</source>
        <translation>Asegúrese de incluir una descripción detallada del problema y como reproducirlo. Añada cualquier pantallazo y/o proyecto glabels de ejemplo que podrían ilustrar el problema.</translation>
    </message>
    <message>
        <source>Before submitting a report, look through the existing issues for similar or related bugs.  If the issue has already been reported, please consider contributing to its report instead.  Otherwise, create a new issue report. Please paste the following information into the issue description.</source>
        <translation>Antes de enviar un informe, revise los problemas existentes por si hay errores similares o relacionados.  Si el problema ya fue reportado, considere contribuir a ese informe.  De lo contrario, cree un nuevo informe. Pegue la siguiente información en la descripción del problema.</translation>
    </message>
</context>
<context>
    <name>glabels::SelectProductDialog</name>
    <message>
        <source>Duplicate</source>
        <translation>Duplicar</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Make an editable copy of the selected template.</source>
        <translation>Crea una copia editable de la plantilla seleccionada.</translation>
    </message>
    <message>
        <source>Edit the selected custom template.</source>
        <translation>Edita la plantilla propia seleccionada.</translation>
    </message>
    <message>
        <source>Delete the selected custom template.</source>
        <translation>Elimina la plantilla propia seleccionada.</translation>
    </message>
    <message>
        <source>%1 (copy)</source>
        <translation>%1 (copia)</translation>
    </message>
    <message>
        <source>%1 (copy %2)</source>
        <translation>%1 (copia %2)</translation>
    </message>
    <message>
        <source>Edit template</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <source>This template has an advanced design (several layouts or a special shape). Use File > Product Template Designer (advanced).</source>
        <translation>Esta plantilla tiene un diseño avanzado (varias disposiciones o una forma especial). Use Archivo > Diseñador de plantillas (avanzado).</translation>
    </message>
    <message>
        <source>Delete template</source>
        <translation>Eliminar plantilla</translation>
    </message>
    <message>
        <source>Delete the template &quot;%1&quot;?</source>
        <translation>¿Eliminar la plantilla &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>This cannot be undone.</source>
        <translation>Esto no se puede deshacer.</translation>
    </message>
    <message>
        <source>Quick template...</source>
        <translation>Plantilla rápida...</translation>
    </message>
    <message>
        <source>Create a custom template: name, shape, size and labels per sheet.</source>
        <translation>Crea una plantilla propia: nombre, forma, tamaño y etiquetas por hoja.</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Vista de lista</translation>
    </message>
    <message>
        <source>Grid View</source>
        <translation>Vista de cuadrícula</translation>
    </message>
        <message>
            <source>Rename...</source>
            <translation>Renombrar…</translation>
        </message>
        <message>
            <source>Only custom templates can be renamed.</source>
            <translation>Solo se pueden renombrar los formatos personalizados.</translation>
        </message>
        <message>
            <source>Rename template</source>
            <translation>Renombrar formato</translation>
        </message>
        <message>
            <source>Vendor:</source>
            <translation>Fabricante:</translation>
        </message>
        <message>
            <source>Part #:</source>
            <translation>N.º de parte:</translation>
        </message>
        <message>
            <source>Description:</source>
            <translation>Descripción:</translation>
        </message>
        <message>
            <source>Vendor and part number cannot be empty.</source>
            <translation>El fabricante y el n.º de parte no pueden estar vacíos.</translation>
        </message>
        <message>
            <source>Could not rename the template. A template with that vendor and part number may already exist.</source>
            <translation>No se pudo renombrar el formato. Quizá ya existe uno con ese fabricante y n.º de parte.</translation>
        </message>
    </context>
<context>
    <name>glabels::SimplePreview</name>
    <message>
        <source>Up</source>
        <translation>Arriba</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesigner</name>
    <message>
        <source>Product Template Designer</source>
        <translation>Diseñador de plantillas de producto</translation>
    </message>
    <message>
        <source>Roll</source>
        <translation>Rollo</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerApplyPage</name>
    <message>
        <source>Save Product Template</source>
        <translation>Guardar plantilla de producto</translation>
    </message>
    <message>
        <source>Click &quot;Save&quot; to save your custom product template!</source>
        <translation>¡Pulse «Guardar» para guardar su plantilla de producto personalizada!</translation>
    </message>
    <message>
        <source>User product template (%1 %2) already exists.</source>
        <extracomment>%1 = brand name of product (e.g. Avery), %2 = part number of product (e.g. 5026).</extracomment>
        <translation>La plantilla de producto del Usuario (%1 %2) ya existe.</translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation>¿Deseas reemplazarlo?</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerCdPage</name>
    <message>
        <source>Product Size</source>
        <translation>Tamaño del producto</translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation>Ajuste los parámetros de tamaño de un único elemento del producto.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerContinuousPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation>Estilo de producto no compatible</translation>
    </message>
    <message>
        <source>Continuous tape product templates are not currently supported by the Product Template Designer.</source>
        <translation>El Diseñador de plantillas de producto no admite por ahora plantillas de cinta continua.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerEllipsePage</name>
    <message>
        <source>Product Size</source>
        <translation>Tamaño del producto</translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation>Ajuste los parámetros de tamaño de un único elemento del producto.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerIntroPage</name>
    <message>
        <source>Welcome</source>
        <translation>Bienvenido</translation>
    </message>
    <message>
        <source>Welcome to the gLabels Product Template Designer.</source>
        <translation>Bienvenido al Diseñador de plantillas de producto de Gedetca Labels.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNLayoutsPage</name>
    <message>
        <source>Number of Layouts</source>
        <translation>Cantidad de disposiciones</translation>
    </message>
    <message>
        <source>Please select the number of layouts required.</source>
        <translation>Seleccione el número de disposiciones necesarias.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerNamePage</name>
    <message>
        <source>Name and Description</source>
        <translation>Nombre y descripción</translation>
    </message>
    <message>
        <source>Please enter the following identifying information about the product.</source>
        <translation>Introduzca la siguiente información de identificación del producto.</translation>
    </message>
    <message>
        <source>Brand and part number match an existing built-in product template!</source>
        <translation>¡La marca y el número de parte coinciden con una plantilla de producto integrada existente!</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerOneLayoutPage</name>
    <message>
        <source>Layout</source>
        <translation>Disposición:</translation>
    </message>
    <message>
        <source>Please enter parameters for your single layout.</source>
        <translation>Introduzca los parámetros de su disposición única.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPageSizePage</name>
    <message>
        <source>Page Size</source>
        <translation>Tamaño de la página</translation>
    </message>
    <message>
        <source>Please select the product page size.</source>
        <translation>Seleccione el tamaño de página del producto.</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Otros</translation>
    </message>
    <message>
        <source>Roll</source>
        <translation>Rollo</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerPathPage</name>
    <message>
        <source>Unsupported Product Style</source>
        <translation>Estilo de producto no compatible</translation>
    </message>
    <message>
        <source>Path based product templates are not currently supported by the Product Template Designer.</source>
        <translation>El Diseñador de plantillas de producto no admite por ahora plantillas basadas en trazados.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRectPage</name>
    <message>
        <source>Product Size</source>
        <translation>Tamaño del producto</translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation>Ajuste los parámetros de tamaño de un único elemento del producto.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerRoundPage</name>
    <message>
        <source>Product Size</source>
        <translation>Tamaño del producto</translation>
    </message>
    <message>
        <source>Please adjust the size parameters of a single product item.</source>
        <translation>Ajuste los parámetros de tamaño de un único elemento del producto.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerShapePage</name>
    <message>
        <source>Product Shape</source>
        <translation>Forma del producto</translation>
    </message>
    <message>
        <source>Please select the basic product shape.</source>
        <translation>Seleccione la forma básica del producto.</translation>
    </message>
</context>
<context>
    <name>glabels::TemplateDesignerTwoLayoutPage</name>
    <message>
        <source>Layouts</source>
        <translation>Disposiciones</translation>
    </message>
    <message>
        <source>Please enter parameters for your two layouts.</source>
        <translation>Introduzca los parámetros de sus dos disposiciones.</translation>
    </message>
</context>
<context>
    <name>glabels::VariablesView</name>
    <message>
        <source>Variables</source>
        <translation>Variables</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Increment</source>
        <translation>Incremento</translation>
    </message>
    <message>
        <source>Step Size</source>
        <translation>Tamaño de paso</translation>
    </message>
    <message>
        <source>Add Variable</source>
        <translation>Agregar variable</translation>
    </message>
    <message>
        <source>Edit Variable</source>
        <translation>Editar variable</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>glabels::barcode::Backends</name>
    <message>
        <source>Code 39</source>
        <translation>Code 39</translation>
    </message>
    <message>
        <source>Code 39 Extended</source>
        <translation>Code 39 extendido</translation>
    </message>
    <message>
        <source>UPC-A</source>
        <translation>UPC-A</translation>
    </message>
    <message>
        <source>EAN-13</source>
        <translation>EAN-13</translation>
    </message>
    <message>
        <source>POSTNET (any)</source>
        <translation>POSTNET (cualquiera)</translation>
    </message>
    <message>
        <source>POSTNET-5 (ZIP only)</source>
        <translation>POSTNET-5 (solo código postal)</translation>
    </message>
    <message>
        <source>POSTNET-9 (ZIP+4)</source>
        <translation>POSTNET-9 (código postal+4)</translation>
    </message>
    <message>
        <source>POSTNET-11 (DPBC)</source>
        <translation>POSTNET-11 (DPBC)</translation>
    </message>
    <message>
        <source>CEPNET</source>
        <translation>CEPNET</translation>
    </message>
    <message>
        <source>USPS Intelligent Mail</source>
        <translation>Correo inteligente USPS</translation>
    </message>
    <message>
        <source>IEC16022 (DataMatrix)</source>
        <translation>IEC16022 (matriz de datos)</translation>
    </message>
    <message>
        <source>EAN (any)</source>
        <translation>EAN (cualquiera)</translation>
    </message>
    <message>
        <source>EAN-8</source>
        <translation>EAN-8</translation>
    </message>
    <message>
        <source>EAN-8+2</source>
        <translation>EAN-8+2</translation>
    </message>
    <message>
        <source>EAN-8+5</source>
        <translation>EAN-8+5</translation>
    </message>
    <message>
        <source>EAN-13+2</source>
        <translation>EAN-13+2</translation>
    </message>
    <message>
        <source>EAN-13+5</source>
        <translation>EAN-13+5</translation>
    </message>
    <message>
        <source>UPC (UPC-A or UPC-E)</source>
        <translation>UPC (UPC-A o UPC-E)</translation>
    </message>
    <message>
        <source>UPC-A +2</source>
        <translation>UPC-A +2</translation>
    </message>
    <message>
        <source>UPC-A +5</source>
        <translation>UPC-A +5</translation>
    </message>
    <message>
        <source>UPC-E</source>
        <translation>UPC-E</translation>
    </message>
    <message>
        <source>UPC-E +2</source>
        <translation>UPC-E +2</translation>
    </message>
    <message>
        <source>UPC-E +5</source>
        <translation>UPC-E +5</translation>
    </message>
    <message>
        <source>ISBN</source>
        <translation>ISBN</translation>
    </message>
    <message>
        <source>ISBN +5</source>
        <translation>ISBN +5</translation>
    </message>
    <message>
        <source>Code 128</source>
        <translation>Código 128</translation>
    </message>
    <message>
        <source>Code 128C</source>
        <translation>Código 128C</translation>
    </message>
    <message>
        <source>Code 128B</source>
        <translation>Código 128B</translation>
    </message>
    <message>
        <source>Interleaved 2 of 5</source>
        <translation>Intercalado 2 de 5</translation>
    </message>
    <message>
        <source>Codabar</source>
        <translation>Codabar</translation>
    </message>
    <message>
        <source>MSI</source>
        <translation>MSI</translation>
    </message>
    <message>
        <source>Plessey</source>
        <translation>Plessey</translation>
    </message>
    <message>
        <source>Code 93</source>
        <translation>Código 93</translation>
    </message>
    <message>
        <source>IEC18004 (QRCode)</source>
        <translation>IEC18004 (Código QR)</translation>
    </message>
    <message>
        <source>Australia Post Standard</source>
        <translation>Correo estándar Australia</translation>
    </message>
    <message>
        <source>Australia Post Reply Paid</source>
        <translation>Correo de contestación pagado Australia</translation>
    </message>
    <message>
        <source>Australia Post Route Code</source>
        <translation>Código de ruta Correo Australia</translation>
    </message>
    <message>
        <source>Australia Post Redirect</source>
        <translation>Correo redirigido Australia</translation>
    </message>
    <message>
        <source>Aztec Code</source>
        <translation>Código Azteca</translation>
    </message>
    <message>
        <source>Code One</source>
        <translation>Código uno</translation>
    </message>
    <message>
        <source>Code 11</source>
        <translation>Código 11</translation>
    </message>
    <message>
        <source>Code 16K</source>
        <translation>Código 16K</translation>
    </message>
    <message>
        <source>Code 2 of 5 IATA</source>
        <translation>Código 2 de 5 IATA</translation>
    </message>
    <message>
        <source>Code 2 of 5 Data Logic</source>
        <translation>Código 2 de 5 Data Logic</translation>
    </message>
    <message>
        <source>Code 32 (Italian Pharmacode)</source>
        <translation>Código 32 (Farmacódigo Italiano)</translation>
    </message>
    <message>
        <source>Code 49</source>
        <translation>Código 49</translation>
    </message>
    <message>
        <source>Code 128 (Mode C suppression)</source>
        <translation>Código 128 (Modo supresión C)</translation>
    </message>
    <message>
        <source>DAFT Code</source>
        <translation>Código DAFT</translation>
    </message>
    <message>
        <source>Data Matrix</source>
        <translation>Matriz de datos</translation>
    </message>
    <message>
        <source>Deutsche Post Leitcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deutsche Post Identcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dutch Post KIX Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN</source>
        <translation>EAN</translation>
    </message>
    <message>
        <source>Grid Matrix</source>
        <translation>Matriz de rejilla</translation>
    </message>
    <message>
        <source>GS1-128</source>
        <translation>GS1-128</translation>
    </message>
    <message>
        <source>HIBC Code 128</source>
        <translation>HIBC Code 128</translation>
    </message>
    <message>
        <source>HIBC Code 39</source>
        <translation>HIBC Code 39</translation>
    </message>
    <message>
        <source>HIBC Data Matrix</source>
        <translation>Matriz de datos HIBC</translation>
    </message>
    <message>
        <source>HIBC QR Code</source>
        <translation>HIBC QR Code</translation>
    </message>
    <message>
        <source>HIBC PDF417</source>
        <translation>HIBC PDF417</translation>
    </message>
    <message>
        <source>HIBC Aztec Code</source>
        <translation>HIBC código Azteca</translation>
    </message>
    <message>
        <source>ITF-14</source>
        <translation>ITF-14</translation>
    </message>
    <message>
        <source>Japanese Postal</source>
        <translation>Postal japonés</translation>
    </message>
    <message>
        <source>Korean Postal</source>
        <translation>Postal coreano</translation>
    </message>
    <message>
        <source>LOGMARS</source>
        <translation>LOGMARS</translation>
    </message>
    <message>
        <source>Maxicode</source>
        <translation>Maxicode</translation>
    </message>
    <message>
        <source>Micro QR Code</source>
        <translation>Micro QR Code</translation>
    </message>
    <message>
        <source>MSI Plessey</source>
        <translation>MSI Plessey</translation>
    </message>
    <message>
        <source>PDF417</source>
        <translation>PDF417</translation>
    </message>
    <message>
        <source>PLANET</source>
        <translation>PLANET</translation>
    </message>
    <message>
        <source>Pharmacode</source>
        <translation>Pharmacode</translation>
    </message>
    <message>
        <source>Pharmacode 2-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QR Code</source>
        <translation>Código QR</translation>
    </message>
    <message>
        <source>Telepen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Telepen Numeric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UK Plessey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aztec Runes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CEPNet (Brazilian Post)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Codablock-F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Stacked Omni.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Expanded Stacked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC MicroPDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MicroPDF417</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NVE-18 (SSCC-18)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PDF417 Compact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pharmazentralnummer (PZN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Code 2 of 5 Industrial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DotCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EAN-14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GS1 DataBar Omnidirectional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Han Xin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flattermarken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DPD Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>POSTNET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 4-State Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UPU S10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FIM (Facing ID Mark)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rMQR (Rectangular Micro QR)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 4-State Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VIN (Vehicle ID Number)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIBC Codablock-F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Royal Mail 2-D Mailmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BC412 (SEMI TI-95)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>glabels::model::Model</name>
    <message>
        <source>Untitled</source>
        <translation>Sin titulo</translation>
    </message>
</context>
<context>
    <name>glabels::model::ModelBarcodeObject</name>
    <message>
        <source>No barcode data</source>
        <translation>Sin datos de código de barras</translation>
    </message>
    <message>
        <source>Invalid barcode data</source>
        <translation>Datos de código de barras no válidos</translation>
    </message>
        <message>
            <source>Barcode</source>
            <translation>Código de barras</translation>
        </message>
    </context>
<context>
    <name>glabels::model::ModelImageObject</name>
    <message>
        <source>No image</source>
        <translation>Sin imagen</translation>
    </message>
        <message>
            <source>Image</source>
            <translation>Imagen</translation>
        </message>
    </context>
<context>
    <name>glabels::model::ModelTextObject</name>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    </context>
<context>
    <name>main</name>
    <message>
        <source>gLabels Label Designer</source>
        <translation type="unfinished">gLabels diseñador etiquetas</translation>
    </message>
    <message>
        <source>gLabels project files to open, optionally.</source>
        <translation>Archivos de proyecto de Gedetca Labels para abrir (opcional).</translation>
    </message>
</context>
    <context>
        <name>glabels::TextFormatEditor</name>
        <message>
            <source>Text</source>
            <translation>Texto</translation>
        </message>
        <message>
            <source>Date</source>
            <translation>Fecha</translation>
        </message>
        <message>
            <source>Time</source>
            <translation>Hora</translation>
        </message>
        <message>
            <source>Number</source>
            <translation>Número</translation>
        </message>
        <message>
            <source>Type:</source>
            <translation>Tipo:</translation>
        </message>
        <message>
            <source>Locale:</source>
            <translation>Local:</translation>
        </message>
        <message>
            <source>System default</source>
            <translation>Predeterminado del sistema</translation>
        </message>
        <message>
            <source>Format:</source>
            <translation>Formato:</translation>
        </message>
        <message>
            <source>Pattern:</source>
            <translation>Patrón:</translation>
        </message>
        <message>
            <source>Use thousands separator</source>
            <translation>Usar símbolo de separación</translation>
        </message>
        <message>
            <source>Show leading zero</source>
            <translation>Mostrar cero a la izquierda</translation>
        </message>
        <message>
            <source>Fixed at</source>
            <translation>Fijar en</translation>
        </message>
        <message>
            <source>Maximum of</source>
            <translation>Máximo de</translation>
        </message>
        <message>
            <source>decimal places</source>
            <translation>lugares decimales</translation>
        </message>
        <message>
            <source>Precision:</source>
            <translation>Precisión:</translation>
        </message>
        <message>
            <source>Negative numbers:</source>
            <translation>Números negativos:</translation>
        </message>
        <message>
            <source>Example</source>
            <translation>Ejemplo</translation>
        </message>
        <message>
            <source>Custom</source>
            <translation>Personalizado</translation>
        </message>
            <message>
            <source>As is</source>
            <translation>Sin cambios</translation>
        </message>
        <message>
            <source>Lower case</source>
            <translation>Minúsculas</translation>
        </message>
        <message>
            <source>Upper case</source>
            <translation>Mayúsculas</translation>
        </message>
        <message>
            <source>Capitalize each word</source>
            <translation>Primera mayúscula</translation>
        </message>
        <message>
            <source>Data view:</source>
            <translation>Vista de datos:</translation>
        </message>
    </context>
    <context>
        <name>glabels::TextTransformEditor</name>
        <message>
            <source>Skip</source>
            <translation>Omitir</translation>
        </message>
        <message>
            <source>Do not suppress</source>
            <translation>No suprimir</translation>
        </message>
        <message>
            <source>Suppress when this data is empty</source>
            <translation>Suprimir cuando este dato esté vacío</translation>
        </message>
        <message>
            <source>Suppress when the following field meets the condition:</source>
            <translation>Suprimir cuando el siguiente campo cumpla la condición:</translation>
        </message>
        <message>
            <source>Is empty</source>
            <translation>Está vacío</translation>
        </message>
        <message>
            <source>Is not empty</source>
            <translation>No está vacío</translation>
        </message>
        <message>
            <source>Equals</source>
            <translation>Es igual a</translation>
        </message>
        <message>
            <source>Is different from</source>
            <translation>Es distinto de</translation>
        </message>
        <message>
            <source>Contains</source>
            <translation>Contiene</translation>
        </message>
        <message>
            <source>Value</source>
            <translation>Valor</translation>
        </message>
        <message>
            <source>Offset</source>
            <translation>Desplazamiento</translation>
        </message>
        <message>
            <source>Constant</source>
            <translation>Constante</translation>
        </message>
        <message>
            <source>Offset source:</source>
            <translation>Origen del desplazamiento:</translation>
        </message>
        <message>
            <source>Offset:</source>
            <translation>Desplazamiento:</translation>
        </message>
        <message>
            <source>Units:</source>
            <translation>Unidades:</translation>
        </message>
        <message>
            <source>Second(s)</source>
            <translation>Segundo(s)</translation>
        </message>
        <message>
            <source>Minute(s)</source>
            <translation>Minuto(s)</translation>
        </message>
        <message>
            <source>Hour(s)</source>
            <translation>Hora(s)</translation>
        </message>
        <message>
            <source>Day(s)</source>
            <translation>Día(s)</translation>
        </message>
        <message>
            <source>Week(s)</source>
            <translation>Semana(s)</translation>
        </message>
        <message>
            <source>Month(s)</source>
            <translation>Mes(es)</translation>
        </message>
        <message>
            <source>Year(s)</source>
            <translation>Año(s)</translation>
        </message>
        <message>
            <source>Applies to date and time data.</source>
            <translation>Se aplica a datos de fecha y hora.</translation>
        </message>
        <message>
            <source>Attached text</source>
            <translation>Texto adjunto</translation>
        </message>
        <message>
            <source>Prefix:</source>
            <translation>Prefijo:</translation>
        </message>
        <message>
            <source>Suffix:</source>
            <translation>Sufijo:</translation>
        </message>
            <message>
            <source>Data processing</source>
            <translation>Procesamiento de datos</translation>
        </message>
        <message>
            <source>Search and replace:</source>
            <translation>Buscar y reemplazar:</translation>
        </message>
        <message>
            <source>Command script:</source>
            <translation>Archivo de comandos:</translation>
        </message>
        <message>
            <source>Serialization:</source>
            <translation>Serialización:</translation>
        </message>
        <message>
            <source>&lt;None&gt;</source>
            <translation>&lt;Ninguno&gt;</translation>
        </message>
        <message>
            <source>%1 action(s)</source>
            <translation>%1 acción(es)</translation>
        </message>
        <message>
            <source>%1 line(s)</source>
            <translation>%1 línea(s)</translation>
        </message>
        <message>
            <source>Increment</source>
            <translation>Incremento</translation>
        </message>
        <message>
            <source>Decrement</source>
            <translation>Decremento</translation>
        </message>
            <message>
            <source>Value source</source>
            <translation>Origen del valor</translation>
        </message>
        <message>
            <source>Own text (the Editor box of the text tab)</source>
            <translation>Texto propio (el cuadro Editor de la pestaña texto)</translation>
        </message>
        <message>
            <source>Value of another object</source>
            <translation>Valor de otro objeto</translation>
        </message>
        <message>
            <source>Data (before the format)</source>
            <translation>Dato (antes del formato)</translation>
        </message>
        <message>
            <source>Text as shown (with format)</source>
            <translation>Texto mostrado (con formato)</translation>
        </message>
        <message>
            <source>Object name:</source>
            <translation>Nombre del objeto:</translation>
        </message>
        <message>
            <source>Value:</source>
            <translation>Valor:</translation>
        </message>
    </context>
    <context>
        <name>glabels::PositionToolBar</name>
        <message>
            <source>Position</source>
            <translation>Posición</translation>
        </message>
    </context>
    <context>
        <name>glabels::SearchReplaceDialog</name>
        <message>
            <source>Search and replace</source>
            <translation>Buscar y reemplazar</translation>
        </message>
        <message>
            <source>Actions:</source>
            <translation>Acciones:</translation>
        </message>
        <message>
            <source>Add action</source>
            <translation>Agregar acción</translation>
        </message>
        <message>
            <source>Remove action</source>
            <translation>Eliminar acción</translation>
        </message>
        <message>
            <source>Move up</source>
            <translation>Subir</translation>
        </message>
        <message>
            <source>Move down</source>
            <translation>Bajar</translation>
        </message>
        <message>
            <source>Action options</source>
            <translation>Opciones de acción</translation>
        </message>
        <message>
            <source>Description:</source>
            <translation>Descripción:</translation>
        </message>
        <message>
            <source>Action:</source>
            <translation>Acción:</translation>
        </message>
        <message>
            <source>Trim spaces (start and end)</source>
            <translation>Recortar espacios (inicio y fin)</translation>
        </message>
        <message>
            <source>Search:</source>
            <translation>Buscar:</translation>
        </message>
        <message>
            <source>Use wildcards (* and ?)</source>
            <translation>Usar comodines (* y ?)</translation>
        </message>
        <message>
            <source>Exact text</source>
            <translation>Texto exacto</translation>
        </message>
        <message>
            <source>Regular expression</source>
            <translation>Expresión regular</translation>
        </message>
        <message>
            <source>First instance only</source>
            <translation>Solo primera instancia</translation>
        </message>
        <message>
            <source>Replace with:</source>
            <translation>Reemplazar con:</translation>
        </message>
        <message>
            <source>Test...</source>
            <translation>Probar…</translation>
        </message>
        <message>
            <source>Action%1</source>
            <translation>Acción%1</translation>
        </message>
        <message>
            <source>Test</source>
            <translation>Prueba</translation>
        </message>
        <message>
            <source>Sample text:</source>
            <translation>Texto de ejemplo:</translation>
        </message>
        <message>
            <source>Result:</source>
            <translation>Resultado:</translation>
        </message>
    </context>
    <context>
        <name>glabels::ScriptDialog</name>
        <message>
            <source>Command script</source>
            <translation>Archivo de comandos</translation>
        </message>
        <message>
            <source>JavaScript. The script receives the text in &lt;b&gt;Value&lt;/b&gt; and the merge fields and variables in &lt;b&gt;Fields&lt;/b&gt; (e.g. &lt;code&gt;Fields.lote&lt;/code&gt;). Leave the result in &lt;b&gt;Value&lt;/b&gt;.&lt;br&gt;Use &lt;b&gt;Insert example...&lt;/b&gt; for ready-made commands such as &lt;code&gt;RestarDias(Value, 1)&lt;/code&gt;, or write any JavaScript code (conditions, loops, functions...). Both can be mixed.&lt;br&gt;The script cannot access files, the network or the system, and it is stopped if it runs for more than half a second.</source>
            <translation>JavaScript. El script recibe el texto en &lt;b&gt;Value&lt;/b&gt; y los campos de combinación y variables en &lt;b&gt;Fields&lt;/b&gt; (p. ej. &lt;code&gt;Fields.lote&lt;/code&gt;). Deje el resultado en &lt;b&gt;Value&lt;/b&gt;.&lt;br&gt;Use &lt;b&gt;Insertar ejemplo…&lt;/b&gt; para comandos listos como &lt;code&gt;RestarDias(Value, 1)&lt;/code&gt;, o escriba cualquier código JavaScript (condiciones, bucles, funciones…). Se pueden mezclar.&lt;br&gt;El script no puede acceder a archivos, a la red ni al sistema, y se detiene si tarda más de medio segundo.</translation>
        </message>
        <message>
            <source>Test...</source>
            <translation>Probar…</translation>
        </message>
        <message>
            <source>Test</source>
            <translation>Prueba</translation>
        </message>
        <message>
            <source>Sample text (Value):</source>
            <translation>Texto de ejemplo (Value):</translation>
        </message>
        <message>
            <source>Result:</source>
            <translation>Resultado:</translation>
        </message>
        <message>
            <source>Script error:</source>
            <translation>Error en el script:</translation>
        </message>
            <message>
            <source>Insert example...</source>
            <translation>Insertar ejemplo…</translation>
        </message>
    </context>
    <context>
        <name>glabels::SerializationDialog</name>
        <message>
            <source>Serialization</source>
            <translation>Serialización</translation>
        </message>
        <message>
            <source>Do not serialize</source>
            <translation>No serializar</translation>
        </message>
        <message>
            <source>Increment</source>
            <translation>Incremento</translation>
        </message>
        <message>
            <source>Decrement</source>
            <translation>Decremento</translation>
        </message>
        <message>
            <source>Alphabetic and/or numeric</source>
            <translation>Alfabético y/o numérico</translation>
        </message>
        <message>
            <source>Numeric only</source>
            <translation>Solo numérico</translation>
        </message>
        <message>
            <source>Alphabetic only</source>
            <translation>Solo alfabético</translation>
        </message>
        <message>
            <source>Upper case A-Z</source>
            <translation>Mayúscula A-Z</translation>
        </message>
        <message>
            <source>Lower case a-z</source>
            <translation>Minúscula a-z</translation>
        </message>
        <message>
            <source>Preserve the number of characters</source>
            <translation>Preservar el número de caracteres</translation>
        </message>
        <message>
            <source>Method:</source>
            <translation>Método:</translation>
        </message>
        <message>
            <source>Letters:</source>
            <translation>Letras:</translation>
        </message>
        <message>
            <source>Increment by:</source>
            <translation>Incremento en:</translation>
        </message>
        <message>
            <source>When to increment</source>
            <translation>Cuándo incrementar</translation>
        </message>
        <message>
            <source>Every label</source>
            <translation>Cada etiqueta</translation>
        </message>
        <message>
            <source>Every copy</source>
            <translation>Cada copia</translation>
        </message>
        <message>
            <source>Every page</source>
            <translation>Cada página</translation>
        </message>
        <message>
            <source>Event:</source>
            <translation>Evento:</translation>
        </message>
        <message>
            <source>Event interval:</source>
            <translation>Intervalo del evento:</translation>
        </message>
        <message>
            <source>Sequence preview...</source>
            <translation>Secuencia de vista previa…</translation>
        </message>
        <message>
            <source>Sequence preview</source>
            <translation>Secuencia de vista previa</translation>
        </message>
        <message>
            <source>First value:</source>
            <translation>Primer valor:</translation>
        </message>
    </context>
    <context>
        <name>glabels::ExportImageDialog</name>
        <message>
            <source>Export image</source>
            <translation>Exportar imagen</translation>
        </message>
        <message>
            <source>Browse...</source>
            <translation>Examinar…</translation>
        </message>
        <message>
            <source>White</source>
            <translation>Blanco</translation>
        </message>
        <message>
            <source>Transparent</source>
            <translation>Transparente</translation>
        </message>
        <message>
            <source>Cut to the label shape (rounded corners, ellipse...)</source>
            <translation>Recortar a la forma de la etiqueta (esquinas redondeadas, elipse…)</translation>
        </message>
        <message>
            <source>%1 images will be created (one per selected merge record); a number is added to the file name.</source>
            <translation>Se crearán %1 imágenes (una por registro de combinación seleccionado); se agrega un número al nombre del archivo.</translation>
        </message>
        <message>
            <source>File:</source>
            <translation>Archivo:</translation>
        </message>
        <message>
            <source>Resolution:</source>
            <translation>Resolución:</translation>
        </message>
        <message>
            <source>Background:</source>
            <translation>Fondo:</translation>
        </message>
        <message>
            <source>The name may contain {name}, {date}, {time}, {datetime}, {n} and {field} (any merge field or variable), e.g. C:\Labels\{lote}.png</source>
            <translation>El nombre puede contener {name}, {date}, {time}, {datetime}, {n} y {field} (cualquier campo de combinación o variable), p. ej. C:\Etiquetas\{lote}.png</translation>
        </message>
        <message>
            <source>PNG images (*.png)</source>
            <translation>Imágenes PNG (*.png)</translation>
        </message>
    </context>
    <context>
        <name>glabels::Gs1Wizard</name>
        <message>
            <source>Sample</source>
            <translation>Muestra</translation>
        </message>
        <message>
            <source>Application identifiers</source>
            <translation>Identificadores de la aplicación</translation>
        </message>
        <message>
            <source>Select the application identifier (AI) to be used.</source>
            <translation>Seleccione el identificador de la aplicación (IA) que se utilizará.</translation>
        </message>
        <message>
            <source>AI</source>
            <translation>IA</translation>
        </message>
        <message>
            <source>Description</source>
            <translation>Descripción</translation>
        </message>
        <message>
            <source>Search (AI or description):</source>
            <translation>Buscar (IA o descripción):</translation>
        </message>
        <message>
            <source>Ready to configure the data component</source>
            <translation>Listo para configurar el componente de datos</translation>
        </message>
        <message>
            <source>✔ = Finished     ➔ = Next</source>
            <translation>✔ = Finalizado     ➔ = Siguiente</translation>
        </message>
        <message>
            <source>Press Next to start configuring the data source of the data component %1.</source>
            <translation>Pulse Siguiente para iniciar la configuración del origen de datos del componente de datos %1.</translation>
        </message>
        <message>
            <source>AI code (%1)</source>
            <translation>Código IA (%1)</translation>
        </message>
        <message>
            <source>Select the type of the data source</source>
            <translation>Seleccione el tipo del origen de datos</translation>
        </message>
        <message>
            <source>Component:</source>
            <translation>Componente:</translation>
        </message>
        <message>
            <source>Data format:</source>
            <translation>Formato de datos:</translation>
        </message>
        <message>
            <source>Embedded data</source>
            <translation>Datos incrustados</translation>
        </message>
        <message>
            <source>Merge field</source>
            <translation>Campo de combinación</translation>
        </message>
        <message>
            <source>Variable</source>
            <translation>Variable</translation>
        </message>
        <message>
            <source>Type:</source>
            <translation>Tipo:</translation>
        </message>
        <message>
            <source>Select the type of the new data source:</source>
            <translation>Seleccione el tipo del nuevo origen de datos:</translation>
        </message>
        <message>
            <source>The embedded data source stores the data in the document. It is used mainly to type static data with the keyboard, but it can also be used for dynamic data, such as counters.</source>
            <translation>El origen de datos incrustado almacena los datos en el documento. Se utiliza principalmente para introducir manualmente datos estáticos con el teclado, pero también se puede utilizar para datos dinámicos, como contadores.</translation>
        </message>
        <message>
            <source>The value is taken from a field of the merge data file (Merge tab). Each label uses the value of its own record.</source>
            <translation>El valor se toma de un campo del archivo de datos de combinación (pestaña Combinar). Cada etiqueta usa el valor de su propio registro.</translation>
        </message>
        <message>
            <source>The value is taken from a variable of the project (Variables tab), for example a counter.</source>
            <translation>El valor se toma de una variable del proyecto (pestaña Variables), por ejemplo un contador.</translation>
        </message>
        <message>
            <source>Enter the text for the embedded data source.</source>
            <translation>Introduzca el texto para el origen de datos incrustado.</translation>
        </message>
        <message>
            <source>Embedded data is provided using the keyboard.</source>
            <translation>Los datos incrustados se proporcionan utilizando el teclado.</translation>
        </message>
        <message>
            <source>Choose the merge field that provides the value.</source>
            <translation>Elija el campo de combinación que proporciona el valor.</translation>
        </message>
        <message>
            <source>Choose the variable that provides the value.</source>
            <translation>Elija la variable que proporciona el valor.</translation>
        </message>
        <message>
            <source>Merge field:</source>
            <translation>Campo de combinación:</translation>
        </message>
        <message>
            <source>Variable:</source>
            <translation>Variable:</translation>
        </message>
        <message>
            <source>The check digit is added automatically: the value must have %1 digits.</source>
            <translation>El dígito verificador se agrega automáticamente: el valor debe tener %1 dígitos.</translation>
        </message>
        <message>
            <source>Do you want to add more data?</source>
            <translation>¿Desea anexar más datos?</translation>
        </message>
        <message>
            <source>You have completed the configuration of this application identifier. Do you want to add another application identifier?</source>
            <translation>Ha completado la configuración de este identificador de aplicación. ¿Desea anexar otro identificador de aplicación?</translation>
        </message>
        <message>
            <source>Yes, I want to add another</source>
            <translation>Sí, quiero agregar otro</translation>
        </message>
        <message>
            <source>No, I do not need more</source>
            <translation>No, no necesito más</translation>
        </message>
        <message>
            <source>✔ = Finished</source>
            <translation>✔ = Finalizado</translation>
        </message>
        <message>
            <source>GS1 application identifier data source wizard</source>
            <translation>Asistente para el origen de datos del identificador de la aplicación GS1</translation>
        </message>
        <message>
            <source>Finish</source>
            <translation>Terminar</translation>
        </message>
        <message>
            <source> + check digit</source>
            <translation> + dígito verificador</translation>
        </message>
            <message>
            <source>&lt; Back</source>
            <translation>&lt; Atrás</translation>
        </message>
        <message>
            <source>Next &gt;</source>
            <translation>Siguiente &gt;</translation>
        </message>
        <message>
            <source>Cancel</source>
            <translation>Cancelar</translation>
        </message>
    </context>
    <context>
        <name>glabels::BarcodeTextEditor</name>
        <message>
            <source>Use a custom text format</source>
            <translation>Usar un formato de texto personalizado</translation>
        </message>
        <message>
            <source>This barcode style has its own text. Check to draw the text with the format below.</source>
            <translation>Este tipo de código tiene su propio texto. Márquelo para dibujar el texto con el formato de abajo.</translation>
        </message>
        <message>
            <source>Bold</source>
            <translation>Negrita</translation>
        </message>
        <message>
            <source>Italic</source>
            <translation>Cursiva</translation>
        </message>
        <message>
            <source>Underline</source>
            <translation>Subrayado</translation>
        </message>
        <message>
            <source>Align left</source>
            <translation>Alinear a la izquierda</translation>
        </message>
        <message>
            <source>Center</source>
            <translation>Centrar</translation>
        </message>
        <message>
            <source>Align right</source>
            <translation>Alinear a la derecha</translation>
        </message>
        <message>
            <source>Text above the barcode</source>
            <translation>Texto sobre el código</translation>
        </message>
        <message>
            <source>Allow printing to shrink the text to fit the object</source>
            <translation>Permitir impresión que encoja el texto para entrar en el objeto</translation>
        </message>
        <message>
            <source>Stretch text to fill the box (deform)</source>
            <translation>Estirar texto para llenar el cuadro (deformar)</translation>
        </message>
    </context>
    <context>
        <name>glabels::model::ModelObject</name>
        <message>
            <source>Object</source>
            <translation>Objeto</translation>
        </message>
    </context>
    <context>
        <name>glabels::model::ModelBoxObject</name>
        <message>
            <source>Box</source>
            <translation>Rectángulo</translation>
        </message>
    </context>
    <context>
        <name>glabels::model::ModelEllipseObject</name>
        <message>
            <source>Ellipse</source>
            <translation>Elipse</translation>
        </message>
    </context>
    <context>
        <name>glabels::model::ModelLineObject</name>
        <message>
            <source>Line</source>
            <translation>Línea</translation>
        </message>
    </context>
<context>
    <name>glabels::ObjectListWidget</name>
    <message>
        <source>Objects of the label. Select one to select it in the work area.</source>
        <translation>Objetos de la etiqueta. Seleccione uno para seleccionarlo en el área de trabajo.</translation>
    </message>
</context>
<context>
    <name>glabels::PrintFormDialog</name>
    <message>
        <source>Data entry form</source>
        <translation>Formulario de entrada de datos</translation>
    </message>
    <message>
        <source>Type the values to print. The preview changes when you accept.</source>
        <translation>Escriba los valores a imprimir. La vista previa cambia al aceptar.</translation>
    </message>
    <message>
        <source>This label does not use any variable.</source>
        <translation>Esta etiqueta no usa ninguna variable.</translation>
    </message>
    <message>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Date and time</source>
        <translation>Fecha y hora</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Integer</source>
        <translation>Entero</translation>
    </message>
    <message>
        <source>Decimal</source>
        <translation>Decimal</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>glabels::QuickTemplateDialog</name>
    <message>
        <source>Edit template</source>
        <translation>Editar plantilla</translation>
    </message>
    <message>
        <source>Quick template</source>
        <translation>Plantilla rápida</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <source>e.g. Label 100x100</source>
        <translation>Ej.: Etiqueta 100x100</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Shape:</source>
        <translation>Forma:</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Rectángulo</translation>
    </message>
    <message>
        <source>Rounded corners</source>
        <translation>Esquinas redondeadas</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Alto:</translation>
    </message>
    <message>
        <source>Diameter:</source>
        <translation>Diámetro:</translation>
    </message>
    <message>
        <source>Corner radius:</source>
        <translation>Radio de esquina:</translation>
    </message>
    <message>
        <source>Sheet</source>
        <translation>Hoja</translation>
    </message>
    <message>
        <source>One label per sheet (roll or single label)</source>
        <translation>Una etiqueta por hoja (rollo o etiqueta suelta)</translation>
    </message>
    <message>
        <source>Several labels per sheet</source>
        <translation>Varias etiquetas por hoja</translation>
    </message>
    <message>
        <source>Paper:</source>
        <translation>Papel:</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>Sheet width:</source>
        <translation>Ancho de hoja:</translation>
    </message>
    <message>
        <source>Sheet height:</source>
        <translation>Alto de hoja:</translation>
    </message>
    <message>
        <source>Columns:</source>
        <translation>Columnas:</translation>
    </message>
    <message>
        <source>Rows:</source>
        <translation>Filas:</translation>
    </message>
    <message>
        <source>Left margin:</source>
        <translation>Margen izquierdo:</translation>
    </message>
    <message>
        <source>Top margin:</source>
        <translation>Margen superior:</translation>
    </message>
    <message>
        <source>Horizontal gap:</source>
        <translation>Separación horizontal:</translation>
    </message>
    <message>
        <source>Vertical gap:</source>
        <translation>Separación vertical:</translation>
    </message>
    <message>
        <source>Center on sheet</source>
        <translation>Centrar en la hoja</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Enter a name for the template.</source>
        <translation>Escriba un nombre para la plantilla.</translation>
    </message>
    <message>
        <source>The labels do not fit on the sheet. Adjust the margins, gaps or the number of labels.</source>
        <translation>Las etiquetas no caben en la hoja. Ajuste los márgenes, separaciones o la cantidad de etiquetas.</translation>
    </message>
    <message>
        <source>A template named &quot;%1&quot; already exists.</source>
        <translation>Ya existe una plantilla llamada &quot;%1&quot;.</translation>
    </message>
    <message>
        <source>Do you want to replace it?</source>
        <translation>¿Desea reemplazarla?</translation>
    </message>
    <message>
        <source>Replace</source>
        <translation>Reemplazar</translation>
    </message>
</context>
    <context>
        <name>glabels::FormatToolBar</name>
        <message>
            <source>Format</source>
            <translation>Formato</translation>
        </message>
        <message>
            <source>Font</source>
            <translation>Fuente</translation>
        </message>
        <message>
            <source>Font size (pt)</source>
            <translation>Tamaño de letra (pt)</translation>
        </message>
        <message>
            <source>Font size</source>
            <translation>Tamaño de letra</translation>
        </message>
        <message>
            <source>Bold</source>
            <translation>Negrita</translation>
        </message>
        <message>
            <source>Italic</source>
            <translation>Cursiva</translation>
        </message>
        <message>
            <source>Underline</source>
            <translation>Subrayado</translation>
        </message>
        <message>
            <source>Align text left</source>
            <translation>Alinear texto a la izquierda</translation>
        </message>
        <message>
            <source>Center text</source>
            <translation>Centrar texto</translation>
        </message>
        <message>
            <source>Align text right</source>
            <translation>Alinear texto a la derecha</translation>
        </message>
        <message>
            <source>Align text to top</source>
            <translation>Texto arriba</translation>
        </message>
        <message>
            <source>Align text to middle</source>
            <translation>Texto al centro vertical</translation>
        </message>
        <message>
            <source>Align text to bottom</source>
            <translation>Texto abajo</translation>
        </message>
        <message>
            <source>Text color</source>
            <translation>Color del texto</translation>
        </message>
        <message>
            <source>Fill color</source>
            <translation>Color de relleno</translation>
        </message>
        <message>
            <source>Line color</source>
            <translation>Color de línea</translation>
        </message>
        <message>
            <source>Fill</source>
            <translation>Relleno</translation>
        </message>
        <message>
            <source>Line</source>
            <translation>Línea</translation>
        </message>
        <message>
            <source>No fill</source>
            <translation>Sin relleno</translation>
        </message>
        <message>
            <source>No line</source>
            <translation>Sin línea</translation>
        </message>
        <message>
            <source>Line width (pt)</source>
            <translation>Grosor de línea (pt)</translation>
        </message>
        <message>
            <source>Line width</source>
            <translation>Grosor de línea</translation>
        </message>
        <message>
            <source>Text alignment</source>
            <translation>Alineación del texto</translation>
        </message>
        <message>
            <source>Position X (mm)</source>
            <translation>Posición X (mm)</translation>
        </message>
        <message>
            <source>Position Y (mm)</source>
            <translation>Posición Y (mm)</translation>
        </message>
        <message>
            <source>Width (mm)</source>
            <translation>Ancho (mm)</translation>
        </message>
        <message>
            <source>Height (mm)</source>
            <translation>Alto (mm)</translation>
        </message>
        <message>
            <source>W</source>
            <translation>An</translation>
        </message>
        <message>
            <source>H</source>
            <translation>Al</translation>
        </message>
    </context>
<context>
    <name>glabels::CropDialog</name>
        <message>
            <source>Crop image</source>
            <translation>Recortar imagen</translation>
        </message>
        <message>
            <source>Left:</source>
            <translation>Izquierda:</translation>
        </message>
        <message>
            <source>Top:</source>
            <translation>Arriba:</translation>
        </message>
        <message>
            <source>Right:</source>
            <translation>Derecha:</translation>
        </message>
        <message>
            <source>Bottom:</source>
            <translation>Abajo:</translation>
        </message>
        <message>
            <source>Remove crop</source>
            <translation>Quitar recorte</translation>
        </message>
        <message>
            <source>Drag the edges or corners of the rectangle; drag inside to move it.</source>
            <translation>Arrastra los bordes o esquinas del rectángulo; arrastra dentro para moverlo.</translation>
        </message>
        <message>
            <source>Crop</source>
            <translation>Recortar</translation>
        </message>
</context>
</TS>
