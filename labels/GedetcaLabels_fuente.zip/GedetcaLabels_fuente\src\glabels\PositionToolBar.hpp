//  PositionToolBar.hpp
//
//  Vertical toolbar for aligning, centering, sizing and rotating the selected
//  objects (BarTender-like).
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef PositionToolBar_hpp
#define PositionToolBar_hpp


#include <QAction>
#include <QIcon>
#include <QString>
#include <QToolBar>


namespace glabels
{

        class PositionToolBar : public QToolBar
        {
                Q_OBJECT

        public:
                explicit PositionToolBar( QWidget* parent = nullptr );

                // Adds a button that triggers 'target' and follows its enabled state
                QAction* addMirror( const QString& iconName, const QString& toolTip, QAction* target );

                static QIcon makeIcon( const QString& name );
        };

}


#endif // PositionToolBar_hpp
