//  TextFormat.hpp
//
//  Data formatting and transformation for text objects:
//  format (text/date/time/number), data view (case), date offset,
//  prefix/suffix and conditional suppression.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_TextFormat_hpp
#define model_TextFormat_hpp


#include "Variables.hpp"
#include "merge/Record.hpp"

#include <QDateTime>
#include <QString>
#include <QList>
#include <QStringList>


namespace glabels::model
{

        class TextFormat
        {
        public:
                enum Type { TEXT = 0, DATE = 1, TIME = 2, NUMBER = 3 };
                enum CaseMode { CASE_NONE = 0, CASE_LOWER = 1, CASE_UPPER = 2, CASE_TITLE = 3 };
                enum OffsetUnit { SECONDS = 0, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS };
                enum SuppressMode { SUPPRESS_NEVER = 0, SUPPRESS_IF_EMPTY = 1, SUPPRESS_IF_FIELD = 2 };
                enum Condition { COND_EMPTY = 0, COND_NOT_EMPTY, COND_EQUALS, COND_NOT_EQUALS, COND_CONTAINS };

                enum SerialMode { SERIAL_NONE = 0, SERIAL_INCREMENT = 1, SERIAL_DECREMENT = 2 };
                enum SerialMethod { SERIAL_ALNUM = 0, SERIAL_NUMERIC = 1, SERIAL_ALPHA = 2 };
                enum SerialEvent { EVENT_ITEM = 0, EVENT_COPY = 1, EVENT_PAGE = 2 };

                // One "search and replace" action
                struct ReplaceAction
                {
                        enum Kind   { FIND_REPLACE = 0, TRIM = 1 };
                        enum Syntax { WILDCARD = 0, EXACT = 1, REGEX = 2 };

                        QString description;
                        Kind    kind{ FIND_REPLACE };
                        QString find;
                        QString replace;
                        Syntax  syntax{ WILDCARD };
                        bool    firstOnly{ false };

                        bool operator==( const ReplaceAction& o ) const;
                };
                // ---- Format (tab "format")
                Type     type{ TEXT };
                QString  locale;                 // QLocale name (e.g. "es_MX"); empty = system
                QString  pattern;                // Date/Time pattern (Qt syntax)
                bool     grouping{ true };       // Number: use thousands separator
                bool     leadingZero{ true };    // Number: show zero before decimal point
                bool     fixedDecimals{ true };  // Number: true = fixed, false = maximum
                int      decimals{ 2 };          // Number: decimal places
                int      negativeStyle{ 0 };     // Number: see negativeStyleExamples()
                CaseMode caseMode{ CASE_NONE };  // Data view

                // ---- Transform (tab "transform")
                QString      prefix;
                QString      suffix;
                int          offsetValue{ 0 };       // Date/Time offset
                OffsetUnit   offsetUnit{ DAYS };
                SuppressMode suppressMode{ SUPPRESS_NEVER };
                QString      suppressField;
                Condition    suppressCond{ COND_EMPTY };
                QString      suppressValue;

                // ---- Search and replace, script and serialization (tab "transform")
                QList<ReplaceAction> replaceActions;
                QString      script;                   // JavaScript; variables: Value, Fields
                SerialMode   serialMode{ SERIAL_NONE };
                SerialMethod serialMethod{ SERIAL_ALNUM };
                bool         serialLowerCase{ false };  // letters for new positions
                bool         serialPreserve{ false };   // keep the number of characters
                int          serialStep{ 1 };
                SerialEvent  serialEvent{ EVENT_ITEM };
                int          serialInterval{ 1 };

                bool isDefault() const;

                // Serialization (stored as a single attribute in the .glabels file)
                QString toString() const;
                static TextFormat fromString( const QString& s );

                // Applies the format. Returns false (and leaves 'out' untouched)
                // if the value cannot be interpreted.  Date/time: empty value = now.
                bool tryApply( const QString& value, QString& out ) const;

                // Full pipeline for printing: search/replace, script, serialization,
                // then the format.  Counters come from the print job (variables).
                QString process( const QString&       value,
                                 const merge::Record& record,
                                 const Variables&     variables ) const;

                // The data after search/replace, script and serialization (before the format)
                QString preProcess( const QString&       value,
                                    const merge::Record& record,
                                    const Variables&     variables ) const;

                // Applies the format; returns the original text if not applicable.
                QString apply( const QString& value ) const;

                // Serialization alone: value after 'count' events (used by the dialog preview)
                QString applySerial( const QString& value, long long count ) const;

                // Should the object be skipped for this record?
                // 'ownValue' is the expanded (unformatted) text of the object.
                bool suppressed( const QString&       ownValue,
                                 const merge::Record& record,
                                 const Variables&     variables ) const;

                // Value used for the preview when the actual data cannot be parsed
                QString sampleValue() const;

                // Presets shown in the editor (pattern lists)
                static QStringList datePatterns();
                static QStringList timePatterns();
                static QDateTime   referenceDateTime();
                static QStringList negativeStyleExamples();

                bool operator==( const TextFormat& other ) const;
                bool operator!=( const TextFormat& other ) const { return !(*this == other); }

        private:
                bool parseDateTime( const QString& value, QDateTime& dt ) const;
                QString formatNumber( double v ) const;
                QString applyCase( const QString& s ) const;
                QString applyReplaceActions( const QString& s ) const;
        };

}


#endif // model_TextFormat_hpp
