//  ImageExporter.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "ImageExporter.hpp"
#include "PrintOptions.hpp"

#include "Frame.hpp"
#include "merge/Merge.hpp"

#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QPainter>
#include <QPainterPath>
#include <QRegularExpression>
#include <QStandardPaths>


namespace glabels::model
{

        namespace
        {
                // File name safe text
                QString sanitize( const QString& s )
                {
                        QString r = s;
                        r.replace( QRegularExpression( "[<>:\"/\\\\|?*\\x00-\\x1f]" ), "_" );
                        r = r.trimmed();
                        while ( r.endsWith( '.' ) ) r.chop( 1 );
                        return r;
                }

                bool hasToken( const QString& s, const QString& token )
                {
                        return s.contains( "{" + token + "}", Qt::CaseInsensitive );
                }
        }


        QString ImageExporter::defaultFolder()
        {
                QString docs = QStandardPaths::writableLocation( QStandardPaths::DocumentsLocation );
                if ( docs.isEmpty() )
                {
                        docs = QDir::homePath();
                }
                return QDir( docs ).filePath( "Gedetca Labels/Exportaciones" );
        }


        QImage ImageExporter::render( const Model*         model,
                                      const merge::Record& record,
                                      const Variables&     variables,
                                      const Options&       options )
        {
                double dpi = qBound( 36.0, options.dpi, 2400.0 );
                double scale = dpi / 72.0;

                int w = qMax( 1, int( qRound( model->w().pt() * scale ) ) );
                int h = qMax( 1, int( qRound( model->h().pt() * scale ) ) );

                QImage image( w, h, QImage::Format_ARGB32 );
                image.setDotsPerMeterX( int( dpi / 0.0254 ) );
                image.setDotsPerMeterY( int( dpi / 0.0254 ) );
                image.fill( options.transparent ? Qt::transparent : Qt::white );

                QPainter painter( &image );
                const bool smooth = !PrintOptions::noAntialias();
                painter.setRenderHint( QPainter::Antialiasing, smooth );
                painter.setRenderHint( QPainter::TextAntialiasing, smooth );
                painter.setRenderHint( QPainter::SmoothPixmapTransform, smooth );
                painter.scale( scale, scale );

                if ( options.clipToShape && model->frame() )
                {
                        painter.setClipPath( model->frame()->clipPath() );
                }

                // 'draw' keeps counters of the print job, so give it its own copy
                Variables vars( variables );
                model->draw( &painter, false, record, vars );

                painter.end();
                return image;
        }


        QString ImageExporter::expandPattern( const QString&       pattern,
                                              const QString&       projectName,
                                              int                  index,
                                              int                  count,
                                              const merge::Record& record,
                                              const Variables&     variables )
        {
                QDateTime now = QDateTime::currentDateTime();
                int width = qMax( 4, QString::number( count ).size() );

                QString out;
                int i = 0;
                while ( i < pattern.size() )
                {
                        if ( pattern[i] == '{' )
                        {
                                int j = pattern.indexOf( '}', i + 1 );
                                if ( j > i )
                                {
                                        QString key = pattern.mid( i + 1, j - i - 1 );
                                        QString lower = key.toLower();
                                        QString value;
                                        bool known = true;

                                        if ( lower == "name" )          value = projectName;
                                        else if ( lower == "date" )     value = now.toString( "yyyyMMdd" );
                                        else if ( lower == "time" )     value = now.toString( "HHmmss" );
                                        else if ( lower == "datetime" ) value = now.toString( "yyyyMMdd_HHmmss" );
                                        else if ( lower == "n" )        value = QString::number( index + 1 ).rightJustified( width, '0' );
                                        else if ( record.contains( key ) )    value = record.value( key );
                                        else if ( variables.contains( key ) ) value = variables[key].value();
                                        else known = false;

                                        if ( known )
                                        {
                                                out += sanitize( value );
                                                i = j + 1;
                                                continue;
                                        }
                                }
                        }
                        out += pattern[i];
                        i++;
                }
                return out;
        }


        QStringList ImageExporter::exportPng( Model*         model,
                                              const QString& targetIn,
                                              const Options& options,
                                              QString*       error )
        {
                QStringList written;

                // ---- Which records?
                QList<merge::Record> records;
                if ( model->merge() && !model->merge()->keys().isEmpty() )
                {
                        records = model->merge()->selectedRecords();
                }
                if ( records.isEmpty() )
                {
                        records << merge::Record();
                }
                const int count = records.size();

                // ---- Target: pattern with tokens, file name or folder
                QString projectName = model->shortName();
                if ( projectName.isEmpty() )
                {
                        projectName = "etiqueta";
                }
                projectName = sanitize( projectName );

                QString target = targetIn.trimmed();
                if ( target.isEmpty() )
                {
                        target = defaultFolder();
                }

                bool isPng = target.endsWith( ".png", Qt::CaseInsensitive );
                if ( !isPng )
                {
                        // A folder: {name}.png (or {name}_{n}.png)
                        target = QDir( target ).filePath( "{name}.png" );
                }

                // Several images need different names
                bool needsNumber = ( count > 1 ) && !hasToken( target, "n" );
                bool perRecordName = false;
                {
                        // A field token that differs between records is also enough
                        const QRegularExpression re( "\\{([^}]+)\\}" );
                        auto it = re.globalMatch( target );
                        while ( it.hasNext() )
                        {
                                QString key = it.next().captured( 1 );
                                if ( records.first().contains( key ) ) perRecordName = true;
                        }
                }

                // Variables as in a print job: initial values, counters grow per image
                Variables variables( model->constVariables() );
                variables.resetVariables();

                QStringList used;
                for ( int i = 0; i < count; i++ )
                {
                        QString fileName = expandPattern( target, projectName, i, count, records[i], variables );

                        if ( needsNumber && !perRecordName )
                        {
                                QFileInfo fi( fileName );
                                fileName = fi.path() + "/" + fi.completeBaseName() + "_" +
                                           QString::number( i + 1 ).rightJustified( qMax( 4, QString::number( count ).size() ), '0' ) +
                                           ".png";
                        }
                        else if ( used.contains( fileName ) )
                        {
                                // Same name twice (e.g. repeated field value): keep both
                                QFileInfo fi( fileName );
                                fileName = fi.path() + "/" + fi.completeBaseName() + "_" + QString::number( i + 1 ) + ".png";
                        }
                        used << fileName;

                        QDir().mkpath( QFileInfo( fileName ).absolutePath() );

                        QImage image = render( model, records[i], variables, options );
                        if ( !image.save( fileName, "PNG" ) )
                        {
                                if ( error ) *error = "Could not write " + fileName;
                                return written;
                        }
                        written << QDir::toNativeSeparators( QFileInfo( fileName ).absoluteFilePath() );

                        variables.incrementVariablesOnItem();
                        variables.incrementVariablesOnCopy();
                }

                return written;
        }

}
