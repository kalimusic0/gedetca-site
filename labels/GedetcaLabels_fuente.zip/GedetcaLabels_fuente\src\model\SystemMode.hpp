//  SystemMode.hpp
//
//  This file is part of gLabels-qt (Gedetca Labels).

#ifndef model_SystemMode_hpp
#define model_SystemMode_hpp


namespace glabels::model
{

        ///
        /// True when the editor was opened by Gedetca Web (--system): only then labels that belong to the system
        /// (made in its Modelador) can be edited. Opened any other way they are read-only.
        ///
        struct SystemMode
        {
                static bool& active()
                {
                        static bool value = false;
                        return value;
                }
        };

}


#endif // model_SystemMode_hpp
