//  TextTransformEditor.hpp
//
//  Editor for the transformations of a text object's data:
//  skip (suppress), date offset, prefix and suffix.
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef TextTransformEditor_hpp
#define TextTransformEditor_hpp


#include "model/TextFormat.hpp"

#include <QComboBox>
#include <QLineEdit>
#include <QRadioButton>
#include <QSpinBox>
#include <QWidget>


namespace glabels
{

        class TextTransformEditor : public QWidget
        {
                Q_OBJECT

        public:
                explicit TextTransformEditor( QWidget* parent = nullptr );

                // Reads/writes only the transform part of the format
                void fillFormat( model::TextFormat& format ) const;
                void setFormat( const model::TextFormat& format );

                // Names of merge fields and variables available for conditions
                void setFieldNames( const QStringList& names );

                // Value of another object (identity of objects): names offered and current choice
                void setObjectNames( const QStringList& names );
                void setSource( const QString& objectName, int kind );
                QString sourceName() const;
                int sourceKind() const;

        signals:
                void changed();

        private slots:
                void onControlsChanged();
                void onEditReplace();
                void onEditScript();
                void onEditSerial();

        private:
                void updateEnabled();
                void updateSummaries();

                QRadioButton* mNeverRadio;
                QRadioButton* mEmptyRadio;
                QRadioButton* mFieldRadio;
                QComboBox*    mFieldCombo;
                QComboBox*    mCondCombo;
                QLineEdit*    mValueEdit;

                QSpinBox*     mOffsetSpin;
                QComboBox*    mUnitCombo;

                QLineEdit*    mPrefixEdit;
                QLineEdit*    mSuffixEdit;

                // Search/replace, script and serialization (edited in dialogs)
                model::TextFormat mAdvanced;
                QStringList   mFieldNames;
                QLineEdit*    mReplaceSummary;
                QLineEdit*    mScriptSummary;
                QLineEdit*    mSerialSummary;

                // Source of the value (own text / value of another object)
                QRadioButton* mOwnRadio;
                QRadioButton* mObjectRadio;
                QComboBox*    mObjectCombo;
                QComboBox*    mKindCombo;

                bool          mBlocked{ false };
        };

}


#endif // TextTransformEditor_hpp
