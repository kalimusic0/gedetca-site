//  Merge/Excel.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "Excel.hpp"

#include <QDate>
#include <QDateTime>
#include <QHash>
#include <QRegularExpression>
#include <QXmlStreamReader>
#include <private/qzipreader_p.h>

#include <cmath>


namespace
{
        static const QString ID = "Excel/Xlsx";

        // Column letters of a cell reference ("AB12" -> 27)
        int columnFromRef( const QString& ref )
        {
                int col = 0;
                for ( QChar c : ref )
                {
                        if ( c.isLetter() )
                        {
                                col = col*26 + ( c.toUpper().unicode() - 'A' + 1 );
                        }
                        else
                        {
                                break;
                        }
                }
                return col - 1;
        }

        // Text of an <si> or <is> element (plain or rich text)
        QString readRichText( QXmlStreamReader& xml, const QString& endName )
        {
                QString text;
                while ( !xml.atEnd() )
                {
                        xml.readNext();
                        if ( xml.isStartElement() && xml.name() == QLatin1String( "t" ) )
                        {
                                text += xml.readElementText( QXmlStreamReader::IncludeChildElements );
                        }
                        else if ( xml.isEndElement() && xml.name() == endName )
                        {
                                break;
                        }
                }
                return text;
        }

        QStringList readSharedStrings( const QByteArray& data )
        {
                QStringList list;
                QXmlStreamReader xml( data );
                while ( !xml.atEnd() )
                {
                        xml.readNext();
                        if ( xml.isStartElement() && xml.name() == QLatin1String( "si" ) )
                        {
                                list << readRichText( xml, "si" );
                        }
                }
                return list;
        }

        // Does a number format show dates or times?
        bool isDateFormat( int id, const QString& code )
        {
                if ( ( id >= 14 && id <= 22 ) || ( id >= 27 && id <= 36 ) || ( id >= 45 && id <= 47 ) || ( id >= 50 && id <= 58 ) )
                {
                        return true;
                }
                if ( code.isEmpty() )
                {
                        return false;
                }
                // ignore quoted texts, [colors] and escaped characters
                QString c = code;
                c.remove( QRegularExpression( "\"[^\"]*\"" ) );
                c.remove( QRegularExpression( "\\[[^\\]]*\\]" ) );
                c.remove( QRegularExpression( "\\\\." ) );
                return c.contains( QRegularExpression( "[dmyhs]", QRegularExpression::CaseInsensitiveOption ) ) &&
                       !c.contains( "General", Qt::CaseInsensitive );
        }

        // Indexes (cellXfs) of the styles that show dates
        QHash<int,bool> readDateStyles( const QByteArray& data )
        {
                QHash<int,QString> customCodes;
                QList<int> xfFormats;

                QXmlStreamReader xml( data );
                bool inCellXfs = false;
                while ( !xml.atEnd() )
                {
                        xml.readNext();
                        if ( xml.isStartElement() )
                        {
                                if ( xml.name() == QLatin1String( "numFmt" ) )
                                {
                                        customCodes.insert( xml.attributes().value( "numFmtId" ).toInt(),
                                                            xml.attributes().value( "formatCode" ).toString() );
                                }
                                else if ( xml.name() == QLatin1String( "cellXfs" ) )
                                {
                                        inCellXfs = true;
                                }
                                else if ( inCellXfs && xml.name() == QLatin1String( "xf" ) )
                                {
                                        xfFormats << xml.attributes().value( "numFmtId" ).toInt();
                                }
                        }
                        else if ( xml.isEndElement() && xml.name() == QLatin1String( "cellXfs" ) )
                        {
                                inCellXfs = false;
                        }
                }

                QHash<int,bool> result;
                for ( int i = 0; i < xfFormats.size(); i++ )
                {
                        result.insert( i, isDateFormat( xfFormats[i], customCodes.value( xfFormats[i] ) ) );
                }
                return result;
        }

        // Excel serial number -> text
        QString serialToText( double serial )
        {
                QDateTime base( QDate( 1899, 12, 30 ), QTime( 0, 0 ) );
                qint64 ms = qint64( std::llround( serial * 86400000.0 ) );
                QDateTime dt = base.addMSecs( ms );
                bool hasTime = ( serial - std::floor( serial ) ) > 1e-9;
                bool hasDate = serial >= 1.0;
                if ( !hasDate )
                {
                        return dt.toString( "HH:mm:ss" );
                }
                return dt.toString( hasTime ? "dd/MM/yyyy HH:mm:ss" : "dd/MM/yyyy" );
        }

        // Number as written in the file -> text (avoids "3.4856780000000001E+16")
        QString numberToText( const QString& v )
        {
                if ( !v.contains( 'E', Qt::CaseInsensitive ) )
                {
                        return v;
                }
                bool ok = false;
                double d = v.toDouble( &ok );
                if ( !ok )
                {
                        return v;
                }
                if ( d == std::floor( d ) && std::fabs( d ) < 1e21 )
                {
                        return QString::number( d, 'f', 0 );
                }
                return QString::number( d, 'g', 15 );
        }
}


namespace glabels::merge
{

        Excel::Excel() : Merge()
        {
                mId = ID;
        }


        Excel::Excel( const Excel* merge )
                : Merge( merge ), mKeys( merge->mKeys ), mRows( merge->mRows ), mNextRow( merge->mNextRow )
        {
        }


        Excel* Excel::clone() const
        {
                return new Excel( this );
        }


        QString Excel::id()
        {
                return ID;
        }


        Merge* Excel::create()
        {
                return new Excel();
        }


        QStringList Excel::keys() const
        {
                return mKeys;
        }


        QString Excel::primaryKey() const
        {
                return mKeys.isEmpty() ? QString() : mKeys.first();
        }


        void Excel::open()
        {
                mKeys.clear();
                mRows.clear();
                mNextRow = 0;

                // "file.xlsx#Sheet name" selects a sheet
                QString path = source();
                QString wantedSheet;
                int hash = path.lastIndexOf( '#' );
                if ( hash > 0 && path.left( hash ).endsWith( ".xlsx", Qt::CaseInsensitive ) )
                {
                        wantedSheet = path.mid( hash + 1 );
                        path = path.left( hash );
                }

                QZipReader zip( path );
                if ( !zip.isReadable() )
                {
                        return;
                }

                // Sheet file: by name through workbook.xml and its relationships, or the first one
                QString sheetFile = "xl/worksheets/sheet1.xml";
                {
                        QMap<QString,QString> targets;             // rId -> file
                        QXmlStreamReader rels( zip.fileData( "xl/_rels/workbook.xml.rels" ) );
                        while ( !rels.atEnd() )
                        {
                                rels.readNext();
                                if ( rels.isStartElement() && rels.name() == QLatin1String( "Relationship" ) )
                                {
                                        QString target = rels.attributes().value( "Target" ).toString();
                                        if ( target.startsWith( '/' ) ) target = target.mid( 1 );
                                        else if ( !target.startsWith( "xl/" ) ) target = "xl/" + target;
                                        targets.insert( rels.attributes().value( "Id" ).toString(), target );
                                }
                        }

                        QXmlStreamReader wb( zip.fileData( "xl/workbook.xml" ) );
                        bool first = true;
                        while ( !wb.atEnd() )
                        {
                                wb.readNext();
                                if ( wb.isStartElement() && wb.name() == QLatin1String( "sheet" ) )
                                {
                                        QString name = wb.attributes().value( "name" ).toString();
                                        QString rid  = wb.attributes().value( "r:id" ).toString();
                                        if ( ( first && wantedSheet.isEmpty() ) || ( !wantedSheet.isEmpty() && name.compare( wantedSheet, Qt::CaseInsensitive ) == 0 ) )
                                        {
                                                if ( targets.contains( rid ) )
                                                {
                                                        sheetFile = targets.value( rid );
                                                }
                                                break;
                                        }
                                        first = false;
                                }
                        }
                }

                QStringList shared = readSharedStrings( zip.fileData( "xl/sharedStrings.xml" ) );
                QHash<int,bool> dateStyles = readDateStyles( zip.fileData( "xl/styles.xml" ) );

                QByteArray sheetData = zip.fileData( sheetFile );
                if ( sheetData.isEmpty() )
                {
                        return;
                }

                QVector<QStringList> rows;
                QXmlStreamReader xml( sheetData );
                while ( !xml.atEnd() )
                {
                        xml.readNext();
                        if ( !( xml.isStartElement() && xml.name() == QLatin1String( "row" ) ) )
                        {
                                continue;
                        }

                        int rowIndex = xml.attributes().value( "r" ).toInt() - 1;
                        QStringList cells;
                        while ( !xml.atEnd() )
                        {
                                xml.readNext();
                                if ( xml.isEndElement() && xml.name() == QLatin1String( "row" ) )
                                {
                                        break;
                                }
                                if ( !( xml.isStartElement() && xml.name() == QLatin1String( "c" ) ) )
                                {
                                        continue;
                                }

                                QString ref  = xml.attributes().value( "r" ).toString();
                                QString type = xml.attributes().value( "t" ).toString();
                                int style    = xml.attributes().value( "s" ).toInt();
                                int col      = ref.isEmpty() ? cells.size() : columnFromRef( ref );

                                QString value;
                                bool isInline = false;
                                while ( !xml.atEnd() )
                                {
                                        xml.readNext();
                                        if ( xml.isEndElement() && xml.name() == QLatin1String( "c" ) )
                                        {
                                                break;
                                        }
                                        if ( xml.isStartElement() && xml.name() == QLatin1String( "v" ) )
                                        {
                                                value = xml.readElementText();
                                        }
                                        else if ( xml.isStartElement() && xml.name() == QLatin1String( "is" ) )
                                        {
                                                value = readRichText( xml, "is" );
                                                isInline = true;
                                        }
                                }

                                QString text;
                                if ( isInline || type == "inlineStr" || type == "str" )
                                {
                                        text = value;
                                }
                                else if ( type == "s" )
                                {
                                        int i = value.toInt();
                                        text = ( i >= 0 && i < shared.size() ) ? shared[i] : QString();
                                }
                                else if ( type == "b" )
                                {
                                        text = ( value == "1" ) ? "VERDADERO" : "FALSO";
                                }
                                else if ( type == "e" )
                                {
                                        text = QString();
                                }
                                else if ( !value.isEmpty() )          // number (or date)
                                {
                                        bool ok = false;
                                        double d = value.toDouble( &ok );
                                        text = ( ok && dateStyles.value( style, false ) ) ? serialToText( d ) : numberToText( value );
                                }

                                while ( cells.size() <= col ) cells << QString();
                                cells[col] = text;
                        }

                        // keep the position of the row (blank rows stay blank)
                        while ( rowIndex >= 0 && rows.size() < rowIndex ) rows << QStringList();
                        rows << cells;
                }

                // Row 1 = field names, the rest are records
                if ( rows.isEmpty() )
                {
                        return;
                }
                mKeys = rows.first();
                for ( int i = 0; i < mKeys.size(); i++ )
                {
                        if ( mKeys[i].trimmed().isEmpty() )
                        {
                                mKeys[i] = QString::number( i + 1 );
                        }
                }
                while ( !mKeys.isEmpty() && mKeys.last().isEmpty() ) mKeys.removeLast();

                for ( int i = 1; i < rows.size(); i++ )
                {
                        mRows << rows[i];
                }
        }


        void Excel::close()
        {
                mRows.clear();
                mNextRow = 0;
        }


        Record Excel::readNextRecord()
        {
                // blank rows are skipped; the end of the list ends the merge
                while ( mNextRow < mRows.size() )
                {
                        const QStringList& cells = mRows[mNextRow++];

                        bool blank = true;
                        for ( const QString& c : cells )
                        {
                                if ( !c.isEmpty() ) { blank = false; break; }
                        }
                        if ( blank )
                        {
                                continue;
                        }

                        Record record;
                        for ( int i = 0; i < mKeys.size(); i++ )
                        {
                                record[ mKeys[i] ] = ( i < cells.size() ) ? cells[i] : QString();
                        }
                        return record;
                }

                return NullRecord();
        }

}
