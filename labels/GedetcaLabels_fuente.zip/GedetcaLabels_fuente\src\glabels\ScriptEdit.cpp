//  ScriptEdit.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "ScriptEdit.hpp"

#include <QAbstractItemView>
#include <QKeyEvent>
#include <QRegularExpression>
#include <QScrollBar>
#include <QTextBlock>
#include <QTextCursor>


namespace glabels
{

        namespace
        {
                struct Item { const char* insertText; const char* displayText; };

                const Item COMANDOS[] = {
                        { "RestarDias(",        "RestarDias( fecha, n )  (resta n d�as a una fecha)" },
                        { "SumarDias(",         "SumarDias( fecha, n )  (suma n d�as a una fecha)" },
                        { "RestarMeses(",       "RestarMeses( fecha, n )" },
                        { "SumarMeses(",        "SumarMeses( fecha, n )" },
                        { "RestarAnios(",       "RestarAnios( fecha, n )" },
                        { "SumarAnios(",        "SumarAnios( fecha, n )" },
                        { "Reemplazar(",        "Reemplazar( texto, buscar, nuevo )  (todas las veces)" },
                        { "Recortar(",          "Recortar( texto )  (quita espacios)" },
                        { "Mayusculas(",        "Mayusculas( texto )" },
                        { "Minusculas(",        "Minusculas( texto )" },
                        { "PrimeraMayuscula(",  "PrimeraMayuscula( texto )  (cada palabra)" },
                        { "RellenarIzquierda(", "RellenarIzquierda( texto, largo, \"0\" )  (ceros a la izquierda)" },
                        { "RellenarDerecha(",   "RellenarDerecha( texto, largo, \" \" )" },
                        { "Primeros(",          "Primeros( texto, n )  (primeros n caracteres)" },
                        { "Ultimos(",           "Ultimos( texto, n )  (�ltimos n caracteres)" },
                        { "QuitarInicio(",      "QuitarInicio( texto, n )  (quita los primeros n)" },
                        { "QuitarFinal(",       "QuitarFinal( texto, n )  (quita los �ltimos n)" },
                        { "Contiene(",          "Contiene( texto, buscar )  (verdadero/falso)" },
                        { "Campo(",             "Campo( \"nombre\" )  (valor de un campo o variable)" },
                        { "Variable(",         "Variable( \"nombre\" )  (valor de una variable del proyecto)" },
                        { "Objeto(",           "Objeto( \"nombre\" )  (texto que muestra otro objeto)" },
                        { "Etiqueta(",         "Etiqueta()  (numero de esta etiqueta en la tirada: 1, 2, 3...)" },
                        { "Total(",            "Total()  (cuantas etiquetas tiene la tirada)" },
                        { "si (",               "si ( condicion ) { ... }  (if)" },
                        { "sino",               "sino { ... }  (else)" },
                        { "para (",             "para ( variable i = 0; i < n; i++ ) { ... }  (for)" },
                        { "mientras (",         "mientras ( condicion ) { ... }  (while)" },
                        { "devolver",           "devolver valor  (return)" },
                        { "variable",           "variable nombre = valor;  (var)" },
                        { "verdadero",          "verdadero  (true)" },
                        { "falso",              "falso  (false)" },
                        { "Valor",              "Valor  (el texto del objeto; se puede cambiar: Valor = ...)" },
                        { "SI(",                "SI( condicion, si_verdadero, si_falso )" },
                        { "Y(",                 "Y( a, b, ... )  (todas ciertas)" },
                        { "O(",                 "O( a, b, ... )  (alguna cierta)" },
                        { "NO(",                "NO( a )" },
                        { "SIERROR(",           "SIERROR( valor, alternativo )  (si esta vacio o no es valido)" },
                        { "ESNUMERO(",          "ESNUMERO( x )" },
                        { "ESBLANCO(",          "ESBLANCO( x )" },
                        { "IGUAL(",             "IGUAL( a, b )" },
                        { "SUMA(",              "SUMA( a, b, ... )" },
                        { "PRODUCTO(",          "PRODUCTO( a, b, ... )" },
                        { "PROMEDIO(",          "PROMEDIO( a, b, ... )" },
                        { "MAX(",               "MAX( a, b, ... )" },
                        { "MIN(",               "MIN( a, b, ... )" },
                        { "CONTAR(",            "CONTAR( a, b, ... )  (cuantos numeros)" },
                        { "ABS(",               "ABS( n )" },
                        { "ENTERO(",            "ENTERO( n )  (parte entera hacia abajo)" },
                        { "TRUNCAR(",           "TRUNCAR( n, decimales )" },
                        { "REDONDEAR(",         "REDONDEAR( n, decimales )" },
                        { "RESIDUO(",           "RESIDUO( n, divisor )" },
                        { "POTENCIA(",          "POTENCIA( n, exponente )" },
                        { "RAIZ(",              "RAIZ( n )" },
                        { "CONCATENAR(",        "CONCATENAR( a, b, ... )  (une textos)" },
                        { "IZQUIERDA(",         "IZQUIERDA( texto, n )" },
                        { "DERECHA(",           "DERECHA( texto, n )" },
                        { "EXTRAE(",            "EXTRAE( texto, inicio, n )  (inicio desde 1)" },
                        { "LARGO(",             "LARGO( texto )" },
                        { "MAYUSC(",            "MAYUSC( texto )" },
                        { "MINUSC(",            "MINUSC( texto )" },
                        { "NOMPROPIO(",         "NOMPROPIO( texto )" },
                        { "ESPACIOS(",          "ESPACIOS( texto )  (quita espacios sobrantes)" },
                        { "SUSTITUIR(",         "SUSTITUIR( texto, antiguo, nuevo )" },
                        { "ENCONTRAR(",         "ENCONTRAR( buscar, en_texto )  (posicion desde 1, 0 si no esta)" },
                        { "REPETIR(",           "REPETIR( texto, veces )" },
                        { "VALOR(",             "VALOR( texto )  (texto a numero)" },
                        { "TEXTO(",             "TEXTO( numero, decimales )" },
                        { "HOY(",               "HOY()  (fecha de hoy dd/MM/aaaa)" },
                        { "AHORA(",             "AHORA()  (fecha y hora)" },
                        { "DIA(",               "DIA( fecha )" },
                        { "MES(",               "MES( fecha )" },
                        { "ANIO(",              "ANIO( fecha )" },
                        { "FECHA(",             "FECHA( anio, mes, dia )" },
                };
                // Keywords and globals
                const Item GLOBALS[] = {
                        { "Value",       "Value  (el texto del objeto)" },
                        { "Fields",      "Fields  (campos y variables)" },
                        { "var ",        "var  (variable)" },
                        { "let ",        "let  (variable)" },
                        { "const ",      "const  (constante)" },
                        { "if (",        "if ( condición ) { … }" },
                        { "else",        "else" },
                        { "else if (",   "else if ( condición ) { … }" },
                        { "for (",       "for ( var i = 0; i < n; i++ ) { … }" },
                        { "while (",     "while ( condición ) { … }" },
                        { "switch (",    "switch ( valor ) { case … }" },
                        { "case ",       "case" },
                        { "break;",      "break;" },
                        { "continue;",   "continue;" },
                        { "return",      "return" },
                        { "function ",   "function nombre( … ) { … }" },
                        { "try {",       "try { … } catch ( e ) { … }" },
                        { "catch (",     "catch" },
                        { "true",        "true" },
                        { "false",       "false" },
                        { "null",        "null" },
                        { "undefined",   "undefined" },
                        { "typeof ",     "typeof" },
                        { "new Date(",   "new Date( texto )  (fecha)" },
                        { "Math",        "Math  (matemáticas)" },
                        { "Number",      "Number  (números)" },
                        { "String",      "String" },
                        { "Date",        "Date  (fechas)" },
                        { "Array",       "Array" },
                        { "JSON",        "JSON" },
                        { "parseInt(",   "parseInt( texto )  (entero)" },
                        { "parseFloat(", "parseFloat( texto )  (decimal)" },
                        { "isNaN(",      "isNaN( valor )  (¿no es número?)" },
                };

                // Methods available after a dot on text / array / number / date values
                const Item MEMBERS[] = {
                        { "replace(",       "replace( buscar, nuevo )  (reemplazar)" },
                        { "slice(",         "slice( desde, hasta )  (porción)" },
                        { "substring(",     "substring( desde, hasta )" },
                        { "split(",         "split( separador )  (partir)" },
                        { "padStart(",      "padStart( largo, relleno )  (ceros a la izquierda)" },
                        { "toUpperCase()",  "toUpperCase()  (mayúsculas)" },
                        { "toLowerCase()",  "toLowerCase()  (minúsculas)" },
                        { "trim()",         "trim()  (quita espacios)" },
                        { "includes(",      "includes( texto )  (contiene)" },
                        { "startsWith(",    "startsWith( texto )  (empieza con)" },
                        { "endsWith(",      "endsWith( texto )  (termina en)" },
                        { "indexOf(",       "indexOf( texto )  (posición)" },
                        { "length",         "length  (largo)" },
                        { "charAt(",        "charAt( n )  (carácter n)" },
                        { "charCodeAt(",    "charCodeAt( n )  (código del carácter)" },
                        { "concat(",        "concat( texto )" },
                        { "lastIndexOf(",   "lastIndexOf( texto )" },
                        { "match(",         "match( /regex/ )" },
                        { "padEnd(",        "padEnd( largo, relleno )" },
                        { "repeat(",        "repeat( veces )" },
                        { "search(",        "search( /regex/ )" },
                        { "substr(",        "substr( desde, cantidad )" },
                        { "toFixed(",       "toFixed( decimales )" },
                        { "toString()",     "toString()" },
                        { "join(",          "join( separador )  (unir)" },
                        { "map(",           "map( x => … )" },
                        { "filter(",        "filter( x => … )" },
                        { "forEach(",       "forEach( x => … )" },
                        { "reduce(",        "reduce( ( a, b ) => …, inicial )" },
                        { "push(",          "push( valor )" },
                        { "pop()",          "pop()" },
                        { "reverse()",      "reverse()  (invertir)" },
                        { "sort()",         "sort()  (ordenar)" },
                        { "splice(",        "splice( desde, cantidad )" },
                        { "getFullYear()",  "getFullYear()  (año)" },
                        { "getMonth()",     "getMonth()  (mes 0-11)" },
                        { "getDate()",      "getDate()  (día)" },
                        { "getDay()",       "getDay()  (día de la semana)" },
                        { "getHours()",     "getHours()" },
                        { "getMinutes()",   "getMinutes()" },
                        { "getSeconds()",   "getSeconds()" },
                        { "getTime()",      "getTime()" },
                        { "setDate(",       "setDate( día )" },
                        { "setMonth(",      "setMonth( mes )" },
                        { "setFullYear(",   "setFullYear( año )" },
                        { "toISOString()",  "toISOString()  (AAAA-MM-DDTHH:mm:ss)" },
                };

                const Item MATH[] = {
                        { "round(",   "round( x )  (redondear)" },
                        { "floor(",   "floor( x )  (hacia abajo)" },
                        { "ceil(",    "ceil( x )  (hacia arriba)" },
                        { "trunc(",   "trunc( x )  (quita decimales)" },
                        { "abs(",     "abs( x )" },
                        { "max(",     "max( a, b )" },
                        { "min(",     "min( a, b )" },
                        { "pow(",     "pow( base, exponente )" },
                        { "sqrt(",    "sqrt( x )" },
                        { "random()", "random()" },
                        { "PI",       "PI" },
                };

                const Item NUMBER[] = {
                        { "isNaN(",           "isNaN( x )" },
                        { "isInteger(",       "isInteger( x )" },
                        { "parseFloat(",      "parseFloat( texto )" },
                        { "parseInt(",        "parseInt( texto )" },
                        { "MAX_SAFE_INTEGER", "MAX_SAFE_INTEGER" },
                };

                const Item STRING[] = {
                        { "fromCharCode(", "fromCharCode( código )" },
                };

                const Item DATE[] = {
                        { "now()",  "now()  (ahora, en milisegundos)" },
                        { "parse(", "parse( texto )" },
                };

                template <size_t N>
                void addAll( QList<QPair<QString,QString>>& list, const Item (&items)[N] )
                {
                        for ( const Item& i : items )
                        {
                                list.append( { QString::fromUtf8( i.insertText ), QString::fromUtf8( i.displayText ) } );
                        }
                }

                bool isWordChar( QChar c )
                {
                        return c.isLetterOrNumber() || c == '_' || c == '$';
                }
        }


        ScriptEdit::ScriptEdit( QWidget* parent )
                : QPlainTextEdit( parent )
        {
                mModel = new QStandardItemModel( this );

                mCompleter = new QCompleter( this );
                mCompleter->setModel( mModel );
                mCompleter->setWidget( this );
                mCompleter->setCompletionMode( QCompleter::PopupCompletion );
                mCompleter->setCaseSensitivity( Qt::CaseInsensitive );
                mCompleter->setCompletionRole( Qt::EditRole );
                mCompleter->setFilterMode( Qt::MatchStartsWith );
                mCompleter->setMaxVisibleItems( 10 );

                connect( mCompleter, QOverload<const QString&>::of( &QCompleter::activated ),
                         this, &ScriptEdit::insertCompletion );
        }


        void ScriptEdit::setFieldNames( const QStringList& names )
        {
                mFieldNames = names;
        }


        void ScriptEdit::focusInEvent( QFocusEvent* event )
        {
                mCompleter->setWidget( this );
                QPlainTextEdit::focusInEvent( event );
        }


        // Identifier being typed, just before the cursor
        QString ScriptEdit::wordBeforeCursor() const
        {
                QTextCursor tc = textCursor();
                QString line = tc.block().text();
                int pos = tc.positionInBlock();
                int start = pos;
                while ( start > 0 && isWordChar( line[start - 1] ) )
                {
                        start--;
                }
                return line.mid( start, pos - start );
        }


        // Identifier before the dot that precedes the word being typed ("Fields" in "Fields.lo")
        QString ScriptEdit::objectBeforeDot() const
        {
                QTextCursor tc = textCursor();
                QString line = tc.block().text();
                int pos = tc.positionInBlock();
                int start = pos;
                while ( start > 0 && isWordChar( line[start - 1] ) )
                {
                        start--;
                }
                if ( start == 0 || line[start - 1] != '.' )
                {
                        return QString();   // not after a dot
                }
                int end = start - 1;        // position of the dot
                int objStart = end;
                while ( objStart > 0 && isWordChar( line[objStart - 1] ) )
                {
                        objStart--;
                }
                QString obj = line.mid( objStart, end - objStart );
                return obj.isEmpty() ? QString( "?" ) : obj;   // "?" = a value, e.g. ")" or "]"
        }


        QList<ScriptEdit::Suggestion> ScriptEdit::suggestionsFor( const QString& object ) const
        {
                QList<QPair<QString,QString>> raw;

                if ( object.isEmpty() )
                {
                        addAll( raw, COMANDOS );
                        addAll( raw, GLOBALS );
                        for ( const QString& f : mFieldNames )
                        {
                                // Quick way to reach a field
                                bool simple = f.contains( QRegularExpression( "^[A-Za-z_][A-Za-z0-9_]*$" ) );
                                QString expr = simple ? "Fields." + f : QString( "Fields[\"%1\"]" ).arg( f );
                                raw.append( { expr, expr + "  (campo / variable)" } );
                        }
                }
                else if ( object == "Fields" )
                {
                        for ( const QString& f : mFieldNames )
                        {
                                // Names with spaces or symbols are offered in the general list as Fields["name"]
                                if ( f.contains( QRegularExpression( "^[A-Za-z_][A-Za-z0-9_]*$" ) ) )
                                {
                                        raw.append( { f, f + "  (campo / variable)" } );
                                }
                        }
                }
                else if ( object == "Math" )   addAll( raw, MATH );
                else if ( object == "Number" ) addAll( raw, NUMBER );
                else if ( object == "String" ) addAll( raw, STRING );
                else if ( object == "Date" )   addAll( raw, DATE );
                else                           addAll( raw, MEMBERS );

                QList<Suggestion> list;
                for ( const auto& p : raw )
                {
                        list.append( { p.first, p.second } );
                }
                return list;
        }


        void ScriptEdit::showSuggestions( bool forced, bool afterDot )
        {
                QString prefix = wordBeforeCursor();
                QString object = objectBeforeDot();

                if ( !forced && !afterDot && prefix.isEmpty() )
                {
                        mCompleter->popup()->hide();
                        return;
                }

                // Nothing to suggest inside "Fields[...]" brackets etc.; just by prefix.
                QList<Suggestion> list = suggestionsFor( object );

                mModel->clear();
                for ( const Suggestion& s : list )
                {
                        auto* item = new QStandardItem( s.displayText );
                        item->setData( s.displayText, Qt::DisplayRole );
                        item->setData( s.insertText, Qt::UserRole );
                        mModel->appendRow( item );
                }

                mCompleter->setCompletionRole( Qt::UserRole );
                mCompleter->setCompletionPrefix( prefix );

                if ( mCompleter->completionCount() == 0 ||
                     ( !forced && mCompleter->completionCount() == 1 &&
                       mCompleter->currentCompletion().compare( prefix, Qt::CaseInsensitive ) == 0 ) )
                {
                        mCompleter->popup()->hide();
                        return;
                }

                mCompleter->popup()->setCurrentIndex( mCompleter->completionModel()->index( 0, 0 ) );

                QRect cr = cursorRect();
                cr.setWidth( mCompleter->popup()->sizeHintForColumn( 0 ) +
                             mCompleter->popup()->verticalScrollBar()->sizeHint().width() + 12 );
                mCompleter->complete( cr );
        }


        void ScriptEdit::insertCompletion( const QString& completion )
        {
                // 'completion' comes from the completion role (UserRole): the text to insert
                QTextCursor tc = textCursor();
                int prefixLength = wordBeforeCursor().size();
                tc.movePosition( QTextCursor::Left, QTextCursor::KeepAnchor, prefixLength );
                tc.insertText( completion );

                // Put the cursor inside "()" of a method taken from the list
                if ( completion.endsWith( "()" ) )
                {
                        tc.movePosition( QTextCursor::Left );
                }
                setTextCursor( tc );
        }


        void ScriptEdit::keyPressEvent( QKeyEvent* event )
        {
                if ( mCompleter->popup()->isVisible() )
                {
                        switch ( event->key() )
                        {
                        case Qt::Key_Enter:
                        case Qt::Key_Return:
                        case Qt::Key_Tab:
                        case Qt::Key_Escape:
                        case Qt::Key_Backtab:
                                event->ignore();   // the completer takes these
                                return;
                        default:
                                break;
                        }
                }

                bool forced = ( event->modifiers() & Qt::ControlModifier ) && event->key() == Qt::Key_Space;
                if ( !forced )
                {
                        QPlainTextEdit::keyPressEvent( event );
                }

                // Modifier keys alone, arrows, etc.: nothing to do
                if ( !forced && event->text().isEmpty() )
                {
                        if ( event->key() == Qt::Key_Backspace )
                        {
                                showSuggestions( false, false );
                        }
                        return;
                }

                QString typed = event->text();
                bool afterDot = ( typed == "." );

                if ( !forced && !afterDot && !( typed.size() == 1 && isWordChar( typed[0] ) ) )
                {
                        mCompleter->popup()->hide();   // space, punctuation, newline...
                        return;
                }

                showSuggestions( forced, afterDot );
        }

}
