//  BarcodeTextEditor.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "BarcodeTextEditor.hpp"

#include <QButtonGroup>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QVBoxLayout>


namespace glabels
{

        namespace
        {
                QToolButton* makeToggle( const QString& text, const QString& tip, const QFont& font )
                {
                        auto* b = new QToolButton();
                        b->setText( text );
                        b->setToolTip( tip );
                        b->setCheckable( true );
                        b->setFont( font );
                        b->setMinimumWidth( 30 );
                        return b;
                }
        }


        BarcodeTextEditor::BarcodeTextEditor( QWidget* parent )
                : QWidget( parent )
        {
                mCustomCheck = new QCheckBox( tr("Use a custom text format") );
                mCustomCheck->setToolTip( tr("This barcode style has its own text. Check to draw the text with the format below.") );

                mFontCombo = new QFontComboBox();
                mSizeSpin = new QDoubleSpinBox();
                mSizeSpin->setRange( 1.0, 200.0 );
                mSizeSpin->setDecimals( 1 );
                mSizeSpin->setSingleStep( 0.5 );
                mSizeSpin->setSuffix( " pt" );

                QFont bold; bold.setBold( true );
                QFont italic; italic.setItalic( true );
                QFont underline; underline.setUnderline( true );
                mBoldButton      = makeToggle( "B", tr("Bold"), bold );
                mItalicButton    = makeToggle( "I", tr("Italic"), italic );
                mUnderlineButton = makeToggle( "U", tr("Underline"), underline );

                mLeftButton   = makeToggle( "⇤", tr("Align left"), QFont() );
                mCenterButton = makeToggle( "↔", tr("Center"), QFont() );
                mRightButton  = makeToggle( "⇥", tr("Align right"), QFont() );
                auto* alignGroup = new QButtonGroup( this );
                alignGroup->setExclusive( true );
                alignGroup->addButton( mLeftButton );
                alignGroup->addButton( mCenterButton );
                alignGroup->addButton( mRightButton );

                mAboveCheck   = new QCheckBox( tr("Text above the barcode") );
                mShrinkCheck  = new QCheckBox( tr("Allow printing to shrink the text to fit the object") );
                mStretchCheck = new QCheckBox( tr("Stretch text to fill the box (deform)") );

                auto* fontRow = new QHBoxLayout();
                fontRow->addWidget( mFontCombo, 1 );
                fontRow->addWidget( mSizeSpin );

                auto* styleRow = new QHBoxLayout();
                styleRow->addWidget( mBoldButton );
                styleRow->addWidget( mItalicButton );
                styleRow->addWidget( mUnderlineButton );
                styleRow->addSpacing( 12 );
                styleRow->addWidget( mLeftButton );
                styleRow->addWidget( mCenterButton );
                styleRow->addWidget( mRightButton );
                styleRow->addStretch( 1 );

                auto* main = new QVBoxLayout( this );
                main->setContentsMargins( 0, 0, 0, 0 );
                main->addWidget( mCustomCheck );
                main->addLayout( fontRow );
                main->addLayout( styleRow );
                main->addWidget( mAboveCheck );
                main->addWidget( mShrinkCheck );
                main->addWidget( mStretchCheck );

                connect( mCustomCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mFontCombo, SIGNAL(currentFontChanged(QFont)), this, SLOT(onControlsChanged()) );
                connect( mSizeSpin, SIGNAL(valueChanged(double)), this, SLOT(onControlsChanged()) );
                for ( auto* b : { mBoldButton, mItalicButton, mUnderlineButton, mLeftButton, mCenterButton, mRightButton } )
                {
                        connect( b, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                }
                connect( mAboveCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mShrinkCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
                connect( mStretchCheck, SIGNAL(toggled(bool)), this, SLOT(onControlsChanged()) );
        }


        model::BarcodeTextOptions BarcodeTextEditor::options() const
        {
                model::BarcodeTextOptions o;
                o.fontFamily = mFontCombo->currentFont().family();
                o.fontSize   = mSizeSpin->value();
                o.bold       = mBoldButton->isChecked();
                o.italic     = mItalicButton->isChecked();
                o.underline  = mUnderlineButton->isChecked();
                o.hAlign     = mLeftButton->isChecked() ? Qt::AlignLeft
                             : mRightButton->isChecked() ? Qt::AlignRight : Qt::AlignHCenter;
                o.above      = mAboveCheck->isChecked();
                o.stretch    = mStretchCheck->isChecked();
                o.autoShrink = mShrinkCheck->isChecked();
                o.custom     = mCanCustomize ? mCustomCheck->isChecked() : false;
                return o;
        }


        void BarcodeTextEditor::setOptions( const model::BarcodeTextOptions& o, bool canCustomize )
        {
                mBlocked = true;
                mCanCustomize = canCustomize;

                mCustomCheck->setVisible( canCustomize );
                mCustomCheck->setChecked( o.custom );
                mFontCombo->setCurrentFont( QFont( o.fontFamily ) );
                mSizeSpin->setValue( o.fontSize );
                mBoldButton->setChecked( o.bold );
                mItalicButton->setChecked( o.italic );
                mUnderlineButton->setChecked( o.underline );
                mLeftButton->setChecked( o.hAlign & Qt::AlignLeft );
                mRightButton->setChecked( o.hAlign & Qt::AlignRight );
                mCenterButton->setChecked( !( o.hAlign & ( Qt::AlignLeft | Qt::AlignRight ) ) );
                mAboveCheck->setChecked( o.above );
                mShrinkCheck->setChecked( o.autoShrink );
                mStretchCheck->setChecked( o.stretch );

                updateEnabled();
                mBlocked = false;
        }


        void BarcodeTextEditor::updateEnabled()
        {
                bool on = !mCanCustomize || mCustomCheck->isChecked();
                for ( QWidget* w : { static_cast<QWidget*>( mFontCombo ), static_cast<QWidget*>( mSizeSpin ),
                                     static_cast<QWidget*>( mBoldButton ), static_cast<QWidget*>( mItalicButton ),
                                     static_cast<QWidget*>( mUnderlineButton ), static_cast<QWidget*>( mLeftButton ),
                                     static_cast<QWidget*>( mCenterButton ), static_cast<QWidget*>( mRightButton ),
                                     static_cast<QWidget*>( mAboveCheck ), static_cast<QWidget*>( mShrinkCheck ),
                                     static_cast<QWidget*>( mStretchCheck ) } )
                {
                        w->setEnabled( on );
                }
        }


        void BarcodeTextEditor::onControlsChanged()
        {
                updateEnabled();
                if ( !mBlocked )
                {
                        emit changed();
                }
        }

}
