//  SelectProductDialog.cpp
//
//  Copyright (C) 2013-2026  Jaye Evins <evins@snaught.com>
//
//  This file is part of gLabels-qt.
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  gLabels-qt is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with gLabels-qt.  If not, see <http://www.gnu.org/licenses/>.
//


#include "SelectProductDialog.hpp"

#include "NotebookUtil.hpp"
#include "QuickTemplateDialog.hpp"
#include "TemplatePickerItem.hpp"

#include "model/Db.hpp"
#include "model/Settings.hpp"

#include <QBoxLayout>
#include <QDebug>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLineEdit>
#include <QMenu>
#include <QMessageBox>
#include <QPushButton>
#include <QShortcut>


namespace glabels
{

        ///
        /// Constructor
        ///
        SelectProductDialog::SelectProductDialog( QWidget *parent )
                : QDialog(parent)
        {
                setupUi( this );
                productInfoWidget->setVisible( false );

                // Rename custom templates: right click or F2
                templatePicker->setContextMenuPolicy( Qt::CustomContextMenu );
                connect( templatePicker, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(onTemplateContextMenu(QPoint)) );
                auto* renameShortcut = new QShortcut( QKeySequence( Qt::Key_F2 ), templatePicker );
                renameShortcut->setContext( Qt::WidgetWithChildrenShortcut );
                connect( renameShortcut, SIGNAL(activated()), this, SLOT(renameSelectedTemplate()) );

                pageSizeIsoCheck->setChecked( model::Settings::searchIsoPaperSizes() );
                pageSizeUsCheck->setChecked( model::Settings::searchUsPaperSizes() );
                pageSizeOtherCheck->setChecked( model::Settings::searchOtherPaperSizes() );

                allCategoriesRadio->setChecked( model::Settings::searchAllCategories() );
                selectedCategoriesRadio->setChecked( !model::Settings::searchAllCategories() );

                categoriesCheckContainer->setEnabled( !model::Settings::searchAllCategories() );
                mCategoryIdList = model::Settings::searchCategoryList();

                auto categories = model::Db::categories();
                for ( auto& category : categories )
                {
                        QCheckBox* check = new QCheckBox( category.name() );
                        check->setChecked( mCategoryIdList.contains( category.id() ) );
                        categoriesLayout->addWidget( check );

                        mCheckList.append( check );
                        mCheckToCategoryMap[check] = category.id();

                        connect( check, SIGNAL(clicked()), this, SLOT(onCategoryCheckClicked()) );
                }

                NotebookUtil::establishSize( modeNotebook );

                if ( templatePicker->mode() == QListView::IconMode )
                {
                        viewModeButton->setIcon( QIcon::fromTheme( "glabels-view-list" ) );
                        viewModeButton->setToolTip( tr( "List View" ) );
                }
                else
                {
                        viewModeButton->setIcon( QIcon::fromTheme( "glabels-view-grid" ) );
                        viewModeButton->setToolTip( tr( "Grid View" ) );
                }

                auto tmplates = model::Db::templates();
                templatePicker->setTemplates( tmplates );

                if ( model::Settings::recentTemplateList().count() > 0 )
                {
                        modeNotebook->setCurrentIndex(1);
                }

                // Quick custom template (one window instead of the multi-page designer)
                auto* quickButton = new QPushButton( tr("Quick template...") );
                quickButton->setToolTip( tr("Create a custom template: name, shape, size and labels per sheet.") );
                if ( auto* row = findChild<QBoxLayout*>( "horizontalLayout" ) )
                {
                        row->insertWidget( 1, quickButton );
                }
                // Show a template in the list after creating / editing it
                auto reloadAndShow = [this]( const QString& part )
                {
                        templatePicker->setTemplates( model::Db::templates() );
                        modeNotebook->setCurrentIndex( 0 );
                        searchEntry->setText( part );
                        onModeTabChanged();
                };

                connect( quickButton, &QPushButton::clicked, this, [this, reloadAndShow]()
                {
                        QuickTemplateDialog quick( this );
                        if ( quick.exec() == QDialog::Accepted )
                        {
                                reloadAndShow( quick.savedPart() );
                        }
                } );

                // Duplicate / edit / delete the selected template
                mDuplicateButton = new QPushButton( tr("Duplicate") );
                mEditButton      = new QPushButton( tr("Edit...") );
                mDeleteButton    = new QPushButton( tr("Delete") );
                mDuplicateButton->setToolTip( tr("Make an editable copy of the selected template.") );
                mEditButton->setToolTip( tr("Edit the selected custom template.") );
                mDeleteButton->setToolTip( tr("Delete the selected custom template.") );
                if ( auto* row = findChild<QBoxLayout*>( "horizontalLayout" ) )
                {
                        row->insertWidget( 2, mDuplicateButton );
                        row->insertWidget( 3, mEditButton );
                        row->insertWidget( 4, mDeleteButton );
                }

                connect( mDuplicateButton, &QPushButton::clicked, this, [this, reloadAndShow]()
                {
                        model::Template t = templatePicker->selectedTemplate();
                        if ( t.isNull() )
                        {
                                return;
                        }
                        QString part = tr( "%1 (copy)" ).arg( t.part() );
                        for ( int n = 2; model::Db::isTemplateKnown( t.brand(), part ); n++ )
                        {
                                part = tr( "%1 (copy %2)" ).arg( t.part() ).arg( n );
                        }
                        model::Template copy( t );
                        copy.setPart( part );
                        copy.setFileName( "" );
                        copy.setIsUserDefined( true );
                        model::Db::registerUserTemplate( copy );
                        reloadAndShow( part );
                } );

                connect( mEditButton, &QPushButton::clicked, this, [this, reloadAndShow]()
                {
                        model::Template t = templatePicker->selectedTemplate();
                        if ( t.isNull() || !t.isUserDefined() )
                        {
                                return;
                        }
                        if ( !QuickTemplateDialog::canEdit( t ) )
                        {
                                QMessageBox::information( this, tr("Edit template"),
                                                          tr("This template has an advanced design (several layouts or a special shape). "
                                                             "Use File > Product Template Designer (advanced).") );
                                return;
                        }
                        QuickTemplateDialog quick( this, &t );
                        if ( quick.exec() == QDialog::Accepted )
                        {
                                reloadAndShow( quick.savedPart() );
                        }
                } );

                connect( mDeleteButton, &QPushButton::clicked, this, [this]()
                {
                        model::Template t = templatePicker->selectedTemplate();
                        if ( t.isNull() || !t.isUserDefined() )
                        {
                                return;
                        }
                        QMessageBox box( this );
                        box.setIcon( QMessageBox::Warning );
                        box.setWindowTitle( tr("Delete template") );
                        box.setText( tr("Delete the template \"%1\"?").arg( t.name() ) );
                        box.setInformativeText( tr("This cannot be undone.") );
                        auto* yes = box.addButton( tr("Delete"), QMessageBox::YesRole );
                        auto* no  = box.addButton( tr("Cancel"), QMessageBox::NoRole );
                        box.setDefaultButton( no );
                        box.exec();
                        if ( box.clickedButton() != yes )
                        {
                                return;
                        }
                        model::Db::deleteUserTemplateByBrandPart( t.brand(), t.part() );
                        templatePicker->setTemplates( model::Db::templates() );
                        onModeTabChanged();
                        updateTemplateButtons();
                } );
                updateTemplateButtons();

                onModeTabChanged();
        }


        ///
        /// Get selected template
        ///
        model::Template SelectProductDialog::tmplate() const
        {
                if ( mHasSelection )
                {
                        return templatePicker->selectedTemplate();
                }
                else
                {
                        return model::Template();
                }
        }
        ///
        /// Context menu of the template picker
        ///
        void SelectProductDialog::onTemplateContextMenu( const QPoint& pos )
        {
                QModelIndex index = templatePicker->indexAt( pos );
                if ( !index.isValid() )
                {
                        return;
                }
                templatePicker->setCurrentIndex( index );

                model::Template t = templatePicker->selectedTemplate();

                QMenu menu( this );
                QAction* renameAction = menu.addAction( tr("Rename...") );
                renameAction->setShortcut( QKeySequence( Qt::Key_F2 ) );
                renameAction->setEnabled( !t.isNull() && t.isUserDefined() );
                if ( !t.isNull() && !t.isUserDefined() )
                {
                        renameAction->setToolTip( tr("Only custom templates can be renamed.") );
                }

                if ( menu.exec( templatePicker->viewport()->mapToGlobal( pos ) ) == renameAction )
                {
                        renameSelectedTemplate();
                }
        }


        ///
        /// Rename the selected (custom) template
        ///
        void SelectProductDialog::renameSelectedTemplate()
        {
                model::Template t = templatePicker->selectedTemplate();
                if ( t.isNull() )
                {
                        return;
                }
                if ( !t.isUserDefined() )
                {
                        QMessageBox::information( this, tr("Rename template"),
                                                  tr("Only custom templates can be renamed.") );
                        return;
                }

                QDialog dialog( this );
                dialog.setWindowTitle( tr("Rename template") );
                auto* form = new QFormLayout( &dialog );
                auto* brandEdit = new QLineEdit( t.brand() );
                auto* partEdit  = new QLineEdit( t.part() );
                auto* descEdit  = new QLineEdit( t.description() );
                brandEdit->setMinimumWidth( 280 );
                form->addRow( tr("Vendor:"), brandEdit );
                form->addRow( tr("Part #:"), partEdit );
                form->addRow( tr("Description:"), descEdit );
                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );
                form->addRow( buttons );
                connect( buttons, SIGNAL(accepted()), &dialog, SLOT(accept()) );
                connect( buttons, SIGNAL(rejected()), &dialog, SLOT(reject()) );

                if ( dialog.exec() != QDialog::Accepted )
                {
                        return;
                }

                QString newBrand = brandEdit->text().trimmed();
                QString newPart  = partEdit->text().trimmed();
                QString newDesc  = descEdit->text().trimmed();
                if ( newBrand.isEmpty() || newPart.isEmpty() )
                {
                        QMessageBox::warning( this, tr("Rename template"),
                                              tr("Vendor and part number cannot be empty.") );
                        return;
                }

                if ( !model::Db::renameUserTemplate( t.brand(), t.part(), newBrand, newPart, newDesc ) )
                {
                        QMessageBox::warning( this, tr("Rename template"),
                                              tr("Could not rename the template. A template with that vendor and part number may already exist.") );
                        return;
                }

                templatePicker->setTemplates( model::Db::templates() );
                onModeTabChanged();
        }



        ///
        /// Mode Notebook Tab Changed Slot
        ///
        void SelectProductDialog::onModeTabChanged()
        {
                switch (modeNotebook->currentIndex())
                {
                case 0:
                        // Search Tab
                        templatePicker->applyFilter( searchEntry->text(),
                                                     pageSizeIsoCheck->isChecked(),
                                                     pageSizeUsCheck->isChecked(),
                                                     pageSizeOtherCheck->isChecked(),
                                                     allCategoriesRadio->isChecked(),
                                                     mCategoryIdList );
                        break;
                case 1:
                        // Recent Tab
                        templatePicker->applyFilter( model::Settings::recentTemplateList() );
                        break;
                default:
                        qDebug() << "onModeTabChanged(): unknown tab!";
                }
        }


        ///
        /// Search Entry Text Changed Slot
        ///
        void SelectProductDialog::onSearchEntryTextChanged()
        {
                templatePicker->applyFilter( searchEntry->text(),
                                             pageSizeIsoCheck->isChecked(),
                                             pageSizeUsCheck->isChecked(),
                                             pageSizeOtherCheck->isChecked(),
                                             allCategoriesRadio->isChecked(),
                                             mCategoryIdList );
        }


        ///
        /// Page Size Check Clicked Slot
        ///
        void SelectProductDialog::onPageSizeCheckClicked()
        {
                model::Settings::setSearchIsoPaperSizes( pageSizeIsoCheck->isChecked() );
                model::Settings::setSearchUsPaperSizes( pageSizeUsCheck->isChecked() );
                model::Settings::setSearchOtherPaperSizes( pageSizeOtherCheck->isChecked() );

                templatePicker->applyFilter( searchEntry->text(),
                                             pageSizeIsoCheck->isChecked(),
                                             pageSizeUsCheck->isChecked(),
                                             pageSizeOtherCheck->isChecked(),
                                             allCategoriesRadio->isChecked(),
                                             mCategoryIdList );
        }


        ///
        /// Category Radio Clicked Slot
        ///
        void SelectProductDialog::onCategoryRadioClicked()
        {
                categoriesCheckContainer->setEnabled( selectedCategoriesRadio->isChecked() );
                loadCategoryList();

                templatePicker->applyFilter( searchEntry->text(),
                                             pageSizeIsoCheck->isChecked(),
                                             pageSizeUsCheck->isChecked(),
                                             pageSizeOtherCheck->isChecked(),
                                             allCategoriesRadio->isChecked(),
                                             mCategoryIdList );

                model::Settings::setSearchAllCategories( allCategoriesRadio->isChecked() );
        }


        ///
        /// Category Check Clicked Slot
        ///
        void SelectProductDialog::onCategoryCheckClicked()
        {
                loadCategoryList();

                templatePicker->applyFilter( searchEntry->text(),
                                             pageSizeIsoCheck->isChecked(),
                                             pageSizeUsCheck->isChecked(),
                                             pageSizeOtherCheck->isChecked(),
                                             allCategoriesRadio->isChecked(),
                                             mCategoryIdList );


                model::Settings::setSearchCategoryList( mCategoryIdList );
        }


        ///
        /// View Mode Button Clicked Slot
        ///
        void SelectProductDialog::onViewModeButtonClicked()
        {
                if ( templatePicker->mode() == QListView::IconMode )
                {
                        templatePicker->setMode( QListView::ListMode );

                        viewModeButton->setIcon( QIcon::fromTheme( "glabels-view-grid" ) );
                        viewModeButton->setToolTip( tr( "Grid View" ) );
                }
                else
                {
                        templatePicker->setMode( QListView::IconMode );

                        viewModeButton->setIcon( QIcon::fromTheme( "glabels-view-list" ) );
                        viewModeButton->setToolTip( tr( "List View" ) );
                }
        }


        ///
        /// Template Picker Selection Changed Slot
        ///
        void SelectProductDialog::updateTemplateButtons()
        {
                model::Template t = templatePicker->selectedTemplate();
                bool has = !t.isNull();
                mDuplicateButton->setEnabled( has );
                mEditButton->setEnabled( has && t.isUserDefined() );
                mDeleteButton->setEnabled( has && t.isUserDefined() );
        }


        void SelectProductDialog::onTemplatePickerSelectionChanged()
        {
                auto tmplate   = templatePicker->selectedTemplate();
                if ( mDuplicateButton )
                {
                        updateTemplateButtons();
                }
                if ( tmplate.isNull() )
                {
                        productInfoWidget->setVisible( false );
                        selectButton->setEnabled( false );
                        return;
                }

                auto frame = tmplate.frame();

                preview->setTemplate( tmplate );

                vendorLabel->setText( tmplate.brand() );
                if ( model::Db::isVendorNameKnown( tmplate.brand() ) )
                {
                        auto vendor = model::Db::lookupVendorFromName( tmplate.brand() );
                        if ( !vendor.url().isEmpty() )
                        {
                                QString markup = QString( "<a href='%1'>%2</a>" ).arg( vendor.url(), vendor.name() );
                                vendorLabel->setText( markup );
                        }
                }

                if ( !tmplate.productUrl().isEmpty() )
                {
                        QString markup = QString( "<a href='%1'>%2</a>" ).arg( tmplate.productUrl(), tmplate.part() );
                        partLabel->setText( markup );
                }
                else
                {
                        partLabel->setText( tmplate.part() );
                }

                descriptionLabel->setText( tmplate.description() );
                pageSizeLabel->setText( tmplate.paperDescription( model::Settings::units() ) );
                labelSizeLabel->setText( frame->sizeDescription( model::Settings::units() ) );
                layoutLabel->setText( frame->layoutDescription() );

                productInfoWidget->setVisible( true );
                selectButton->setEnabled( true );
        }


        ///
        /// Select Button Clicked Slot
        ///
        void SelectProductDialog::onSelectButtonClicked()
        {
                mHasSelection = true;
                close();
        }


        ///
        /// Cancel Button Clicked Slot
        ///
        void SelectProductDialog::onCancelButtonClicked()
        {
                close();
        }


        ///
        /// Load category list
        ///
        void SelectProductDialog::loadCategoryList()
        {
                mCategoryIdList.clear();

                for ( QCheckBox* check : mCheckList )
                {
                        if ( check->isChecked() )
                        {
                                mCategoryIdList.append( mCheckToCategoryMap[check] );
                        }
                }
        }

} // namespace glabels
