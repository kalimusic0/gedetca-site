//  CropDialog.hpp
//
//  This file is part of gLabels-qt (Gedetca Labels).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef CropDialog_hpp
#define CropDialog_hpp


#include <QDialog>
#include <QDoubleSpinBox>
#include <QImage>
#include <QMarginsF>
#include <QWidget>


namespace glabels
{

        namespace model { class ModelObject; }
        class UndoRedoModel;


        ///
        /// The picture with a rectangle to drag (edges, corners or the whole rectangle)
        ///
        class CropWidget : public QWidget
        {
                Q_OBJECT

        public:
                CropWidget( const QImage& image, const QMarginsF& margins, QWidget* parent = nullptr );

                QMarginsF margins() const;
                void setMargins( const QMarginsF& margins );

        signals:
                void changed();

        protected:
                void paintEvent( QPaintEvent* event ) override;
                void mousePressEvent( QMouseEvent* event ) override;
                void mouseMoveEvent( QMouseEvent* event ) override;
                void mouseReleaseEvent( QMouseEvent* event ) override;
                QSize sizeHint() const override;

        private:
                QRectF imageRect() const;
                QRectF cropRect() const;
                int hitTest( const QPointF& p ) const;
                void clampMargins();

                QImage    mImage;
                QMarginsF mMargins;
                int       mDragMode{ 0 };
                QPointF   mDragStart;
                QMarginsF mDragMargins;
        };


        ///
        /// Crop an image object: preview with a draggable rectangle and the four margins in percent
        ///
        class CropDialog : public QDialog
        {
                Q_OBJECT

        public:
                CropDialog( const QImage& image, const QMarginsF& margins, QWidget* parent = nullptr );

                QMarginsF margins() const;

                // Opens the dialog for an image object and applies the result (with an undo step)
                static bool run( QWidget* parent, model::ModelObject* object, UndoRedoModel* undoRedoModel );

        private:
                void onWidgetChanged();
                void onSpinsChanged();

                CropWidget*      mWidget;
                QDoubleSpinBox*  mLeft;
                QDoubleSpinBox*  mTop;
                QDoubleSpinBox*  mRight;
                QDoubleSpinBox*  mBottom;
                bool             mBlocked{ false };
        };

}


#endif // CropDialog_hpp
