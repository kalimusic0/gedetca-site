//  FieldListWidget.hpp
//
//  Lista de campos de sustitucion arrastrables hacia el editor de etiquetas.

#ifndef FieldListWidget_hpp
#define FieldListWidget_hpp


#include "model/Model.hpp"

#include <QListWidget>


namespace glabels
{

        ///
        /// Field List Widget
        ///
        class FieldListWidget : public QListWidget
        {
                Q_OBJECT

        public:
                static const char* MIME_TYPE;

                FieldListWidget( QWidget* parent = nullptr );

                void setModel( model::Model* model );

        protected:
                QMimeData* mimeData( const QList<QListWidgetItem*>& items ) const override;

        private slots:
                void onFieldsChanged();

        private:
                model::Model* mModel;
        };

}

#endif // FieldListWidget_hpp
