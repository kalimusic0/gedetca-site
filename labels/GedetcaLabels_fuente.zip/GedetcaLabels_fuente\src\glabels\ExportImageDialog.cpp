//  ExportImageDialog.cpp
//
//  This file is part of gLabels-qt (Gedetca Labels customization).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#include "ExportImageDialog.hpp"

#include "model/Settings.hpp"

#include <QDialogButtonBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QVBoxLayout>


namespace glabels
{

        ExportImageDialog::ExportImageDialog( const QString& suggestedFile, int imageCount, QWidget* parent )
                : QDialog( parent )
        {
                setWindowTitle( tr("Export image") );
                setMinimumWidth( 520 );

                mTargetEdit = new QLineEdit( suggestedFile );
                auto* browse = new QPushButton( tr("Browse...") );
                auto* targetRow = new QHBoxLayout();
                targetRow->addWidget( mTargetEdit, 1 );
                targetRow->addWidget( browse );

                mDpiSpin = new QSpinBox();
                mDpiSpin->setRange( 36, 2400 );
                mDpiSpin->setSuffix( " dpi" );
                mDpiSpin->setValue( model::Settings::exportDpi() );

                mBackgroundCombo = new QComboBox();
                mBackgroundCombo->addItem( tr("White") );
                mBackgroundCombo->addItem( tr("Transparent") );
                mBackgroundCombo->setCurrentIndex( model::Settings::exportTransparent() ? 1 : 0 );

                mClipCheck = new QCheckBox( tr("Cut to the label shape (rounded corners, ellipse...)") );

                mSizeLabel = new QLabel();
                mSizeLabel->setWordWrap( true );
                if ( imageCount > 1 )
                {
                        mSizeLabel->setText( tr("%1 images will be created (one per selected merge record); "
                                                "a number is added to the file name.").arg( imageCount ) );
                }

                auto* form = new QFormLayout();
                form->addRow( tr("File:"), targetRow );
                form->addRow( tr("Resolution:"), mDpiSpin );
                form->addRow( tr("Background:"), mBackgroundCombo );
                form->addRow( mClipCheck );
                form->addRow( mSizeLabel );

                auto* hint = new QLabel( tr("The name may contain {name}, {date}, {time}, {datetime}, {n} and "
                                            "{field} (any merge field or variable), e.g. C:\\Labels\\{lote}.png") );
                hint->setWordWrap( true );

                auto* buttons = new QDialogButtonBox( QDialogButtonBox::Ok | QDialogButtonBox::Cancel );

                auto* main = new QVBoxLayout( this );
                main->addLayout( form );
                main->addWidget( hint );
                main->addWidget( buttons );

                connect( browse, SIGNAL(clicked()), this, SLOT(onBrowse()) );
                connect( buttons, SIGNAL(accepted()), this, SLOT(accept()) );
                connect( buttons, SIGNAL(rejected()), this, SLOT(reject()) );
        }


        void ExportImageDialog::onBrowse()
        {
                QString file = QFileDialog::getSaveFileName( this, tr("Export image"), mTargetEdit->text(),
                                                             tr("PNG images (*.png)") );
                if ( !file.isEmpty() )
                {
                        if ( !file.endsWith( ".png", Qt::CaseInsensitive ) )
                        {
                                file += ".png";
                        }
                        mTargetEdit->setText( file );
                }
        }


        QString ExportImageDialog::target() const
        {
                return mTargetEdit->text().trimmed();
        }


        model::ImageExporter::Options ExportImageDialog::options() const
        {
                model::ImageExporter::Options o;
                o.dpi         = mDpiSpin->value();
                o.transparent = ( mBackgroundCombo->currentIndex() == 1 );
                o.clipToShape = mClipCheck->isChecked();
                return o;
        }

}
