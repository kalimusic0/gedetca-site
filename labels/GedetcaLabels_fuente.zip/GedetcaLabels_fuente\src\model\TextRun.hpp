//  TextRun.hpp
//
//  This file is part of gLabels-qt (Gedetca Labels).
//
//  gLabels-qt is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//

#ifndef model_TextRun_hpp
#define model_TextRun_hpp


#include <QList>
#include <QString>
#include <QTextCharFormat>


namespace glabels::model
{

        ///
        /// Character formatting of a stretch of the raw text of a text object (mixed formats in one object).
        /// Every property is optional: a value of -1 (or empty family / zero size) means "as the object".
        ///
        struct TextRun
        {
                int     start{ 0 };
                int     length{ 0 };
                int     bold{ -1 };
                int     italic{ -1 };
                int     underline{ -1 };
                double  size{ 0 };           // points, 0 = as the object
                QString family;

                bool isDefault() const;
                bool sameStyle( const TextRun& other ) const;

                // "start|len|b|i|u|size|family;..." (family percent-encoded)
                static QString toString( const QList<TextRun>& runs );
                static QList<TextRun> fromString( const QString& string );

                // Style of the character at index (a run with only the style, or a default one)
                static TextRun styleAt( const QList<TextRun>& runs, int index );
        };

}


#endif // model_TextRun_hpp
